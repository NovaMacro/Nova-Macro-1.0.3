﻿; going to blue portal
bm_Walk(18, RightKey)
bm_Walk(8, LeftKey)
bm_Walk(65, FwdKey)
bm_Walk(10, RightKey)
bm_Walk(4, BackKey)
bm_Walk(3, LeftKey)

; blue portal
send("{" RotRight " 2}")
Sleep(200)
send("{" SC_E " down}")
Sleep(50)
send("{" SC_E " up}")
HyperSleep(1500)

; going to hive
bm_Walk(5, RightKey)
bm_walk(2, LeftKey)
bm_Walk(5, BackKey, LeftKey)
bm_Walk(22, LeftKey)
bm_Walk(3, RightKey)
bm_Walk(8, BackKey)
bm_Walk(10, LeftKey)

; hive
bm_Walk(10, RightKey)
bm_Walk(5, FwdKey)
bm_Walk(4, BackKey)

; made by Lorddrak