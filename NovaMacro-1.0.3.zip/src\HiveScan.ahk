﻿; =====================================================================
;  Scan des abeilles dans le jeu (Hive Check) : ouvre le menu "Bees",
;  fait defiler la liste et lit chaque abeille avec l'OCR de Windows.
;  - nom : l'OCR lit mal la police du jeu, donc on s'aide de l'ordre fixe
;    de la liste (rarete puis ordre alphabetique) et d'une comparaison souple
;  - etoile a droite du nom : grise = pas eue, noire = eue, doree = gifted
;  - "x2" sous l'icone = nombre d'exemplaires
; =====================================================================

HiveScan(*) {
    if Running
        return MsgBox("Stop the macro (F3) before scanning your bees.", "Nova Macro", "Icon!")
    if !GetRobloxHWND()
        return MsgBox("Roblox is not open.", "Nova Macro", "Icon!")
    if (MsgBox("Nova Macro will open the Bees menu in Roblox, scroll through it and read your bees.`n`nDon't touch the mouse or keyboard until it's done (about 30 s).", "Nova Macro - scan my bees", "OKCancel Iconi") != "OK")
        return
    ActivateRoblox()
    Sleep 300
    try bm_OpenMenu("beemenu")
    catch as e
        return MsgBox("Could not open the Bees menu: " e.Message, "Nova Macro", "Icon!")
    Sleep 800
    UpdateWindow()
    ; zone de la liste (a gauche de l'ecran, sous la barre de menus)
    lx := windowX, ly := windowY + offsetY + 70, lw := Min(400, windowWidth // 3), lh := windowHeight - offsetY - 90
    MouseMove lx + lw // 2, ly + lh // 2
    Send "{WheelUp 40}"
    Sleep 600
    st := {pos: 0, found: Map(), total: 0, prev: [], prevLast: -99999}
    tmp := A_Temp "\nova_beescan"
    DirCreate tmp
    Loop 30 {
        ToolTip "Scanning your bees... (" st.found.Count " found)", windowX + windowWidth // 2 - 80, windowY + 60
        pBM := Gdip_BitmapFromScreen(lx "|" ly "|" lw "|" lh)
        Gdip_SaveBitmapToFile(pBM, tmp "\screen.png")
        lines := OcrLines(tmp "\screen.png")
        same := HCParseScreen(lines, pBM, st)
        Gdip_DisposeImage(pBM)
        if same || (st.pos >= BEE_LIST.Length)   ; plus rien de nouveau : fin de la liste
            break
        MouseMove lx + lw // 2, ly + lh // 2
        Send "{WheelDown 4}"
        Sleep 450
    }
    ToolTip
    try bm_OpenMenu()
    ; resultat dans le Hive Check
    gifted := 0, owned := 0
    for b in BEE_LIST {
        v := st.found.Has(b[1]) ? st.found[b[1]] : "-"
        SaveSetting("HC_B_" b[1], v)
        try RefreshControl("HC_B_" b[1])
        owned += (v != "-"), gifted += (v = "Gifted")
    }
    if st.total {
        SaveSetting("HC_Bees", st.total)
        try RefreshControl("HC_Bees")
    }
    Log("Bee scan: " owned " bee types owned, " gifted " gifted")
    if (MsgBox("Scan done: " owned " bee types found (" gifted " gifted)" (st.total ? ", " st.total " bees in your hive" : "") ".`n`n"
        . "Check the 2 bee pages if something looks wrong, then analyze your hive.`n`nAnalyze now?", "Nova Macro - scan my bees", "YesNo Iconi") = "Yes")
        HiveCheck()
}

; lit le texte d'une image (OCR Windows) : [{t, x, y, w, h}]
OcrLines(img) {
    out := A_Temp "\nova_beescan\ocr.txt"
    try FileDelete out
    RunWait 'powershell -NoProfile -ExecutionPolicy Bypass -File "' A_ScriptDir '\lib\ocr.ps1" "' img '" "' out '"', , "Hide"
    lines := []
    if FileExist(out)
        for l in StrSplit(FileRead(out, "UTF-8"), "`n", "`r") {
            p := StrSplit(l, "|")
            if (p.Length >= 5)
                lines.Push({t: Trim(p[1]), x: Integer(p[2]), y: Integer(p[3]), w: Integer(p[4]), h: Integer(p[5])})
        }
    return lines
}

; analyse un ecran de la liste ; renvoie true s'il n'y a rien de nouveau depuis l'ecran precedent
HCParseScreen(lines, pBM, st) {
    ; decalage avec l'ecran precedent grace aux descriptions (bien lues par l'OCR)
    offset := "", same := 0, longs := 0
    for l in lines
        if (StrLen(l.t) >= 15) {
            longs++
            for p in st.prev
                if (p.t == l.t) {
                    offset := p.y - l.y, same += (offset = 0)
                    break
                }
            if (offset != "")
                break
        }
    if (offset = 0) && longs   ; la liste n'a pas bouge : on est en bas
        return true
    for l in lines
        if RegExMatch(l.t, "i)you have (\d+) bees", &m)
            st.total := Integer(m[1])
    ; noms d'abeilles : lignes courtes, isolees au-dessus de leur description
    names := []
    for i, l in lines {
        gap := (i = 1) ? 999 : l.y - lines[i - 1].y
        if (StrLen(l.t) > 16) || (gap < 32) || (l.x < 100) || (l.h >= 25)
            continue
        if RegExMatch(l.t, "i)^(common|rare|epic|legendary|mythic|event)\b|discovered|you have")
            continue
        if (offset != "") && (l.y + offset <= st.prevLast)   ; deja vue sur l'ecran precedent
            continue
        names.Push(l)
    }
    ; zone de texte des cartes (centre et largeur des descriptions) : l'etoile est a droite
    cx := 0, cn := 0, maxW := 0
    for l in lines
        if (StrLen(l.t) >= 15) && (l.x >= 60) && !RegExMatch(l.t, "i)discovered|you have")
            cx += l.x + l.w / 2, cn++, maxW := Max(maxW, l.w)
    cx := cn ? cx / cn : 200, maxW := maxW ? maxW : 190
    for nm in names {
        ; abeille la plus probable parmi les 3 suivantes dans l'ordre de la liste
        best := 0, bs := -1, c := HCNorm(nm.t)
        Loop 3 {
            k := st.pos + A_Index
            if (k > BEE_LIST.Length)
                break
            sc := HCSim(c, StrLower(BEE_LIST[k][2])) - (A_Index - 1) * 0.08
            if (sc > bs)
                bs := sc, best := k
        }
        if !best
            break
        if (bs < 0.3)
            best := st.pos + 1   ; nom illisible : la suivante dans l'ordre
        st.pos := best
        key := BEE_LIST[best][1]
        ; etoile a droite du nom
        star := HCStar(pBM, Round(cx + 0.36 * maxW), nm.y - 4, Round(0.13 * maxW), nm.h + 8)
        ; nombre d'exemplaires ("x2") sous l'icone de la meme carte
        count := 0
        for l in lines
            if (l.y > nm.y + 20) && (l.y < nm.y + 150) && RegExMatch(l.t, "i)^[x×]\s*([0-9lI|]{1,3})$", &m)
                count := Integer(RegExReplace(m[1], "[lI|]", "1"))
        if (star = "gold")
            st.found[key] := "Gifted"
        else if (star = "black") || count
            st.found[key] := "Have"
    }
    st.prev := lines
    st.prevLast := names.Length ? names[names.Length].y : (lines.Length ? lines[lines.Length].y : -99999)
    return false
}

; couleur de l'etoile : "gold" (gifted), "black" (eue) ou "" (pas eue)
HCStar(pBM, x, y, w, h) {
    Gdip_GetImageDimensions(pBM, &bw, &bh)
    gold := 0, black := 0
    yy := Max(0, y)
    while (yy < Min(bh, y + h)) {
        xx := Max(0, x)
        while (xx < Min(bw, x + w)) {
            c := Gdip_GetPixel(pBM, xx, yy), r := (c >> 16) & 255, g := (c >> 8) & 255, b := c & 255
            if (r > 190 && g > 140 && b < 110)
                gold++
            else if (r < 70 && g < 80 && b < 90)
                black++
            xx += 2
        }
        yy += 2
    }
    return (gold >= 8) ? "gold" : (black >= 8) ? "black" : ""
}

; nom lu par l'OCR, nettoye (chiffres pris pour des lettres, mot "Bee" retire)
HCNorm(t) {
    t := StrLower(t)
    for a, b in Map("0", "o", "1", "l", "3", "e", "5", "s", "@", "a", "|", "l")
        t := StrReplace(t, a, b)
    t := RegExReplace(t, "[^a-z]")
    return RegExReplace(t, "(b[e]{1,2}|bce|bec)$")
}

; ressemblance de deux mots (0 a 1)
HCSim(a, b) {
    if (a = "" || b = "")
        return 0
    if InStr(a, b) || InStr(b, a)
        return 1
    la := StrLen(a), lb := StrLen(b), prev := []
    Loop lb + 1
        prev.Push(A_Index - 1)
    Loop la {
        i := A_Index, cur := [i], ca := SubStr(a, i, 1)
        Loop lb {
            j := A_Index
            cur.Push(Min(prev[j + 1] + 1, cur[j] + 1, prev[j] + (ca = SubStr(b, j, 1) ? 0 : 1)))
        }
        prev := cur
    }
    return 1 - prev[lb + 1] / Max(la, lb)
}
