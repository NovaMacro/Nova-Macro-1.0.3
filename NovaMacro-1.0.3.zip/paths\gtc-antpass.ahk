﻿bm_Walk(3, FwdKey)
bm_Walk(52, LeftKey)
bm_Walk(3, FwdKey)
send "{" FwdKey " down}{space down}"
HyperSleep(300)
send "{space up}"
bm_Walk(5, RightKey)
send "{space down}"
HyperSleep(300)
send "{space up}{" FwdKey " up}"
HyperSleep(500)
bm_Walk(2, FwdKey)
bm_Walk(15, RightKey)
bm_Walk(6, FwdKey, RightKey)
bm_Walk(7, FwdKey)
bm_Walk(5, BackKey, LeftKey)
bm_Walk(23, FwdKey)
bm_Walk(12, LeftKey)
bm_Walk(8, LeftKey, FwdKey) ; 1.3
bm_Walk(10, FwdKey) ; 1.3
bm_Walk(5, RightKey) ; 1.3
bm_Walk(25, FwdKey, RightKey) ; 31
bm_Walk(25, LeftKey) ; 31
bm_Walk(17, BackKey)
