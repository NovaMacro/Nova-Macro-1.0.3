﻿if (MoveMethod = "walk"){
	bm_gotoramp()
	bm_Walk(67.5, BackKey, LeftKey)
	send "{" RotRight " 4}"
	bm_Walk(31.5, FwdKey)
	bm_Walk(9, LeftKey)
	bm_Walk(9, BackKey)
	bm_Walk(58.5, LeftKey)
	bm_Walk(49.5, FwdKey)
	bm_Walk(3.375, LeftKey)
	bm_Walk(36, FwdKey)
	bm_Walk(60, RightKey)
	bm_Walk(60, BackKey)
	bm_Walk(9, LeftKey)
	bm_Walk(9, FwdKey)
}else{
	bm_gotoramp()
	bm_gotocannon()
	send "{" RotLeft " 4}"
	sleep 100
	send "{e down}"
	HyperSleep(100)
	send "{e up}{" FwdKey " down}"
	HyperSleep(800)
	send "{" FwdKey " up}{space 2}"
	HyperSleep(2100)
	send "{space}"
	sleep 1000
	bm_Walk(7, BackKey, LeftKey)
	bm_Walk(9, LeftKey, FwdKey)
	bm_Walk(5, FwdKey)	
}
bm_Walk(5, BackKey)
bm_Walk(2, RightKey)
