﻿; =====================================================================
;  Coeur : touches, deplacements, fenetre Roblox, reset, canon, ruche
; =====================================================================

; ---------- Touches (scan codes : marche en AZERTY et en QWERTY) ----------
global FwdKey := "sc011", BackKey := "sc01f", LeftKey := "sc01e", RightKey := "sc020"
global RotLeft := "sc033", RotRight := "sc034", RotUp := "sc149", RotDown := "sc151"
global ZoomIn := "sc017", ZoomOut := "sc018"
global SC_E := "sc012", SC_R := "sc013", SC_L := "sc026", SC_Esc := "sc001", SC_Enter := "sc01c"
global SC_Space := "sc039", SC_LShift := "sc02a", SC_Slash := "sc035", SC_1 := "sc002"
global TCFBKey := FwdKey, AFCFBKey := BackKey, TCLRKey := LeftKey, AFCLRKey := RightKey

; ---------- Etat global ----------
global Running := false, Paused := false, HiveConfirmed := 0
global windowX := 0, windowY := 0, windowWidth := 0, windowHeight := 0
global HiveSlot := 6, HiveBees := 50, MoveMethod := "Cannon", KeyDelay := 20
global HasteComp := 1, base_movespeed := 28, hasty_guard := 0, gifted_hasty := 0
global NightDetected := 0, InPath := false, StopReq := false
global Stats := Map("tokens", 0, "deaths", 0, "gather", 0, "convert", 0, "cycles", 0, "bugs", 0, "bosses", 0, "vb", 0
    , "collects", 0, "quests", 0, "disconnects", 0)
global StartTick := 0
global PineFast := 0, SprinklerType := "Supreme", SprinkKey := "sc002", DisableToolUse := 0, ShiftLockEnabled := 0
global sprinklerImages := ["saturator"]

class MacroStop extends Error {
}

ApplyGlobals() {
    global HiveSlot := Max(1, Min(6, Num(S["HiveSlot"], 6)))
    global HiveBees := Num(S["HiveBees"], 50)
    global MoveMethod := (S["MoveMethod"] = "Cannon") ? "Cannon" : "Walk"
    global KeyDelay := Num(S["KeyDelay"], 20)
    ; vitesse de base du compte ; la haste et les autres buffs sont lus a l'ecran en continu
    global base_movespeed := Max(5, Num(S["MoveSpeed"], 28)) * (1 + Num(S["SpeedCorr"]) / 100)
    global HasteComp := 1
    global hasty_guard := Num(S["HastyGuard"]), gifted_hasty := Num(S["GiftedHasty"])
    global SprinklerType := (S["SprinklerType"] = "None") ? "None" : S["SprinklerType"]
    global SprinkKey := Format("sc{:03x}", Num(S["SprinklerSlot"], 1) + 1)
    global PineFast := Num(S["PineFast"])
}

HyperSleep(ms) {
    static freq := (DllCall("QueryPerformanceFrequency", "Int64*", &f := 0), f)
    DllCall("QueryPerformanceCounter", "Int64*", &begin := 0)
    current := 0, finish := begin + ms * freq / 1000
    while (current < finish) {
        if StopReq   ; arret demande : on sort tout de suite
            throw MacroStop("stop")
        if ((finish - current) > 30000) {
            DllCall("Winmm.dll\timeBeginPeriod", "UInt", 1)
            DllCall("Sleep", "UInt", 1)
            DllCall("Winmm.dll\timeEndPeriod", "UInt", 1)
        }
        DllCall("QueryPerformanceCounter", "Int64*", &current)
    }
}

; enfonce 1 ou 2 touches et marche n cases (1 case = 4 studs), haste compris
bm_Walk(n, k1, k2 := "") {
    Send "{" k1 " down}" (k2 ? "{" k2 " down}" : "")
    Walk(n)
    Send "{" k1 " up}" (k2 ? "{" k2 " up}" : "")
}

; deplacement exprime en millisecondes a vitesse 18 (format des anciens chemins)
MoveMs(ms, k1, k2 := "") => bm_Walk(ms * 18 / 4000, k1, k2)

; marche jusqu'a n cases en tenant compte de la vitesse reelle (haste...),
; et s'arrete des que cond() est vrai. Renvoie true si cond() a ete vu.
WalkUntil(n, k1, k2, cond) {
    static freq := (DllCall("QueryPerformanceFrequency", "Int64*", &f := 0), f)
    Send "{" k1 " down}" (k2 ? "{" k2 " down}" : "")
    hit := false
    try {
        d := freq // 8, l := n * freq * 4
        v := DetectMovespeed(&s, &e)
        while (d < l) {
            if StopReq
                throw MacroStop("stop")
            if cond() {
                hit := true
                break
            }
            d += ((v + 0) + (v := DetectMovespeed(&s2, &e2))) / 2 * (e2 - e), e := e2
        }
    } finally
        Send "{" k1 " up}" (k2 ? "{" k2 " up}" : "")
    return hit
}

; tourne la camera de n crans (patterns Natro recents)
bm_cameraRotation(dir, n := 1) {
    Send "{" (dir = "left" ? RotLeft : RotRight) " " n "}"
}

Jump() {
    Send "{" SC_Space " down}"
    Sleep 100
    Send "{" SC_Space " up}"
}

ReleaseAll() {
    for k in [FwdKey, BackKey, LeftKey, RightKey, SC_Space, SC_LShift, SC_E]
        Send "{" k " up}"
    try Click "Up"
}

; arrete l'action en cours si la macro a ete stoppee
CheckStop() {
    if !Running || StopReq
        throw MacroStop("stop")
    while Paused   ; securite : on attend la fin de la pause
        Sleep 200
}

; ---------- Fenetre Roblox ----------
UpdateWindow() {
    global offsetY
    if !GetRobloxHWND()
        return false
    GetRobloxClientPos()
    offsetY := GetYOffset()
    return windowWidth > 0
}

SafeMouse() {
    if UpdateWindow()
        MouseMove windowX + 350, windowY + offsetY + 100
}

; cherche un bitmap dans une zone de l'ecran Roblox
FindBitmap(name, x, y, w, h, variation := 2, &pos?) {
    if !UpdateWindow() || !bitmaps.Has(name)
        return false
    pBM := Gdip_BitmapFromScreen(Round(windowX + x) "|" Round(windowY + y) "|" Round(w) "|" Round(h))
    found := (Gdip_ImageSearch(pBM, bitmaps[name], &p, , , , , variation, , 2) = 1)
    Gdip_DisposeImage(pBM)
    if found
        pos := StrSplit(p, ",")
    return found
}

; zone en haut au centre, la ou s'affichent les prompts "E"
TopBitmap(name, variation := 2) => UpdateWindow() && FindBitmap(name, windowWidth // 2 - 200, offsetY, 400, 125, variation)

; recherche d'une image png du dossier assets
bm_imgSearch(fileName, v, aim := "full", trans := "none") {
    if !UpdateWindow()
        return [3, 0, 0]
    xi := (aim = "actionbar") ? windowWidth // 4 : (aim = "highright") ? windowWidth // 2 : (aim = "right") ? windowWidth // 2 : (aim = "center") ? windowWidth // 4 : (aim = "lowright") ? windowWidth // 2 : 0
    yi := (aim = "low") ? windowHeight // 2 : (aim = "actionbar") ? (windowHeight // 4) * 3 : (aim = "center") ? windowHeight // 4 : (aim = "lowright") ? windowHeight // 2 : (aim = "quest") ? 150 : 0
    ww := (aim = "actionbar") ? xi * 3 : (aim = "highleft") ? windowWidth // 2 : (aim = "left") ? windowWidth // 2 : (aim = "center") ? xi * 3 : (aim = "quest" || aim = "questbrown") ? 310 : windowWidth
    wh := (aim = "high") ? windowHeight // 2 : (aim = "highright") ? windowHeight // 2 : (aim = "highleft") ? windowHeight // 2 : (aim = "buff") ? 150 : (aim = "abovebuff") ? 30 : (aim = "center") ? yi * 3 : (aim = "quest") ? Max(560, windowHeight - 100) : (aim = "questbrown") ? windowHeight // 2 : windowHeight
    try result := ImageSearch(&FoundX, &FoundY, windowX + xi, windowY + yi, windowX + ww, windowY + wh, "*" v ((trans != "none") ? (" *Trans" trans) : "") " " A_ScriptDir "\assets\" fileName)
    catch
        return [2, 0, 0]
    return (result = 1) ? [0, FoundX - windowX, FoundY - windowY] : [1, 0, 0]
}

ImgFound(fileName, v, aim := "full") => bm_imgSearch(fileName, v, aim)[1] = 0

Pack() => bm_backpackPercent()

AtHive() => TopBitmap("makehoney") || TopBitmap("collectpollen")

; appuie sur E si le prompt est visible
PressE(tries := 20) {
    Loop tries {
        if ImgFound("e_button.png", 30, "high") {
            Send "{" SC_E " down}"
            Sleep 100
            Send "{" SC_E " up}"
            return true
        }
        Sleep 100
    }
    return false
}

; ferme les dialogues de PNJ et les fenetres oui/non
ClearScreen() {
    if !UpdateWindow()
        return
    Loop 200 {
        pBM := Gdip_BitmapFromScreen(windowX + windowWidth // 2 - 50 "|" windowY + 2 * windowHeight // 3 "|100|" windowHeight // 3)
        if (Gdip_ImageSearch(pBM, bitmaps["dialog"], &pos, , , , , 10, , 3) != 1) {
            Gdip_DisposeImage(pBM)
            break
        }
        Gdip_DisposeImage(pBM)
        MouseMove windowX + windowWidth // 2, windowY + 2 * windowHeight // 3 + SubStr(pos, InStr(pos, ",") + 1) - 15
        Click
        Sleep 150
    }
    if FindBitmap("no", windowWidth // 2 - 250, windowHeight // 2 - 52, 500, 150, 2, &p) {
        MouseMove windowX + windowWidth // 2 - 250 + p[1], windowY + windowHeight // 2 - 52 + p[2]
        Click
    }
    r := bm_imgSearch("close.png", 30, "full")
    if (r[1] = 0) {
        MouseMove windowX + r[2], windowY + r[3]
        Click
        Sleep 500
    }
    SafeMouse()
}

; ---------- Reset et orientation a la ruche ----------
ResetChar(force := false) {
    global HiveConfirmed
    CheckStop()
    CheckDisconnect()
    ; deja devant sa ruche (retour a pied reussi) : pas besoin de reset
    if (!force && HiveConfirmed && AtHive()) {
        ReleaseAll()
        try bm_OpenMenu()
        Log("Already at the hive, no reset")
        return true
    }
    HiveConfirmed := 0
    global LastResetTick := A_TickCount   ; la mort causee par le reset n'est pas comptee
    SetStatus("Reset", "character")
    ActivateRoblox()
    ReleaseAll()
    try bm_OpenMenu()
    ClearScreen()
    Loop 4 {
        CheckStop()
        UpdateWindow()
        SafeMouse()
        SetKeyDelay 250 + KeyDelay
        Send "{" SC_Esc "}{" SC_R "}{" SC_Enter "}"
        SetKeyDelay KeyDelay
        ; on attend que la vie se vide puis revienne
        n := 0
        while ((n < 2) && (A_Index <= 80)) {
            Sleep 100
            UpdateWindow()
            pBM := Gdip_BitmapFromScreen(windowX "|" windowY "|" windowWidth "|50")
            n += (Gdip_ImageSearch(pBM, bitmaps["emptyhealth"], , , , , , 10) = (n = 0))
            Gdip_DisposeImage(pBM)
        }
        Sleep 1000 + Num(S["ResetWait"], 2) * 1000
        UpdateWindow()
        if bm_SetHiveCameraDirection(4)
            return true
        Log("Hive not seen after reset, retrying")
    }
    Send "{" ZoomOut " 5}"
    return false
}

bm_gotoramp() {
    bm_Walk(5, FwdKey)
    bm_Walk(9.2 * HiveSlot - 4, RightKey)
}

; saute sur la rampe et longe vers la droite jusqu'au canon rouge
bm_gotocannon() {
    Loop 6 {
        CheckStop()
        SafeMouse()
        Send "{" SC_Space " down}{" RightKey " down}"
        Sleep 100
        Send "{" SC_Space " up}"
        Walk(2)
        Send "{" FwdKey " down}"
        Walk(1.5)
        Send "{" FwdKey " up}"
        ; on longe la rampe vers la droite (distance adaptee a la vitesse reelle) jusqu'au canon
        found := WalkUntil(120, RightKey, "", () => TopBitmap("redcannon"))
        if found {
            Loop 10 {   ; on verifie qu'on n'a pas depasse le canon
                Sleep 500
                if TopBitmap("redcannon")
                    return true
                bm_Walk(1.5, LeftKey)
            }
        }
        Log("Cannon not found, retrying")
        ResetChar()
        bm_gotoramp()
    }
    throw Error("cannon not found")
}

; ---------- Chemins et patterns (fichiers des dossiers paths\ et patterns\) ----------
CallPath(name) {
    CheckStop()
    if !PATH_FILES.Has(name)
        throw Error("missing path: paths\" name ".ahk")
    ActivateRoblox()
    SafeMouse()
    try bm_setShiftLock(0)      ; les chemins se font sans shift lock
    Hook("On the way " PathLabel(name), LastStatus != "" ? "Goal: " LastStatus : "", "travel"
        , [["Movement", MoveMethod = "Cannon" ? "cannon" : "on foot"], ["Speed", Round(base_movespeed, 1)]], false, 2)
    global HiveConfirmed := 0   ; on quitte la ruche
    global InPath := true   ; les timers de fond attendent : les timings du canon restent exacts
    try (PATH_FILES[name])()
    finally
        InPath := false
}

; texte lisible pour un chemin (ex : "gtf-pinetree" -> "vers le champ Pine Tree")
PathLabel(name) {
    parts := StrSplit(name, "-", , 2)
    if (parts.Length < 2)
        return name
    key := parts[2], nice := key
    for f in FIELD_LIST
        if (FieldKey(f) = key)
            nice := f
    for c in COLLECT_LIST
        if (c[1] = key)
            nice := c[2]
    switch parts[1], 0 {
        case "gtf": return "to field " nice
        case "wf": return "to the hive (from " nice ")"
        case "gtc": return "to " nice
        case "gtq": return "to quest giver " StrTitle(key)
        case "gtb": return "to booster " key
    }
    return name
}

; ---------- detection de la mort du personnage ----------
global LastResetTick := 0, YouDied := 0
DeathTimer() {
    static lastDeath := 0
    if !Running || Paused || InPath || (A_TickCount - LastResetTick < 20000) || (A_TickCount - lastDeath < 15000)
        return
    if !UpdateWindow()
        return
    try found := ImageSearch(&fx, &fy, windowX + windowWidth // 2, windowY + windowHeight // 2, windowX + windowWidth, windowY + windowHeight, "*50 " A_ScriptDir "\assets\died.png")
    catch
        return
    if (found = 1) {
        lastDeath := A_TickCount
        global YouDied := 1
        Stats["deaths"]++
        Log("The character died!")
        Hook("Character died", "During: " (LastStatus != "" ? LastStatus : "?"), "death"
            , [["Deaths (session)", Stats["deaths"]], ["Bag", Pack() "%"]], true, 1)
    }
}

GoField(field) {
    SetStatus("Travel", field)
    CurrentField(field)
    CallPath("gtf-" FieldKey(field))
}

RunPattern(name, reps, size) {
    fn := PATTERN_FILES.Has(name) ? PATTERN_FILES[name] : PATTERN_FILES["Squares"]
    fn(reps, size, 0)
}

; apres un chemin de retour : longe les ruches vers la gauche jusqu'a la sienne
FindHive() {
    global HiveConfirmed
    SafeMouse()
    found := AtHive()
    if !found {
        ; on longe les 6 ruches vers la gauche (distance adaptee a la vitesse reelle) en guettant "Make Honey"
        found := WalkUntil(9.2 * 7, LeftKey, "", AtHive)
    }
    if found {
        ; on verifie qu'on ne l'a pas depassee (on revient un peu a droite si besoin)
        Loop 10 {
            Sleep 400
            if AtHive() {
                HiveConfirmed := 1
                Log("Hive found on foot")
                return true
            }
            bm_Walk(1.5, RightKey)
        }
    }
    Log("Hive not found on foot ('Make Honey' not seen) -> reset")
    ResetChar(true)
    return false
}

; ---------- ruche automatique : retrouve sa ruche et son slot sans reglage ----------
; reset -> on reapparait devant SA ruche. Si ce n'est pas le cas (nouveau serveur, ruche perdue),
; on en reprend une. Sinon on va au bout de la rangee (cote rampe) et on revient ruche par ruche
; jusqu'a revoir "Make Honey" : le nombre de ruches passees donne le slot.
DetectHive() {
    global HiveConfirmed
    SetStatus("Hive", "looking for your hive")
    ResetChar(true)
    Sleep 600
    if !AtHive() {
        Log("Not at a hive after reset: claiming one")
        if !ClaimHive()
            return false
        ResetChar(true)
        Sleep 600
    }
    bm_Walk(5, FwdKey)
    bm_Walk(9.2 * 6 + 6, RightKey)   ; bloque au bout de la rangee, quel que soit le slot
    bm_Walk(5, BackKey)
    slot := 0
    Loop 6 {
        bm_Walk(A_Index = 1 ? 5.2 : 9.2, LeftKey)
        Sleep 350
        if AtHive() {
            slot := A_Index
            break
        }
    }
    if !slot {
        Log("Hive slot not found, keeping slot " HiveSlot)
        ResetChar(true)
        return false
    }
    HiveConfirmed := 1
    if (slot != HiveSlot) {
        SaveSetting("HiveSlot", slot)
        ApplyGlobals()
        try RefreshControl("HiveSlot")
    }
    SetStatus("Hive", "slot " slot " detected")
    Hook("Hive detected", "Your hive is in slot " slot ".", "good", "", false, 2)
    return true
}

; ---------- conversion a la ruche (sac puis ballon), fin detectee ----------
; etat de l'ecran pendant la conversion : prompt E present ? "Make Honey" ? ballon rafraichi ?
ConvState() {
    st := {e: false, make: false, balloon: false}
    if !UpdateWindow()
        return st
    pBM := Gdip_BitmapFromScreen(windowX + windowWidth // 2 - 200 "|" windowY + offsetY + 36 "|" windowWidth // 2 + 200 "|" windowHeight - offsetY - 36)
    st.e := (Gdip_ImageSearch(pBM, bitmaps["e_button"], , , , 400, 120, 2, , 6) = 1)
    st.make := (Gdip_ImageSearch(pBM, bitmaps["makehoney"], , , , 400, 120, 2, , 2) = 1)
    st.balloon := (Gdip_ImageSearch(pBM, bitmaps["hiveballoon"], , windowWidth // 2, windowHeight - offsetY - 36 - 400, , , 40, , 3) = 1)
    Gdip_DisposeImage(pBM)
    return st
}

PressMakeHoney() {
    Send "{" SC_E " down}"
    Sleep 100
    Send "{" SC_E " up}"
}

ConvertHoney() {
    CheckStop()
    t := A_TickCount, bagStart := Pack(), balloonDone := false, bagMs := 0, balloonMs := 0
    st := ConvState()
    if !st.e && (bagStart = 0) {
        Log("Empty bag and no hive prompt: nothing to convert")
        return
    }
    if st.make
        PressMakeHoney()
    ; 1) on vide le sac
    if (bagStart > 0) {
        SetStatus("Conversion", "bag (" bagStart "%)")
        zero := 0
        while (A_TickCount - t < Num(S["ConvertMax"], 300) * 1000) {
            CheckStop()
            Sleep 1000
            CheckBoosts("hive")
            st := ConvState()
            if st.make
                PressMakeHoney()   ; la conversion s'est arretee : on la relance
            if st.balloon {
                balloonDone := true   ; le ballon a deja ete converti en meme temps
                break
            }
            if !st.e
                break               ; plus de prompt : on n'est plus en train de convertir
            zero := (Pack() = 0) ? zero + 1 : 0
            if (zero >= 3)
                break
            if (Mod(A_Index, 15) = 0 && CheckDisconnect())
                return
        }
        bagMs := A_TickCount - t
        Log("Bag empty in " Dur(bagMs))
    }
    ; 2) le ballon de la ruche (si active)
    every := Num(S["BalloonMins"]) * 60
    if S["Balloon"] && !balloonDone && (every = 0 || Now() - GetTime("balloon") >= every) {
        SetStatus("Conversion", "hive balloon")
        b := A_TickCount
        while (A_TickCount - b < 600000) {   ; 10 min max
            CheckStop()
            st := ConvState()
            if st.make
                PressMakeHoney()
            if st.balloon || !st.e {
                balloonDone := st.balloon
                break
            }
            if (Mod(A_Index, 30) = 0) {   ; clic pour garder le jeu actif
                MouseMove windowX + windowWidth - 30, windowY + offsetY + 16
                Click
                SafeMouse()
            }
            if (Mod(A_Index, 15) = 0 && CheckDisconnect())
                return
            CheckBoosts("hive")
            Sleep 1000
        }
        balloonMs := A_TickCount - b
        if balloonDone
            SetTime("balloon")
        Log(balloonDone ? "Balloon converted in " Dur(balloonMs) : "Balloon: end of conversion not detected")
    }
    if (extra := Num(S["ConvertExtra"]))
        Sleep extra * 1000
    Stats["convert"] += A_TickCount - t
    Hook("Conversion done", "", "honey", [["Starting bag", bagStart "%"], ["Time (bag)", Dur(bagMs)]
        , ["Balloon", balloonDone ? "converted (" Dur(balloonMs) ")" : (S["Balloon"] ? "not this time" : "desactive")]
        , ["Total conversion", Dur(Stats["convert"])]], true, 2)
}

; ---------- Barre d'objets (touches 2 a 7) ----------
CheckBoosts(ctx) {
    static last := Map()
    Loop 6 {
        i := A_Index + 1, mode := S["B" i "_Mode"]
        if (mode = "Never") || (mode = "In field" && ctx != "field") || (mode = "At hive" && ctx != "hive")
            continue
        if !last.Has(i) || (A_TickCount - last[i] >= Num(S["B" i "_Int"], 60) * 1000) {
            Send "{" Format("sc{:03x}", i + 1) "}"
            last[i] := A_TickCount
            Sleep 100
        }
    }
}

; ---------- Detection de la nuit (pour la Vicious Bee) ----------
NightTimer() {
    static confidence := 0
    if !Running || Paused || InPath || !S["VB_Enable"] || !UpdateWindow()
        return
    if CheckTimeBitmap("day")
        confidence := 0
    else if CheckTimeBitmap("night") {
        if (++confidence >= 6) {
            confidence := 0
            if !NightDetected {
                global NightDetected := Now()
                Log("Night detected")
                Hook("Night detected", "The macro will look for the Vicious Bee in the selected fields.", "vb", "", false, 2)
            }
        }
    } else if (confidence > 1)
        confidence -= 2

    CheckTimeBitmap(time) {
        pBM := Gdip_BitmapFromScreen(windowX "|" windowY + windowHeight // 2 "|" windowWidth "|" windowHeight // 2)
        for , v in bitmaps[time]
            if (Gdip_ImageSearch(pBM, v, , , , , , 4) = 1) {
                Gdip_DisposeImage(pBM)
                return 1
            }
        Gdip_DisposeImage(pBM)
        return 0
    }
}

; la Vicious Bee doit-elle interrompre ce qu'on fait ?
VBReady() {
    if !S["VB_Enable"] || !NightDetected
        return false
    if (Now() - NightDetected > 600) {   ; nuit trop ancienne
        global NightDetected := 0
        return false
    }
    return !(S["VB_Daily"] && Now() - GetTime("vb_kill") < 79200)
}
