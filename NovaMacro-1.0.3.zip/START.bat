@echo off
cd /d "%~dp0"
start "" "%~dp0AutoHotkey64.exe" "%~dp0Loader.ahk"
