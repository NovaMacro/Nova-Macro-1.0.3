﻿if (HiveBees > 25) {
    bm_gotoramp()
    Send "{space down}{" RightKey " down}"
    Sleep 100
    Send "{space up}"
    Walk(2)
    Send "{" FwdKey " down}"
    Walk(1.8)
    Send "{" FwdKey " up}"
    Walk(30)
    send "{" RightKey " up}{space down}"
    HyperSleep(300)
    send "{space up}"
    bm_Walk(6, RightKey)
    HyperSleep(500)
    send "{" RotRight " 2}"
    send "{space down}"
    HyperSleep(100)
    send "{space up}"
    bm_Walk(3, FwdKey)
    HyperSleep(1000)
    send "{space down}{" RightKey " down}"
    HyperSleep(100)
    send "{space up}"
    HyperSleep(300)
    send "{space}{" RightKey " up}"
    HyperSleep(1000)
    bm_Walk(7.5, Backkey, RightKey)
}
else {
    bm_gotoramp()
	bm_Walk(67.5, BackKey, LeftKey)
	send "{" RotRight " 4}"
	bm_Walk(31.5, FwdKey)
	bm_Walk(9, LeftKey)
	bm_Walk(9, BackKey)
	bm_Walk(58.5, LeftKey)
	bm_Walk(49.5, FwdKey)
	bm_Walk(20.25, LeftKey)
	send "{" RotRight " 4}"
	bm_Walk(60.75, FwdKey)
	send "{" RotRight " 2}"
	bm_Walk(9, BackKey)
	bm_Walk(15.75, BackKey, RightKey)
	bm_Walk(30, LeftKey)
	bm_Walk(36, FwdKey)
	bm_Walk(28, LeftKey)
	bm_Walk(5, RightKey)
	bm_Walk(3.5, BackKey)
	bm_Walk(23.5, LeftKey)
	bm_Walk(3, BackKey)
	bm_Walk(10, RightKey)
	bm_Walk(3, LeftKey)
	bm_Walk(8, BackKey)
}
;dual path 230629 noobyguy
