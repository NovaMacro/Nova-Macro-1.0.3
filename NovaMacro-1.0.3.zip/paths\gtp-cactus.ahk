﻿if (MoveMethod = "walk")
{
    bm_gotoramp()
    bm_Walk(67.5, BackKey, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(31, FwdKey)
    bm_Walk(7.8, LeftKey)
    bm_Walk(10, BackKey)
    bm_Walk(5, RightKey)
    bm_Walk(1.5, FwdKey)
    bm_Walk(60, LeftKey)
    bm_Walk(49.5, FwdKey)
    bm_Walk(40, RightKey)
    bm_Walk(5, BackKey)
    bm_Walk(3, LeftKey)
}
else {
    bm_gotoramp()
    bm_gotocannon()
    send "{e down}"
    HyperSleep(100)
    send "{e up}{" RightKey " down}{" BackKey " down}"
    HyperSleep(890)
    send "{space 2}"
    HyperSleep(2500)
    send "{" RightKey " up}"
    HyperSleep(1100)
    send "{" BackKey " up}{space}{" RotLeft " 4}"
    HyperSleep(600)
    bm_Walk(20, FwdKey, RightKey)
    bm_Walk(15, RightKey)
    bm_Walk(30, BackKey)
    bm_Walk(3, LeftKey)
}
;path 230729 noobyguy
; edited by Lorddrak