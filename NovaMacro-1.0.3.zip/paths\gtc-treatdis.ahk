﻿if (MoveMethod = "walk")
{
	bm_gotoramp()
	bm_Walk(67.5, BackKey, LeftKey)
	send "{" RotRight " 4}"
	bm_Walk(30, FwdKey)
	bm_Walk(20, FwdKey, RightKey)
	send "{" RotRight " 2}"
	bm_Walk(43.5, FwdKey)
	bm_Walk(16, RightKey)
	send "{" FwdKey " down}"
	HyperSleep(200)
	send "{space down}"
	HyperSleep(100)
	send "{space up}"
	HyperSleep(800)
	send "{" FwdKey " up}{" RotLeft " 2}"
	bm_Walk(29.25, FwdKey)
	bm_Walk(17, FwdKey, LeftKey)
	bm_Walk(3, FwdKey)
}
else
{
	bm_gotoramp()
	bm_gotocannon()
	send "{e down}"
	HyperSleep(100)
	send "{e up}{" LeftKey " down}"
	HyperSleep(1810)
	send "{space 2}"
	HyperSleep(1925)
	send "{" LeftKey " up}{space}{" RotRight " 4}"
	Sleep 1500
}
;path 230630 noobyguy - walk updated
