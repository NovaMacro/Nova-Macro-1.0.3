﻿If (!PineFast || (HiveBees < 25) || (MoveMethod = "Walk")) {   ; retour rapide (canon + planeur) seulement si active dans Farm > Conversion
	bm_Walk(31, FwdKey)
	bm_Walk(75, RightKey)
	send "{" RotLeft " 4}"
	Sleep(50)
	bm_Walk(20, FwdKey)
	bm_Walk(3, FwdKey, LeftKey)
	bm_Walk(18, FwdKey)
	bm_Walk(6, FwdKey, RightKey)
	bm_Walk(10, RightKey)
	bm_Walk(2, LeftKey)
	send "{" FwdKey " down}"
	Walk(6)
	send "{" SC_Space " down}"
	HyperSleep(200)
	send "{" SC_Space " up}"
	Walk(108)
	send "{" FwdKey " up}"

	switch HiveSlot
		{
		case 3:
		bm_Walk(2.7, BackKey) ;center on hive pad 3

		default:
		bm_Walk(1.5, BackKey) ;walk backwards to avoid thicker hives
		bm_Walk(35, RightKey) ;walk to ramp
		bm_Walk(2.7, BackKey) ;center with hive pads
		}
	}
else {
	bm_Walk(30, FwdKey)
	bm_Walk(25, LeftKey)
	bm_Walk(2, FwdKey)
	bm_Walk(30, BackKey)
	bm_Walk(23, BackKey, RightKey)
	bm_Walk(7, BackKey)
	bm_Walk(5, RightKey)
	bm_Walk(12, BackKey)
	SendInput "{" SC_Space " down}"
	Sleep(100)
	SendInput "{" SC_Space " up}"
	bm_Walk(9.5, BackKey)
	bm_Walk(4, RightKey)
	HyperSleep(200)

	; cannon
	SetKeyDelay 150+A_KeyDelay
	send "{" SC_LShift "}"
	loop 4
		send("{" RotRight "}"), Sleep(50)
	SetKeyDelay A_KeyDelay
	sleep(100)
	send("{" SC_E " down}"), HyperSleep(10)
	send("{" SC_E " up}"), HyperSleep(10)

	; glider
	loop 2
		send("{" SC_Space " down}"), HyperSleep(200), send("{" SC_Space " up}"), HyperSleep(200)
	Sleep(3800)
	send("{" SC_Space " down}"), hypersleep(100)
	send("{" SC_Space " up}"), sleep(500)

	send "{" SC_LShift "}"
	; hive
	bm_Walk(3.3, BackKey)
	bm_Walk(3, RightKey)
	bm_Walk(1, FwdKey)
	bm_Walk(32, RightKey)
	bm_Walk(5, FwdKey)
	bm_Walk(4, BackKey)
}

;added MoveMethod condition to no-glider option misc 181123
;slightly altered tile measurements and optimised glider deployment SP 230405
;path with and without glider zaappiix 230212
; [2024-01-15/rpertusio] Avoid using corner (Hive 1 and ramp) where character gets stuck after 2024-01-12 BSS update - deleted on new path
; [2024-01-15/rpertusio] Aligns with default SpawnLocation, saves walking if player chose Hive 3 - deleted on new path

; fast cannon path by Lorddrak
; ty dully for keydelay idea