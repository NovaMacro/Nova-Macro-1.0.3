﻿; =====================================================================
;  Reglages : valeurs par defaut, lecture et sauvegarde (settings.ini)
; =====================================================================

global CFG_FILE := A_ScriptDir "\settings.ini"

global FIELD_LIST := ["Sunflower", "Dandelion", "Mushroom", "Blue Flower", "Clover", "Strawberry", "Spider", "Bamboo"
    , "Pineapple", "Stump", "Cactus", "Pumpkin", "Pine Tree", "Rose", "Mountain Top", "Pepper", "Coconut"]
global SIZE_LIST := ["XS", "S", "M", "L", "XL"], SIZE_VAL := Map("XS", 0.25, "S", 0.5, "M", 1, "L", 1.5, "XL", 2)

; [cle, nom, cooldown en secondes, categorie]  (cle = chemin paths\gtc-<cle>.ahk et icone assets\icons\collect\<cle>.png)
global COLLECT_LIST := [["clock", "Wealth Clock", 3600, "Items"], ["honeydis", "Honey Dispenser", 3600, "Dispensers"]
    , ["treatdis", "Treat Dispenser", 3600, "Dispensers"], ["blueberrydis", "Blueberry Dispenser", 14400, "Dispensers"]
    , ["strawberrydis", "Strawberry Dispenser", 14400, "Dispensers"], ["coconutdis", "Coconut Dispenser", 14400, "Dispensers"]
    , ["royaljellydis", "Royal Jelly Dispenser", 79200, "Dispensers"], ["gluedis", "Glue Dispenser", 79200, "Dispensers"]
    , ["antpass", "Ant Pass", 7200, "Passes"], ["robopass", "Robo Pass", 79200, "Passes"], ["honeystorm", "Honeystorm", 14400, "Items"]]

; Memory Match ; [cle, nom, cooldown (s), chemin]
global MM_LIST := [["Normal", "Memory Match", 7200, "normalmm"], ["Mega", "Mega Memory Match", 14400, "megamm"]
    , ["Extreme", "Extreme Memory Match", 28800, "extrememm"], ["Night", "Night Memory Match", 28800, "nightmm"]]

; [cle, nom, champs, respawn (s), duree du kill (s)]
global MOB_LIST := [["Ladybugs", "Ladybugs", ["Strawberry", "Mushroom", "Clover"], 330, 15]
    , ["RhinoBeetles", "Rhino Beetles", ["Blue Flower", "Clover", "Bamboo"], 330, 20]
    , ["Spider", "Spider", ["Spider"], 1830, 30]
    , ["Mantis", "Mantis", ["Pineapple", "Pine Tree"], 1230, 25]
    , ["Scorpions", "Scorpions", ["Rose"], 1230, 25]
    , ["Werewolf", "Werewolf", ["Pumpkin"], 3600, 40]]

; [cle, nom, respawn (s)]
global BOSS_LIST := [["King", "King Beetle", 86400], ["Tunnel", "Tunnel Bear", 172800], ["Snail", "Stump Snail", 345600]
    , ["Crab", "Coco Crab", 129600], ["Commando", "Commando Chick", 1800]]

; champs ou chercher la Vicious Bee la nuit
global VB_FIELDS := ["Pepper", "Mountain Top", "Rose", "Cactus", "Spider", "Clover"]

global QUEST_LIST := [["Polar", "Polar Bear"], ["Black", "Black Bear"], ["Brown", "Brown Bear"]
    , ["Bucko", "Bucko Bee"], ["Riley", "Riley Bee"], ["Honey", "Honey Bee"]]

; tokens du Farm IA : [cle (= image assets	okens\<cle>.png, <cle>_2.png...), nom affiche, priorite par defaut]
global TOKEN_LIST := [["Haste", "Haste", 10], ["Focus", "Focus", 9], ["Inspire", "Inspire", 9], ["BoostRed", "Red Boost", 8]
    , ["BoostBlue", "Blue Boost", 8], ["BoostWhite", "White Boost", 8], ["Link", "Token Link", 8], ["Melody", "Melody", 7]
    , ["Inflate", "Inflate Balloons", 7], ["Frogs", "Summon Frog", 7], ["BabyLove", "Baby Love", 7], ["TabbyLove", "Tabby Love", 7]
    , ["PuppyLove", "Puppy Love", 6], ["PartyBalloons", "Surprise Party", 6], ["EcoBalloon", "Eco Balloon", 5], ["Bomb", "Bomb", 6]
    , ["BombBlue", "Blue Bomb", 5], ["BombRed", "Red Bomb", 5], ["FuzzBombs", "Fuzz Bombs", 5], ["Mark", "Mark", 6]
    , ["HoneyMark", "Honey Mark", 5], ["PollenMark", "Pollen Mark", 5], ["MarkSurge", "Mark Surge", 6], ["RedSync", "Red Sync", 6]
    , ["Sync", "Blue Sync", 6], ["Rage", "Rage", 6], ["Impale", "Impale", 5], ["Triangulate", "Triangulate", 6]
    , ["Inferno", "Inferno", 6], ["Tornado", "Tornado", 5], ["PhotonBeam", "Photon Beam", 5], ["Gumdrop", "Gumdrop Barrage", 5]
    , ["Pulse", "Pulse", 5], ["TabbyScratch", "Tabby Scratch", 5], ["Glitch", "Glitch", 5], ["Glob", "Glob", 5]
    , ["Smile", "Smile", 4], ["RainCloud", "Rain Cloud", 4], ["PollenHaze", "Pollen Haze", 4], ["Fetch", "Fetch", 4]
    , ["FlameFuel", "Flame Fuel", 4], ["TargetPractice", "Target Practice", 4], ["MapCorruption", "Map Corruption", 4]
    , ["MindHack", "Mind Hack", 4]
    ; loot : objets qui tombent dans les champs
    , ["Honey", "Honey", 3], ["Treat", "Treat", 3], ["Strawberry", "Strawberry", 2], ["Blueberry", "Blueberry", 2]
    , ["Pineapple", "Pineapple", 2], ["SunflowerSeed", "Sunflower Seed", 2], ["RoyalJelly", "Royal Jelly", 5], ["StarJelly", "Star Jelly", 6]
    , ["Ticket", "Ticket", 4], ["Gumdrops", "Gumdrops", 3], ["Glitter", "Glitter", 4], ["Glue", "Glue", 3], ["Oil", "Oil", 3]
    , ["Enzymes", "Enzymes", 3], ["RedExtract", "Red Extract", 3], ["BlueExtract", "Blue Extract", 3], ["TropicalDrink", "Tropical Drink", 3]
    , ["MoonCharm", "Moon Charm", 3], ["FieldDice", "Field Dice", 3], ["SmoothDice", "Smooth Dice", 4], ["LoadedDice", "Loaded Dice", 4]
    , ["SoftWax", "Soft Wax", 3]]

; type de chaque token : R = abeilles rouges, B = bleues, W = blanches, L = loot (objets),
; absent = autre (Haste, Focus, Melody, Bomb, Mark... utiles a toutes les ruches)
global TOKEN_CAT := MakeTokenCat()
MakeTokenCat() {
    m := Map()
    for k in ["BoostRed", "RedSync", "BombRed", "Rage", "Impale", "Inferno", "FlameFuel", "TargetPractice"]
        m[k] := "R"
    for k in ["BoostBlue", "BombBlue", "Sync", "Pulse", "Inflate", "Frogs"]
        m[k] := "B"
    for k in ["BoostWhite", "TabbyLove", "TabbyScratch", "PuppyLove", "BabyLove", "Fetch", "Tornado", "RainCloud", "PhotonBeam"
        , "FuzzBombs", "PollenHaze", "Triangulate", "MarkSurge"]
        m[k] := "W"
    for k in ["Honey", "Treat", "Strawberry", "Blueberry", "Pineapple", "SunflowerSeed", "RoyalJelly", "StarJelly", "Ticket", "Gumdrops"
        , "Glitter", "Glue", "Oil", "Enzymes", "RedExtract", "BlueExtract", "TropicalDrink", "MoonCharm", "FieldDice", "SmoothDice"
        , "LoadedDice", "SoftWax"]
        m[k] := "L"
    return m
}
TokenCat(key) => TOKEN_CAT.Has(key) ? TOKEN_CAT[key] : "O"
global HIVE_LIST := ["Blue", "Red", "White", "Mixed"]

; un token est-il utile pour cette ruche ? (blancs, autres et loot : toutes les ruches ; mixte = tout)
HiveHas(hive, key) {
    c := TokenCat(key)
    return (c != "R" && c != "B") || (hive = "Mixed") || (hive = "Blue" && c = "B") || (hive = "Red" && c = "R")
}

; ordre de priorite selon la couleur de la ruche (le 1er = priorite 10, les autres tokens de la ruche = 1)
global HIVE_PRESETS := Map(
    "Blue", ["BoostWhite", "Inflate", "Frogs", "TabbyLove", "PartyBalloons", "Inspire", "Haste", "Bomb", "Mark", "FuzzBombs", "Focus", "Honey"],
    "Red", ["Haste", "RedSync", "Triangulate", "MarkSurge", "Rage", "Bomb", "Mark", "FuzzBombs", "BoostRed", "Focus", "Honey", "Impale"],
    "White", ["Inspire", "Focus", "Haste", "BoostWhite", "TabbyLove", "BabyLove", "PuppyLove", "Melody", "FuzzBombs", "PollenHaze"
        , "Triangulate", "MarkSurge", "Tornado", "PhotonBeam", "Bomb", "Mark", "Honey"],
    "Mixed", ["Focus", "Inspire", "Haste", "BabyLove", "TabbyLove", "EcoBalloon", "Frogs", "Sync", "TabbyScratch", "BoostBlue", "Gumdrop"
        , "Pulse", "Inferno", "Triangulate", "Bomb", "Tornado", "PhotonBeam", "Mark", "MarkSurge", "FuzzBombs"])

; applique l'ordre de priorite d'une couleur de ruche ; les tokens d'une autre couleur sont ignores (0)
ApplyHivePreset(hive) {
    if !HIVE_PRESETS.Has(hive)
        return
    list := HIVE_PRESETS[hive], rank := Map()
    for i, k in list
        rank[k] := i
    for tk in TOKEN_LIST
        if (TokenCat(tk[1]) != "L")   ; le loot garde ses priorites
            SaveSetting("AI_P_" tk[1], !HiveHas(hive, tk[1]) ? 0 : rank.Has(tk[1]) ? 10 - (rank[tk[1]] - 1) * 8 // list.Length : 1)
    SaveSetting("AI_Hive", hive)
}

; abeilles pour le Hive Check : [cle, nom, couleur, rarete]
global BEE_LIST := [["Basic", "Basic", "White", "Common"]
    , ["Bomber", "Bomber", "White", "Rare"], ["Brave", "Brave", "White", "Rare"], ["Bumble", "Bumble", "Blue", "Rare"], ["Cool", "Cool", "Blue", "Rare"]
    , ["Hasty", "Hasty", "White", "Rare"], ["Looker", "Looker", "White", "Rare"], ["Rad", "Rad", "Red", "Rare"], ["Rascal", "Rascal", "Red", "Rare"]
    , ["Stubborn", "Stubborn", "White", "Rare"]
    , ["Bubble", "Bubble", "Blue", "Epic"], ["Bucko", "Bucko", "Blue", "Epic"], ["Commander", "Commander", "White", "Epic"], ["Demo", "Demo", "Red", "Epic"]
    , ["Exhausted", "Exhausted", "White", "Epic"], ["Fire", "Fire", "Red", "Epic"], ["Frosty", "Frosty", "Blue", "Epic"], ["Honey", "Honey", "White", "Epic"]
    , ["Rage", "Rage", "Red", "Epic"], ["Riley", "Riley", "Red", "Epic"], ["Shocked", "Shocked", "White", "Epic"]
    , ["Baby", "Baby", "White", "Legendary"], ["Carpenter", "Carpenter", "White", "Legendary"], ["Demon", "Demon", "Red", "Legendary"]
    , ["Diamond", "Diamond", "Blue", "Legendary"], ["Lion", "Lion", "White", "Legendary"], ["Music", "Music", "White", "Legendary"]
    , ["Ninja", "Ninja", "Blue", "Legendary"], ["Shy", "Shy", "Red", "Legendary"]
    , ["Buoyant", "Buoyant", "Blue", "Mythic"], ["Fuzzy", "Fuzzy", "White", "Mythic"], ["Precise", "Precise", "Red", "Mythic"]
    , ["Spicy", "Spicy", "Red", "Mythic"], ["Tadpole", "Tadpole", "Blue", "Mythic"], ["Vector", "Vector", "White", "Mythic"]
    , ["Bear", "Bear", "White", "Event"], ["Cobalt", "Cobalt", "Blue", "Event"], ["Crimson", "Crimson", "Red", "Event"], ["Digital", "Digital", "White", "Event"], ["Festive", "Festive", "Red", "Event"]
    , ["Gummy", "Gummy", "White", "Event"], ["Photon", "Photon", "White", "Event"], ["Puppy", "Puppy", "White", "Event"]
    , ["Tabby", "Tabby", "White", "Event"], ["Vicious", "Vicious", "Blue", "Event"], ["Windy", "Windy", "White", "Event"]]

global BOOST_MODES := ["Never", "Always", "In field", "At hive"]

global DEF := Map(
    ; personnage
    "MoveSpeed", 28, "SpeedCap", 40, "SpeedCorr", 0, "HasteComp", 1, "HastyGuard", 0, "GiftedHasty", 0,
    "MoveMethod", "Cannon", "HiveSlot", 6, "HiveBees", 50, "SprinklerSlot", 1, "SprinklerType", "Supreme", "KeyDelay", 20,
    "ResetWait", 2, "ConvertMax", 300, "ConvertExtra", 0, "Balloon", 0, "BalloonMins", 0, "PineFast", 0,
    ; boss
    "SnailMins", 0, "ChickMins", 10, "Amulet", "Keep",
    "VB_Enable", 0, "VB_Daily", 0,
    ; quetes
    "Q_GatherMins", 5,
    ; reconnexion
    "R_Enable", 1, "R_Link", "", "R_Hours", 0, "R_Public", 1,
    ; discord
    "D_Enable", 0, "D_Webhook", "", "D_UserID", "", "D_Shots", 1, "D_Hourly", 1, "D_Ping", 1, "D_Level", "Important", "D_Live", 1, "D_LiveEvery", "1.5 s",
    ; interface
    "UI_Accent", "Nova", "UI_OnTop", 0, "UI_Theme", "Dark",
    ; raccourcis
    "HK_Start", "F1", "HK_Pause", "F2", "HK_Stop", "F3",
    ; Hive Check (Tools)
    "HC_Hive", "Blue", "HC_Bees", 25, "HC_Field", "Pine Tree",
    ; ruche : slot detecte tout seul
    "HiveAuto", 1,
    ; divers
    "M_GatherOff", 0, "M_Diag", 1, "U_Check", 1,
    ; boosters de champ
    "BO_blue", 0, "BO_red", 0, "BO_mountain", 0,
    ; farm IA
    "AI_FPS", 15, "AI_Capture", "Screen", "AI_Var", 45, "AI_Zone", 80, "AI_PlayerY", 55, "AI_Leash", 10, "AI_Reach", 30,
    "AI_Home", 20, "AI_Chase", 4, "AI_Wander", 1, "AI_WanderTiles", 2, "AI_Screen", "Roblox window", "AI_Res", "50%",
    "AI_Hive", "Mixed", "AI_Overlay", 0, "AI_Loot", 0, "AI_Eco", 1, "AI_TokSize", 42, "AI_Match", 70, "AI_Stay", 1, "AI_Cam", 1, "AI_CamEvery", 4
)
global S := LoadSettings()

LoadSettings() {
    Loop 3 {
        p := "F" A_Index "_"
        for k, v in Map("Field", "None", "Pattern", "Squares", "Size", "M", "Width", 3,
            "InvFB", 0, "InvLR", 0, "RotDir", "None", "RotCount", 1, "Mins", 15, "Pack", 95, "Return", "Walk", "Sprinkler", 1,
            "SprLoc", "Center", "SprDist", 10, "Drift", 0, "Shift", 0, "AI", 0)
            DEF[p k] := v
    }
    for c in COLLECT_LIST
        DEF["C_" c[1]] := 0
    for m in MOB_LIST
        DEF["K_" m[1]] := 0
    for b in BOSS_LIST
        DEF["B_" b[1]] := 0
    for f in VB_FIELDS
        DEF["VB_" StrReplace(f, " ")] := 1
    for q in QUEST_LIST
        DEF["Q_" q[1]] := 0
    for tk in TOKEN_LIST
        DEF["AI_P_" tk[1]] := tk[3]
    for g in MM_LIST
        DEF["MM_" g[1]] := 0
    for b in BEE_LIST
        DEF["HC_B_" b[1]] := "-"
    Loop 6
        DEF["B" (A_Index + 1) "_Item"] := "None"
    Loop 6
        DEF["B" (A_Index + 1) "_Mode"] := "Never", DEF["B" (A_Index + 1) "_Int"] := 60
    settings := Map()
    for k, v in DEF {
        val := IniRead(CFG_FILE, "cfg", k, v)
        if ((nv := MigrateValue(k, val)) != val)   ; reglage enregistre par une ancienne version (en francais)
            IniWrite(nv, CFG_FILE, "cfg", k), val := nv
        settings[k] := val
    }
    ; ancien preset "Defaut" -> "Default"
    if FileExist(A_ScriptDir "\presets\Defaut.ini") && !FileExist(A_ScriptDir "\presets\Default.ini")
        try FileMove A_ScriptDir "\presets\Defaut.ini", A_ScriptDir "\presets\Default.ini"
    if (IniRead(CFG_FILE, "state", "preset", "") = "Defaut")
        IniWrite "Default", CFG_FILE, "state", "preset"
    return settings
}

; valeurs des anciennes versions (francais) -> valeurs actuelles (anglais), seulement pour les listes de choix
MigrateValue(k, v) {
    static common := Map("Aucun", "None", "Aucune", "None")
    static lists := Map(
        "Return", Map("Marcher", "Walk"), "MoveMethod", Map("Canon", "Cannon", "Marche", "Walk"),
        "RotDir", Map("Gauche", "Left", "Droite", "Right"),
        "SprLoc", Map("Centre", "Center", "Haut gauche", "Upper Left", "Haut", "Upper", "Haut droite", "Upper Right", "Droite", "Right"
            , "Bas droite", "Lower Right", "Bas", "Lower", "Bas gauche", "Lower Left", "Gauche", "Left"),
        "Mode", Map("Jamais", "Never", "Toujours", "Always", "Au champ", "In field", "A la ruche", "At hive"),
        "Amulet", Map("Garder", "Keep", "Remplacer", "Replace"), "AI_Capture", Map("Ecran", "Screen", "Fenetre", "Window"),
        "AI_Screen", Map("Fenetre Roblox", "Roblox window"), "AI_Hive", Map("Bleue", "Blue", "Rouge", "Red", "Blanche", "White", "Mixte", "Mixed"),
        "UI_Theme", Map("Sombre", "Dark", "Noir", "Black", "Ardoise", "Slate", "Nuit bleue", "Midnight", "Foret", "Forest"),
        "UI_Accent", Map("Bleu", "Blue", "Miel", "Honey", "Violet", "Purple", "Vert", "Green", "Rose", "Pink"),
        "D_Level", Map("Tout", "All", "Essentiel", "Essential"))
    if common.Has(v)
        return common[v]
    kind := RegExReplace(k, "^(F\d_|B\d_)")
    return (lists.Has(kind) && lists[kind].Has(v)) ? lists[kind][v] : v
}

Num(v, d := 0) => IsNumber(v) ? v + 0 : d
Now() => DateDiff(A_NowUTC, "19700101", "Seconds")
GetTime(k) => Num(IniRead(CFG_FILE, "time", k, 0))
SetTime(k, t?) => IniWrite(IsSet(t) ? t : Now(), CFG_FILE, "time", k)
GetState(k, d := "") => IniRead(CFG_FILE, "state", k, d)
SetState(k, v) => IniWrite(v, CFG_FILE, "state", k)
SaveSetting(k, v) {
    S[k] := v
    IniWrite v, CFG_FILE, "cfg", k
    if ACCOUNT_KEYS.Has(k)   ; reglage lie au compte : on met aussi a jour son profil
        IniWrite v, AccountFile(CurrentAccount()), "account", k
}
FieldKey(field) => StrLower(StrReplace(field, " "))

; position du sprinkler (francais -> nom utilise par les chemins)
global SPR_LOCS := Map("Center", "Center", "Upper Left", "Upper Left", "Upper", "Upper", "Upper Right", "Upper Right"
    , "Right", "Right", "Lower Right", "Lower Right", "Lower", "Lower", "Lower Left", "Lower Left", "Left", "Left")
global SPR_LOC_LIST := ["Center", "Upper Left", "Upper", "Upper Right", "Right", "Lower Right", "Lower", "Lower Left", "Left"]
global SPRINKLER_TYPES := ["Supreme", "Diamond", "Golden", "Silver", "Basic", "None"]

; =====================================================================
;  Profils de compte : chaque compte garde sa vitesse, sa ruche, son
;  sprinkler, son serveur... Les presets (champs, collectes...) restent
;  independants du compte.
; =====================================================================
global ACCOUNT_KEYS := MakeAccountKeys()
MakeAccountKeys() {
    m := Map()
    for key in ["MoveSpeed", "SpeedCorr", "HastyGuard", "GiftedHasty", "MoveMethod", "KeyDelay"
        , "HiveSlot", "HiveAuto", "HiveBees", "SprinklerSlot", "SprinklerType", "ResetWait", "R_Enable", "R_Link", "R_Public", "D_UserID"]
        m[key] := 1
    return m
}

AccountDir() => A_ScriptDir "\profils"
AccountFile(name) => AccountDir() "\" name ".ini"
CurrentAccount() => GetState("account", "Main")

SaveAccount(name) {
    DirCreate AccountDir()
    for k in ACCOUNT_KEYS
        IniWrite S[k], AccountFile(name), "account", k
}

; charge les reglages d'un compte dans la configuration active
LoadAccount(name) {
    for k in ACCOUNT_KEYS
        SaveSetting(k, MigrateValue(k, IniRead(AccountFile(name), "account", k, S[k])))
    SetState("account", name)
}

AccountList() {
    if !FileExist(AccountFile(CurrentAccount()))
        SaveAccount(CurrentAccount())
    list := []
    Loop Files AccountDir() "\*.ini"
        list.Push(SubStr(A_LoopFileName, 1, -4))
    return list
}
