﻿if (MoveMethod = "walk")
{
	bm_gotoramp()
	bm_Walk(44.75, BackKey, LeftKey) ; 47.25
	bm_Walk(52.5, LeftKey)
	bm_Walk(2.8, BackKey, RightKey)
	bm_Walk(6.7, BackKey)
	bm_Walk(40.5, LeftKey)
	bm_Walk(5, BackKey)
	send "{" RotRight " 2}"
}
else
{
	bm_gotoramp()
	bm_gotocannon()
	send "{e down}"
	HyperSleep(100)
	send "{e up}{" LeftKey " down}{" FwdKey " down}"
	HyperSleep(1180)
	send "{space 2}"
	HyperSleep(5000)
	send "{" FwdKey " up}{" LeftKey " up}{space}"
	Sleep 1500
	bm_Walk(10, FwdKey, LeftKey)
	bm_Walk(10, BackKey)
	bm_Walk(7, BackKey, RightKey)
	bm_Walk(9, BackKey)
	send "{" RotRight " 2}"
}
Sleep 250
;path 230630 noobyguy
