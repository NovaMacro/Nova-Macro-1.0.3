if (MoveMethod = "walk")
{
	bm_gotoramp()
	bm_Walk(67.5, BackKey, LeftKey)
	send "{" RotRight " 4}"
	bm_Walk(31.5, FwdKey)
	bm_Walk(9, LeftKey)
	bm_Walk(9, BackKey)
	bm_Walk(58.5, LeftKey)
	bm_Walk(49.5, FwdKey)
	bm_Walk(3.375, LeftKey)
	bm_Walk(36, FwdKey)
	bm_Walk(54, RightKey)
	bm_Walk(54, BackKey)
	bm_Walk(58.5, RightKey)
	bm_Walk(15.75, FwdKey, LeftKey)
	bm_Walk(13.5, FwdKey)
	send "{" RotRight " 4}"
	bm_Walk(27, RightKey)
	bm_Walk(18, BackKey)
	bm_Walk(27, RightKey)
}
else
{
	bm_gotoramp()
	bm_gotocannon()
	send "{e down}"
	HyperSleep(100)
	send "{e up}"
	Sleep 3000
	bm_Walk(40.5, RightKey)
}
