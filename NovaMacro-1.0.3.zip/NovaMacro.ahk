﻿; =====================================================================
;  Nova Macro - macro Bee Swarm Simulator (AutoHotkey v2)
;  F1 = Start   F2 = Pause   F3 = Stop
;  Lance START.bat (il met a jour les chemins et patterns avant de demarrer)
;  Licence : GPL-3.0 (voir LICENCE.txt)
; =====================================================================
#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent
SetWorkingDir A_ScriptDir
SendMode "Event"
CoordMode "Pixel", "Screen"
CoordMode "Mouse", "Screen"

; ---------- ecran de chargement ----------
#Include src\Splash.ahk
Splash(8, "Loading dependencies...")

; ---------- bibliotheques ----------
#Include lib\Gdip_All.ahk
#Include lib\Gdip_ImageSearch.ahk
#Include lib\Walk.ahk               ; demarre Gdip, cree "bitmaps" et la marche avec haste
#Include lib\Roblox.ahk
#Include lib\bm_OpenMenu.ahk
#Include lib\bm_InventorySearch.ahk
#Include lib\DurationFromSeconds.ahk

; ---------- images de detection ----------
Splash(30, "Loading detection images...")
global Shrine := Map()
#Include assets\general\bitmaps.ahk
#Include assets\convert\bitmaps.ahk
#Include assets\collect\bitmaps.ahk
#Include assets\kill\bitmaps.ahk
#Include assets\inventory\bitmaps.ahk
#Include assets\reconnect\bitmaps.ahk
#Include assets\offset\bitmaps.ahk
#Include assets\quests\bitmaps.ahk
#Include assets\reset\bitmaps.ahk
#Include assets\night\bitmaps.ahk
#Include assets\fdc\bitmaps.ahk
#Include assets\sprinkler\bitmaps.ahk

; ---------- Nova Macro ----------
Splash(55, "Loading settings and modules...")
#Include src\Config.ahk
#Include src\Loader.ahk
#Include src\Core.ahk
#Include src\Detection.ahk
#Include src\Notify.ahk
#Include src\Reconnect.ahk
#Include src\Activities.ahk
#Include src\FarmAI.ahk
#Include src\Bosses.ahk
#Include src\MemoryMatch.ahk
#Include src\QuestData.ahk
#Include src\Quests.ahk
#Include src\Gui.ahk
#Include src\Update.ahk
#Include src\HiveCheck.ahk
#Include src\HiveScan.ahk
#Include *i lib\Dynamic.ahk         ; chemins et patterns (genere depuis paths\ et patterns\)

; si des fichiers ont ete ajoutes ou modifies, on passe par le chargeur
Splash(70, "Loading paths and patterns...")
if !FileExist(BM_DynamicFile()) || (BM_GenerateDynamic() !== FileRead(BM_DynamicFile(), "UTF-8")) {
    Run '"' A_AhkPath '" "' A_ScriptDir '\Loader.ahk"', A_ScriptDir
    ExitApp
}

try TraySetIcon(A_ScriptDir "\assets\logo\nova.ico")   ; icone de la fenetre et de la barre des taches
A_IconTip := "Nova Macro"
Splash(80, "Building the interface...")
ApplyGlobals()
BuildGui()   ; fenetre construite mais cachee tant que l'ecran de chargement est la
if S["U_Check"] {   ; nouvelle version publiee sur GitHub ?
    Splash(90, "Checking for updates...")
    try CheckUpdateNow()
}
Splash(100, "Ready")
Sleep 250
SplashClose()
MainGui.Show(Format("w{} h{}", WIN_W, WIN_H) (TestMode() ? " NA" : ""))
if UpdInfo
    ShowUpdate()
SetTimer UpdateStats, 1000
SetTimer NightTimer, 5000
SetTimer DeathTimer, 2000
SetTimer HourlyReport, 60000
Log("Nova Macro ready (" PATH_FILES.Count " paths, " PATTERN_FILES.Count " patterns)")

; raccourcis choisis dans Reglages > Raccourcis
ApplyHotkeys()

ApplyHotkeys() {
    static current := []
    for key in current
        try Hotkey key, "Off"
    current := []
    for name, fn in Map("HK_Start", StartMacro, "HK_Pause", TogglePause, "HK_Stop", StopMacro) {
        key := S[name]
        if (key = "" || key = "None")
            continue
        try {
            Hotkey key, fn, "On"
            current.Push(key)
        } catch
            Log("Invalid hotkey: " key)
    }
}

; =====================================================================
StartMacro(*) {
    global Running, StartTick, StopReq, Paused
    if Running
        return
    ApplyGlobals()
    Running := true, StartTick := A_TickCount, StopReq := false, Paused := false
    UI_Chip("Running")
    UI_SetStatus("Starting...")
    SetTimer MainLoop, -50
}

TogglePause(*) {
    global Paused
    if !Running || StopReq
        return
    Paused := !Paused
    ReleaseAll()
    UI_Chip(Paused ? "Pause" : "Running")
    UI_SetStatus(Paused ? "Paused (F2 to resume)" : "Resumed")
    ; message envoye tout de suite, sans attendre la reponse de Discord (la fenetre ne gele pas)
    Hook(Paused ? "Macro paused" : "Macro resumed", Paused ? "Press F2 to resume." : "", "pause", SessionFields(), false, 1)
    WebhookPump(true)
    Pause -1
}

; arret propre : pas de rechargement du script, la boucle s'arrete d'elle-meme
StopMacro(*) {
    global StopReq, Paused
    if !Running
        return
    StopReq := true
    ReleaseAll()
    UI_Chip("Stopping")
    UI_SetStatus("Stopping...")
    if Paused {
        Paused := false
        Pause 0
    }
    SetTimer ForceStop, -4000   ; securite : si la boucle ne repond pas, on recharge
}

ForceStop() {
    if Running {
        ReleaseAll()
        Reload
    }
}

MainLoop() {
    global Running, StopReq, Paused
    SetKeyDelay KeyDelay
    Log("Macro started")
    Hook("Macro started", "Here is everything enabled for this session.", "start", SettingsFields(), true, 1)
    errors := 0
    try {
        if !GetRobloxHWND()
            CheckDisconnect(true)
        ActivateRoblox()
        if !GetTime("reconnect_last")
            SetTime("reconnect_last")
        if S["HiveAuto"]   ; on retrouve sa ruche (et son slot) tout seul
            try DetectHive()
            catch MacroStop as e
                throw e
            catch as e
                LogError(e, "hive detection")
        Loop {
            CheckStop()
            try {
                CheckDisconnect()
                ScheduledReconnect()
                DoViciousBee()
                DoCollect()
                DoBosses()
                DoKills()
                DoMemoryMatch()
                DoQuests()
                DoBoosters()
                if (QuestGatherField != "")
                    Gather(QuestFieldCfg(QuestGatherField))
                else if S["M_GatherOff"] {
                    SetStatus("Waiting", "gathering disabled (Gather > Options)")
                    CheckBoosts("hive")
                    Sleep 3000
                } else if (i := NextFieldSlot())
                    Gather(FieldCfg(i))
                else {
                    SetStatus("Waiting", "no field (Gather, + button)")
                    CheckBoosts("hive")
                    Sleep 3000
                }
                errors := 0
            } catch MacroStop as e {
                throw e
            } catch as e {
                ReleaseAll()
                errors++
                LogError(e, "(continuing)")
                if (errors = 5)
                    Hook("5 errors in a row", "The macro keeps going but something is stuck. Check the screenshot.", "bad"
                        , [["Last error", e.Message, false], ["Detail", e.Extra], ["Line", e.Line]], true, 1)
                Sleep 1000
            }
        }
    } catch MacroStop {
        ; arret demande
    }
    ReleaseAll()
    try AICamRestore()   ; camera du Farm IA remise comme avant
    try bm_setShiftLock(0)
    LiveStop("Gathering stopped", "The macro was stopped.", "")
    Running := false, StopReq := false, Paused := false
    SetTimer ForceStop, 0
    UI_Chip("Ready")
    SetStatus("Stopped", "F1 to restart")
    Hook("Macro stopped", "Full session summary.", "stop", SessionFields(), true, 1)
}

ScheduledReconnect() {
    if (h := Num(S["R_Hours"])) && (Now() - GetTime("reconnect_last") >= h * 3600) {
        SetStatus("Reconnect", "scheduled every " h "h")
        Hook("Scheduled reconnect", "Automatic reconnect every " h " h.", "net", "", false, 2)
        CheckDisconnect(true)
    }
}
