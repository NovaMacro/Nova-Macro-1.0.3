; Lance par START.bat : met a jour les chemins/patterns puis demarre Nova Macro
#Requires AutoHotkey v2.0
#SingleInstance Force
#NoTrayIcon
SetWorkingDir A_ScriptDir
#Include src\Splash.ahk
#Include src\Loader.ahk

Splash(4, "Preparing paths and patterns...")
if (BM_BuildDynamic() != "error")
    Run '"' A_AhkPath '" "' A_ScriptDir '\NovaMacro.ahk"', A_ScriptDir
Sleep 400   ; la macro affiche son propre ecran de chargement
ExitApp     ; sinon la fenetre de chargement resterait affichee
