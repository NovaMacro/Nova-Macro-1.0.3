﻿; =====================================================================
;  Chargeur automatique des chemins (paths\) et des patterns (patterns\)
;  Chaque fichier .ahk de ces dossiers devient une fonction appelable.
;  Pour ajouter un pattern : depose un fichier dans patterns\ et relance.
; =====================================================================

BM_DynamicFile() => A_ScriptDir "\lib\Dynamic.ahk"

BM_GenerateDynamic() {
    reg := "", funcs := "", used := Map()
    used.CaseSense := 0

    for kind in ["paths", "patterns"] {
        Loop Files A_ScriptDir "\" kind "\*.ahk" {
            name := SubStr(A_LoopFileName, 1, -4)
            if (name = "" || InStr(name, "'"))
                continue
            base := (kind = "paths" ? "BMPath_" : "BMPattern_") RegExReplace(name, "[^A-Za-z0-9_]", "_")
            fn := base, n := 1
            while used.Has(fn)
                fn := base "_" (++n)
            used[fn] := 1
            body := RTrim(FileRead(A_LoopFileFullPath, "UTF-8"), "`r`n`t ")
            ; chemins/patterns colles depuis une autre macro : on convertit les anciens noms de fonctions
            body := RegExReplace(body, "\bnm_(?=\w+\()", "bm_")
            if (kind = "paths") {
                reg .= "PATH_FILES['" StrLower(name) "'] := " fn "`r`n"
                funcs .= fn "() {`r`n" body "`r`n}`r`n`r`n"
            } else {
                reg .= "PATTERN_FILES['" name "'] := " fn ", PATTERN_NAMES.Push('" name "')`r`n"
                funcs .= fn "(reps, size, facingcorner := 0) {`r`n" body "`r`n}`r`n`r`n"
            }
        }
    }
    return "; AUTO-GENERATED FILE - do not edit.`r`n"
        . "; Edit the files in the paths\ and patterns\ folders instead.`r`n"
        . "global PATH_FILES := Map(), PATTERN_FILES := Map(), PATTERN_NAMES := []`r`n"
        . "PATH_FILES.CaseSense := 0, PATTERN_FILES.CaseSense := 0`r`n"
        . reg "`r`n" funcs
}

; regenere lib\Dynamic.ahk ; verifie que tout compile, sinon remet l'ancien
; renvoie "same", "ok" ou "error"
BM_BuildDynamic() {
    file := BM_DynamicFile()
    new := BM_GenerateDynamic()
    old := FileExist(file) ? FileRead(file, "UTF-8") : ""
    if (new == old)
        return "same"
    BM_WriteFile(file, new)

    errFile := A_Temp "\beemacro_check.txt"
    try FileDelete errFile
    code := RunWait(A_ComSpec ' /c ""' A_AhkPath '" /ErrorStdOut /validate "' A_ScriptDir '\NovaMacro.ahk" 2> "' errFile '""', A_ScriptDir, "Hide")
    if (code != 0) {
        err := FileExist(errFile) ? FileRead(errFile) : "unknown error"
        if (old != "")
            BM_WriteFile(file, old)
        MsgBox "A path or pattern file has an error, it was not loaded:`n`n" err
            . "`n`nFix or delete the faulty file, then run START.bat again.", "Nova Macro", "Icon!"
        return "error"
    }
    return "ok"
}

BM_WriteFile(path, text) {
    f := FileOpen(path, "w", "UTF-8")
    f.Write(text)
    f.Close()
}
