﻿if (MoveMethod = "walk" ) {
	bm_gotoramp()
	bm_Walk(88.875, BackKey, LeftKey)
	bm_Walk(27, LeftKey)
	HyperSleep(50)
	send "{" RotLeft " 2}"
	bm_Walk(15, FwdKey) 
	bm_Walk(20, LeftKey)
	bm_Walk(20, FwdKey)
	bm_Walk(10, BackKey)
}
else {
	bm_gotoramp()
	bm_gotocannon()
	send "{e down}"
	HyperSleep(100)
	send "{e up}{" LeftKey " down}"
	HyperSleep(700)
	send "{space 2}"
	HyperSleep(4450)
	send "{" LeftKey " up}{space}"
	HyperSleep(1000)
	send "{" RotLeft " 2}"
	bm_Walk(20, LeftKey)
	bm_Walk(20, FwdKey)
	bm_Walk(10, BackKey)
}
;path 230729 noobyguy
; edited by Lorddrak