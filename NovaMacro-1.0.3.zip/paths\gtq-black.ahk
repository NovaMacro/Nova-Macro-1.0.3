﻿bm_gotoramp()
bm_Walk(10, BackKey) ; 13.25
bm_Walk(13.5, RightKey)
bm_Walk(6, FwdKey)
bm_Walk(6, BackKey)
