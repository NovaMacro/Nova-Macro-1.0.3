﻿if (MoveMethod = "walk")
{
	bm_gotoramp()
	bm_Walk(44.75, BackKey, LeftKey)
	bm_Walk(42.5, LeftKey)
	bm_Walk(8.5, BackKey)
	bm_Walk(22.5, LeftKey)
	send "{" RotLeft " 2}"
	bm_Walk(40, FwdKey)
	bm_Walk(1.2, BackKey)
	bm_Walk(15, RightKey)
}
else
{
	bm_gotoramp()
	bm_gotocannon()
	Send "{e down}"
	HyperSleep(100)
	Send "{e up}{" FwdKey " down}{" LeftKey " down}"
	HyperSleep(1500)
	send "{space 2}"
	Sleep 8000
	Send "{" FwdKey " up}{" LeftKey " up}"
	bm_Walk(20, RightKey)
	bm_Walk(8, LeftKey)
	bm_Walk(3, RightKey, BackKey)
	bm_Walk(2, BackKey)
}
