; ==== Donnees des quetes ====
; [numero de la ligne dans le journal, action, cible]
QuestBarGapSize := 10
QuestBarSize := 50
QuestBarInset := 16

;map: quest name, [objective array]
PolarBear := Map("Aromatic Pie",
		[[3,"Kill","Mantis"]
		,[4,"Kill","Ladybugs"]
		,[1,"Collect","Rose"]
		,[2,"Collect","Pine Tree"]]

	, "Beetle Brew",
		[[3,"Kill","Ladybugs"]
		,[4,"Kill","RhinoBeetles"]
		,[1,"Collect","Pineapple"]
		,[2,"Collect","Dandelion"]]

	, "Candied Beetles",
		[[3,"Kill","RhinoBeetles"]
		,[1,"Collect","Strawberry"]
		,[2,"Collect","Blue Flower"]]

	, "Exotic Salad",
		[[1,"Collect","Cactus"]
		,[2,"Collect","Rose"]
		,[3,"Collect","Blue Flower"]
		,[4,"Collect","Clover"]]

	, "Extreme Stir-Fry",
		[[6,"Kill","Werewolf"]
		,[5,"Kill","Scorpions"]
		,[4,"Kill","Spider"]
		,[1,"Collect","Cactus"]
		,[2,"Collect","Bamboo"]
		,[3,"Collect","Dandelion"]]

	, "High Protein",
		[[4,"Kill","Spider"]
		,[3,"Kill","Scorpions"]
		,[2,"Kill","Mantis"]
		,[1,"Collect","Sunflower"]]

	, "Ladybug Poppers",
		[[2,"Kill","Ladybugs"]
		,[1,"Collect","Blue Flower"]]

	, "Mantis Meatballs",
		[[2,"Kill","Mantis"]
		,[1,"Collect","Pine Tree"]]

	, "Prickly Pears",
		[[1,"Collect","Cactus"]]

	, "Pumpkin Pie",
		[[3,"Kill","Mantis"]
		,[1,"Collect","Pumpkin"]
		,[2,"Collect","Sunflower"]]

	, "Scorpion Salad",
		[[2,"Kill","Scorpions"]
		,[1,"Collect","Rose"]]

	, "Spiced Kebab",
		[[3,"Kill","Werewolf"]
		,[1,"Collect","Clover"]
		,[2,"Collect","Bamboo"]]

	, "Spider Pot-Pie",
		[[2,"Kill","Spider"]
		,[1,"Collect","Mushroom"]]

	, "Spooky Stew",
		[[4,"Kill","Werewolf"]
		,[3,"Kill","Spider"]
		,[1,"Collect","Spider"]
		,[2,"Collect","Mushroom"]]

	, "Strawberry Skewers",
		[[3,"Kill","Scorpions"]
		,[1,"Collect","Strawberry"]
		,[2,"Collect","Bamboo"]]

	, "Teriyaki Jerky",
		[[3,"Kill","Werewolf"]
		,[1,"Collect","Pineapple"]
		,[2,"Collect","Spider"]]

	, "Thick Smoothie",
		[[1,"Collect","Strawberry"]
		,[2,"Collect","Pumpkin"]]

	, "Trail Mix",
		[[1,"Collect","Sunflower"]
		,[2,"Collect","Pineapple"]]

	; TODO: PETALDETECT
	, "Petal Tabbouleh",
		[[1, "Collect", "Pineapple"]
		, [2, "Collect", "Strawberry"]
		, [3, "Kill", "RhinoBeetles"]]

	, "Mashed Blooms",
		[[1, "Collect", "Pumpkin"]
		,[2, "Collect", "Spider"]
		,[3, "Collect", "Bamboo"]
		,[4, "Kill", "Spider"]]
)

BlackBear := Map("Just White",
		[[1,"Collect","White"]]

	, "Just Red",
		[[1,"Collect","Red"]]

	, "Just Blue",
		[[1,"Collect","Blue"]]

	, "A Bit Of Both",
		[[1,"Collect","Red"]
		,[2,"Collect","Blue"]]

	, "Any Pollen",
		[[1,"Collect","Any"]]

	, "The Whole Lot",
		[[1,"Collect","Red"]
		,[2,"Collect","Blue"]
		,[3,"Collect","White"]]

	, "Between The Bamboo",
		[[2,"Collect","Bamboo"]
		,[1,"Collect","Blue"]]

	, "Play In The Pumpkins",
		[[2,"Collect","Pumpkin"]
		,[1,"Collect","White"]]

	, "Plundering Pineapples",
		[[2,"Collect","Pineapple"]
		,[1,"Collect","Any"]]

	, "Stroll In The Strawberries",
		[[2,"Collect","Strawberry"]
		,[1,"Collect","Red"]]

	, "Mid-Level Mission",
		[[1,"Collect","Spider"]
		,[2,"Collect","Strawberry"]
		,[3,"Collect","Bamboo"]]

	, "Blue Flower Bliss",
		[[1,"Collect","Blue Flower"]]

	, "Delve Into Dandelions",
		[[1,"Collect","Dandelion"]]

	, "Fun In The Sunflowers",
		[[1,"Collect","Sunflower"]]

	, "Mission For Mushrooms",
		[[1,"Collect","Mushroom"]]

	, "Leisurely Lowlands",
		[[1,"Collect","Sunflower"]
		,[2,"Collect","Dandelion"]
		,[3,"Collect","Mushroom"]
		,[4,"Collect","Blue Flower"]]

	, "Triple Trek",
		[[1,"Collect","Mountain Top"]
		,[2,"Collect","Pepper"]
		,[3,"Collect","Coconut"]]

	, "Pepper Patrol",
		[[1,"Collect","Pepper"]])


BuckoBee := Map("Abilities",
		[[1,"Collect","Any"]]

	, "Bamboo",
		[[1,"Collect","Bamboo"]]

	, "Bombard",
		[[4,"Get","Ant"]
		,[3,"Get","Ant"]
		,[2,"Kill","RhinoBeetles"]
		,[1,"Collect","Any"]]

	, "Booster",
		[[2,"Get","BlueBoost"]
		,[1,"Collect","Any"]]

	, "Clean-Up",
		[[1,"Collect","Blue Flower"]
		,[2,"Collect","Bamboo"]
		,[3,"Collect","Pine Tree"]]

	, "Extraction",
		[[1,"Collect","Clover"]
		,[2,"Collect","Cactus"]
		,[3,"Collect","Pumpkin"]]

	, "Flowers",
		[[1,"Collect","Blue Flower"]]

	, "Goo",
		[[1,"Collect","Blue"]]

	, "Medley",
		[[2,"Collect","Bamboo"]
		,[3,"Collect","Pine Tree"]
		,[1,"Collect","Any"]]

	, "Picnic",
		[[5,"Get","Ant"]
		,[4,"Get","Ant"]
		,[3,"Feed","Blueberry"]
		,[1,"Collect","Blue Flower"]
		,[2,"Collect","Blue"]]

	, "Pine Trees",
		[[1,"Collect","Pine Tree"]]

	, "Pollen",
		[[1,"Collect","Blue"]]

	, "Scavenge",
		[[1,"Collect","Blue"]
		,[3,"Collect","Blue"]
		,[2,"Collect","Any"]]

	, "Skirmish",
		[[2,"Kill","RhinoBeetles"]
		,[1,"Collect","Blue Flower"]]

	, "Tango",
		[[3,"Kill","Mantis"]
		,[1,"Collect","Blue"]
		,[2,"Collect","Any"]]

	, "Tour",
		[[5,"Kill","Mantis"]
		,[4,"Kill","RhinoBeetles"]
		,[1,"Collect","Blue Flower"]
		,[2,"Collect","Bamboo"]
		,[3,"Collect","Pine Tree"]]

	, "Petals",
		[[1,"Collect","Pine Tree"]
		,[2,"Collect","Clover"]
		,[3,"Collect","Pineapple"]])


RileyBee := Map("Abilities",
		[[1,"Collect","Any"]]

	, "Booster",
		[[2,"Get","RedBoost"]
		,[1,"Collect","Any"]]

	, "Clean-Up",
		[[1,"Collect","Mushroom"]
		,[2,"Collect","Strawberry"]
		,[3,"Collect","Rose"]]

	, "Extraction",
		[[1,"Collect","Clover"]
		,[2,"Collect","Cactus"]
		,[3,"Collect","Pumpkin"]]

	, "Goo",
		[[1,"Collect","Red"]]

	, "Medley",
		[[2,"Collect","Strawberry"]
		,[3,"Collect","Rose"]
		,[1,"Collect","Any"]]

	, "Mushrooms",
		[[1,"Collect","Mushroom"]]

	, "Picnic",
		[[4,"Get","Ant"]
		,[3,"Feed","Strawberry"]
		,[1,"Collect","Mushroom"]
		,[2,"Collect","Strawberry"]]

	, "Pollen",
		[[1,"Collect","Red"]]

	, "Rampage",
		[[3,"Get","Ant"]
		,[2,"Kill","Ladybugs"]
		,[1,"Kill","All"]]

	, "Roses",
		[[1,"Collect","Rose"]]

	, "Scavenge",
		[[1,"Collect","Red"]
		,[3,"Collect","Strawberry"]
		,[2,"Collect","Any"]]

	, "Skirmish",
		[[2,"Kill","Ladybugs"]
		,[1,"Collect","Mushroom"]]

	, "Strawberries",
		[[1,"Collect","Strawberry"]]

	, "Tango",
		[[3,"Kill","Scorpions"]
		,[1,"Collect","Red"]
		,[2,"Collect","Any"]]

	, "Tour",
		[[5,"Kill","Scorpions"]
		,[4,"Kill","Ladybugs"]
		,[1,"Collect","Mushroom"]
		,[2,"Collect","Strawberry"]
		,[3,"Collect","Rose"]]

	, "Petals",
		[[1,"Collect","Strawberry"]
		,[2,"Collect","Clover"]
		,[3,"Collect","Spider"]]
)
