﻿if (MoveMethod = "walk")
{
	bm_Walk(3, FwdKey)
	bm_Walk(52, LeftKey)
	bm_Walk(3, FwdKey)
	send "{" FwdKey " down}{space down}"
	HyperSleep(300)
	send "{space up}"
	bm_Walk(5, RightKey)
	send "{space down}"
	HyperSleep(300)
	send "{space up}{" FwdKey " up}"
	HyperSleep(500)
	bm_Walk(2, FwdKey)
	bm_Walk(15, RightKey)
	bm_Walk(6, FwdKey, RightKey)
	bm_Walk(7, FwdKey)
	bm_Walk(5, BackKey, LeftKey)
	bm_Walk(23, FwdKey)
	bm_Walk(12, LeftKey)
	bm_Walk(8, LeftKey, FwdKey) ; 1.3
	bm_Walk(10, FwdKey) ; 1.3
	bm_Walk(5, RightKey) ; 1.3
	bm_Walk(25, FwdKey, RightKey) ; 31
	bm_Walk(50, LeftKey)
	bm_Walk(2, RightKey)
	bm_Walk(40, FwdKey)
	send "{" RotRight " 2}"
	bm_Walk(55, FwdKey)
	bm_Walk(10, LeftKey)
	send "{" RotRight " 2}"
	bm_Walk(5.79, FwdKey, RightKey)
	bm_Walk(50, FwdKey)
	send "{space down}"
	Hypersleep(300)
	send "{space up}"
	bm_Walk(6, FwdKey)
	send "{space down}"
	HyperSleep(100)
	send "{space up}"
	bm_Walk(4, FwdKey, RightKey)
	send "{" RotLeft " 4}"
	Sleep 1500
}
else
{
	bm_gotoramp()
	bm_gotocannon()
	send "{e down}"
	HyperSleep(100)
	send "{e up}{" FwdKey " down}"
	HyperSleep(1170)
	send "{space 2}{" FwdKey " up}"
	HyperSleep(6750)
	bm_Walk(18, FwdKey)
	bm_Walk(8.5, LeftKey)
	bm_Walk(3, LeftKey, FwdKey)
	Sleep 1500
}
;path 230630 noobyguy - walk updated
