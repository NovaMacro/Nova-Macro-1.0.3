﻿if (MoveMethod = "walk")
{
	bm_gotoramp()
	bm_Walk(67.5, BackKey, LeftKey)
	send "{" RotRight " 4}"
	bm_Walk(31.5, FwdKey)
	bm_Walk(9, LeftKey)
	bm_Walk(9, BackKey)
	bm_Walk(58.5, LeftKey)
	bm_Walk(49.5, FwdKey)
	bm_Walk(3.375, LeftKey)
	bm_Walk(36, FwdKey)
	bm_Walk(54, RightKey)
	bm_Walk(54, BackKey)
	bm_Walk(58.5, RightKey)
	bm_Walk(3, LeftKey)
	bm_Walk(57, FwdKey)
	bm_Walk(16, LeftKey)
	bm_Walk(3, FwdKey)
	bm_Walk(8, LeftKey)
	bm_Walk(2, RightKey)
	bm_Walk(13, FwdKey)
	send "{" RotLeft " 2}"
	bm_Walk(1.5, FwdKey)
	send "{space down}"
	HyperSleep(100)
	send "{space up}"
	bm_Walk(8.5, FwdKey)
	bm_Walk(3, LeftKey)
	bm_Walk(20, FwdKey)
	Sleep 500
}
else
{
	bm_gotoramp()
	bm_gotocannon()
	send "{e down}"
	HyperSleep(100)
	send "{e up}{" LeftKey " down}{" BackKey " down}"
	HyperSleep(1400)
	send "{space 2}"
	HyperSleep(1100)
	send "{" LeftKey " up}"
	HyperSleep(650)
	send "{" BackKey " up}{space}{" RotRight " 4}"
	Sleep 1500
	bm_Walk(4, RightKey, FwdKey)
	bm_Walk(23, FwdKey)
	bm_Walk(9, LeftKey)
	bm_Walk(3, FwdKey)
	bm_Walk(8, LeftKey)
	bm_Walk(2, RightKey)
	bm_Walk(13, FwdKey)
	send "{" RotLeft " 2}"
	bm_Walk(1.5, FwdKey)
	send "{space down}"
	HyperSleep(100)
	send "{space up}"
	bm_Walk(8.5, FwdKey)
	bm_Walk(3, LeftKey)
	bm_Walk(20, FwdKey)
	Sleep 500
}
;path 230629 noobyguy | 230909 reverted cannon path -noobyguy
