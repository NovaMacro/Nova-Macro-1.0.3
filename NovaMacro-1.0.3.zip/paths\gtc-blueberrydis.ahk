﻿if (MoveMethod = "walk")
{
	bm_gotoramp()
	bm_Walk(88.875, BackKey, LeftKey)
	bm_Walk(27, LeftKey)
	HyperSleep(50)
	send "{" RotLeft " 2}"
	HyperSleep(50)
	bm_Walk(30, FwdKey)
	bm_Walk(11.5, FwdKey, RightKey)
	bm_Walk(2, RightKey)
}
else
{
	bm_gotoramp()
	bm_gotocannon()
	send "{e down}"
	HyperSleep(100)
	send "{e up}{" LeftKey " down}"
	HyperSleep(700)
	send "{space 2}"
	HyperSleep(4450)
	send "{" LeftKey " up}{space}"
	HyperSleep(1000)
	send "{" RotLeft " 2}"
	bm_Walk(10, LeftKey)
	bm_Walk(8, RightKey)
	;inside
	bm_Walk(10, FwdKey)
	send "{" RotRight " 1}"
	HyperSleep(100)
	bm_Walk(1.6, FwdKey)
	send "{FwdKey down}{space down}"
	HyperSleep(300)
	send "{space up}"
	send "{space}"
	HyperSleep(1300)
}
;path 230629 noobyguy