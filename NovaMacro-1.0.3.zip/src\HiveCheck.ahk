; =====================================================================
;  Hive Check (onglet Tools) : le joueur indique sa couleur de ruche,
;  son nombre d'abeilles, le champ qu'il veut farmer et les abeilles
;  qu'il a (eue / gifted). L'analyse dit quoi obtenir, quoi gift en
;  premier, quoi remplacer et pourquoi, dans un rapport (Bloc-notes).
;  Regles tirees de la meta de Bee Swarm Simulator.
; =====================================================================

; abeilles importantes pour chaque ruche, de la plus a la moins prioritaire
global HC_CORE := Map(
    "Blue", ["Buoyant", "Tadpole", "Vicious", "Tabby", "Bubble", "Bucko", "Diamond", "Cobalt", "Frosty", "Photon", "Windy", "Puppy", "Baby", "Hasty", "Ninja", "Cool", "Bumble"],
    "Red", ["Precise", "Spicy", "Tabby", "Demon", "Crimson", "Riley", "Fire", "Rage", "Rascal", "Photon", "Windy", "Puppy", "Baby", "Hasty", "Demo", "Shy", "Rad"],
    "White", ["Tabby", "Vector", "Fuzzy", "Photon", "Windy", "Puppy", "Baby", "Music", "Gummy", "Digital", "Hasty", "Lion", "Commander", "Carpenter", "Bomber", "Looker"],
    "Mixed", ["Tabby", "Vicious", "Windy", "Photon", "Puppy", "Baby", "Precise", "Buoyant", "Vector", "Fuzzy", "Spicy", "Tadpole", "Music", "Diamond", "Hasty"])

; pourquoi chaque abeille compte (affiche dans le rapport)
global HC_WHY := Map(
    "Buoyant", "makes Inflate Balloons: huge blue pollen and a boost to balloon pollen.",
    "Tadpole", "summons frogs (Summon Frog token) that collect a lot of blue pollen.",
    "Vicious", "very strong attacker; its spikes and bonuses help any hive, especially blue.",
    "Tabby", "gets stronger over time with Tabby Love stacks and boosts critical power for the whole hive.",
    "Bubble", "creates bubbles in fields that pop for big blue pollen.",
    "Bucko", "makes Blue Boost tokens that raise blue field pollen.",
    "Diamond", "converts a lot of pollen into honey; the best legendary for blue hives.",
    "Cobalt", "event bee that boosts blue pollen with its pulses.",
    "Frosty", "makes blue bombs: cheap and steady blue pollen.",
    "Photon", "Photon Beam: very fast pollen collection, great in every hive.",
    "Windy", "Rain Cloud and Tornado tokens: lots of pollen, great in every hive.",
    "Puppy", "Puppy Love and Fetch: bond and pollen boosts for the hive.",
    "Baby", "Baby Love token: a big pollen boost for the whole hive.",
    "Hasty", "Haste tokens make you walk faster; a gifted Hasty gives permanent movespeed.",
    "Ninja", "fast blue collector.", "Cool", "steady blue collector.", "Bumble", "cheap blue collector, good early.",
    "Precise", "Target Practice and Mark tokens: the strongest red mythic, big critical bonuses.",
    "Spicy", "Inferno and Flame Fuel tokens: very strong red pollen.",
    "Demon", "strong red legendary with flames in red fields.",
    "Crimson", "event bee that boosts red pollen with its pulses.",
    "Riley", "makes Red Boost tokens that raise red field pollen.",
    "Fire", "leaves flames in fields that give red pollen.", "Rage", "Rage tokens boost the hive's attack and red pollen.",
    "Rascal", "makes red bombs.", "Demo", "makes bomb tokens.", "Shy", "strong red collector.", "Rad", "cheap red collector, good early.",
    "Vector", "Triangulate and Mark Surge tokens: big boosts from marks, the best white mythic.",
    "Fuzzy", "Fuzz Bombs and Pollen Haze: huge white pollen.",
    "Music", "Melody tokens boost the whole hive.", "Gummy", "Glob and Gumdrop Barrage tokens: good pollen and goo.",
    "Digital", "Glitch and Map Corruption tokens.", "Lion", "strong white collector.",
    "Commander", "Focus tokens for critical chance.", "Carpenter", "steady white collector with good marks.",
    "Bomber", "makes bomb tokens.", "Looker", "Focus tokens for critical chance.")

; couleur dominante de chaque champ et abeilles necessaires
global HC_FIELD_COLOR := Map("Sunflower", "White", "Dandelion", "White", "Mushroom", "Red", "Blue Flower", "Blue", "Clover", "Mixed"
    , "Strawberry", "Red", "Spider", "White", "Bamboo", "Blue", "Pineapple", "White", "Stump", "Mixed", "Cactus", "Mixed"
    , "Pumpkin", "White", "Pine Tree", "Blue", "Rose", "Red", "Mountain Top", "Mixed", "Pepper", "Red", "Coconut", "White")
global HC_FIELD_BEES := Map("Sunflower", 0, "Dandelion", 0, "Mushroom", 0, "Blue Flower", 0, "Clover", 0, "Strawberry", 5, "Spider", 5
    , "Bamboo", 5, "Pineapple", 10, "Stump", 10, "Cactus", 15, "Pumpkin", 15, "Pine Tree", 15, "Rose", 15, "Mountain Top", 15
    , "Pepper", 35, "Coconut", 35)
; meilleurs champs par ruche, du meilleur au plus facile d'acces
global HC_BEST := Map("Blue", ["Pine Tree", "Bamboo", "Blue Flower"], "Red", ["Pepper", "Rose", "Strawberry", "Mushroom"]
    , "White", ["Coconut", "Pumpkin", "Pineapple", "Spider", "Sunflower"], "Mixed", ["Mountain Top", "Cactus", "Clover"])

BeeInfo(key) {
    for b in BEE_LIST
        if (b[1] = key)
            return {key: b[1], name: b[2], color: b[3], rarity: b[4]}
}

; ---------- analyse ----------
HiveCheck(*) {
    hive := S["HC_Hive"], bees := Num(S["HC_Bees"], 25), field := S["HC_Field"]
    fcolor := HC_FIELD_COLOR.Has(field) ? HC_FIELD_COLOR[field] : "Mixed"
    have := Map(), gifted := Map(), counts := Map("Blue", 0, "Red", 0, "White", 0), mythics := 0
    for b in BEE_LIST {
        st := S["HC_B_" b[1]]
        if (st = "Have" || st = "Gifted") {
            have[b[1]] := 1, counts[b[3]]++
            if (b[4] = "Mythic")
                mythics++
        }
        if (st = "Gifted")
            gifted[b[1]] := 1
    }
    core := HC_CORE[hive], score := 0, line := "`r`n" StrRepeat("=", 64) "`r`n"
    t := "NOVA MACRO - HIVE CHECK`r`n" FormatTime(, "yyyy-MM-dd  HH:mm") "`r`n" line

    ; --- setup ---
    t .= "YOUR SETUP`r`n"
    t .= "  Hive color : " hive "`r`n  Bees       : " bees " / 50`r`n  Main field : " field " (" fcolor " pollen, needs " HC_FIELD_BEES[field] " bees)`r`n"
    t .= "  Bees you marked: " have.Count " (" gifted.Count " gifted)  -  blue " counts["Blue"] ", red " counts["Red"] ", white " counts["White"] ", mythics " mythics "`r`n"

    ; --- champ ---
    t .= line "FIELD`r`n"
    if (bees < HC_FIELD_BEES[field])
        t .= "  ! " field " needs " HC_FIELD_BEES[field] " bees and you have " bees ". You can't reach it yet.`r`n"
    if (hive != "Mixed" && fcolor != hive && fcolor != "Mixed")
        t .= "  ! " field " gives mostly " StrLower(fcolor) " pollen, but your hive is " StrLower(hive) ".`r`n"
        . "    Your bees get their color bonuses only on " StrLower(hive) " pollen, so you lose a big part of your gathering here.`r`n"
    best := ""
    for f in HC_BEST[hive]
        if (bees >= HC_FIELD_BEES[f]) {
            best := f
            break
        }
    if (best != "" && best != field)
        t .= "  > Best field for you right now: " best ". It is the strongest " StrLower(hive) " field you can reach with " bees " bees.`r`n"
    else if (best = field)
        t .= "  OK " field " is the best field for your hive right now. Keep farming it.`r`n", score += 15

    ; --- abeilles a obtenir ---
    t .= line "BEES TO GET (in order)`r`n"
    n := 0
    for k in core
        if !have.Has(k) && (n < 6) {
            n++, bi := BeeInfo(k)
            t .= "  " n ". " bi.name " Bee (" bi.rarity ", " StrLower(bi.color) ")`r`n     Why: " HC_WHY[k] "`r`n"
            if (bi.rarity = "Mythic")
                t .= "     How: Mythic Eggs, or Star Jelly / Royal Jelly rolls on a bee you don't need.`r`n"
            else if (bi.rarity = "Event")
                t .= "     How: event bee, only from its own event or quest line.`r`n"
        }
    if !n
        t .= "  You already have every key bee for a " StrLower(hive) " hive. Nice!`r`n", score += 25
    else
        score += Round(25 * (core.Length - n) / core.Length)

    ; --- abeilles a gift ---
    t .= line "BEES TO GIFT NEXT (in order)`r`n"
    n := 0
    if have.Has("Hasty") && !gifted.Has("Hasty")
        n++, t .= "  " n ". Hasty Bee`r`n     Why: a gifted Hasty gives permanent movespeed, so the macro travels and gathers faster.`r`n"
    for k in core
        if have.Has(k) && !gifted.Has(k) && (k != "Hasty") && (n < 6) {
            n++, bi := BeeInfo(k)
            t .= "  " n ". " bi.name " Bee`r`n     Why: " HC_WHY[k] " Gifted bees also give a bonus to the whole hive.`r`n"
        }
    if !n
        t .= "  Every key bee you own is already gifted (or you didn't mark any).`r`n", score += 20
    t .= "  Tip: use Star Treats on the bee, or feed it its favorite treat for a chance to gift it.`r`n"

    ; --- abeilles a remplacer ---
    t .= line "BEES TO REPLACE`r`n"
    n := 0
    if (hive != "Mixed") {
        for b in BEE_LIST
            if have.Has(b[1]) && (b[3] != hive) && (b[3] != "White") && !gifted.Has(b[1]) {
                n++
                t .= "  - " b[2] " Bee (" StrLower(b[3]) "): it does not get your " StrLower(hive) " hive bonuses.`r`n"
            }
        if n
            t .= "  Why: in a " StrLower(hive) " hive, " StrLower(hive) " bees and white bees are the ones that count.`r`n"
            . "  Use Royal Jelly on these slots until you get a " StrLower(hive) " bee from the list above.`r`n"
    }
    if !n
        t .= "  Nothing to replace. Your bees fit your hive.`r`n", score += 15
    if (hive = "Mixed")
        t .= "  Note: a mixed hive is flexible but never as strong as one color. Once you have 2 mythics of one`r`n"
        . "  color, think about moving to that color.`r`n"
    else
        score += Min(10, Round(10 * counts[hive] / Max(1, have.Count)))

    ; --- conseils ---
    t .= line "TIPS`r`n"
    if (bees < 50)
        t .= "  - Keep hatching eggs: every new bee adds pollen. You have " 50 - bees " free slot(s).`r`n"
    if (mythics = 0)
        t .= "  - Aim for your first mythic: it is the biggest power jump for a " StrLower(hive) " hive.`r`n"
    t .= "  - In Nova Macro, choose hive '" hive "' in AI Gather > Settings so the AI targets the right tokens.`r`n"
    t .= "  - Set your field to " (best != "" ? best : field) " in Gather and turn on drift compensation if you have a Supreme Saturator.`r`n"
    score := Min(100, score + Round(15 * have.Count / Max(1, core.Length)))
    t .= line "HIVE SCORE: " score " / 100  (based on the bees and settings you entered)`r`n"

    DirCreate A_ScriptDir "\reports"
    file := A_ScriptDir "\reports\Hive Check " FormatTime(, "yyyy-MM-dd HH-mm") ".txt"
    try FileDelete file
    FileAppend t, file, "UTF-8"
    Run 'notepad.exe "' file '"'
    Log("Hive Check done (score " score ")")
}

StrRepeat(s, n) {
    out := ""
    Loop n
        out .= s
    return out
}
