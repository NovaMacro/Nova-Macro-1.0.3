﻿; =====================================================================
;  Mises a jour : au demarrage, la macro regarde la derniere version
;  publiee sur GitHub (Releases). Si elle est plus recente, la fenetre
;  se grise et propose "Install now" ou "Later".
;  L'installation garde les reglages, profils et presets de chacun.
; =====================================================================

; depot GitHub ou sont publiees les mises a jour : "pseudo/nom-du-depot"
global UPDATE_REPO := "NovaMacro/NovaMacro-1.0.1"

NovaVersion() {
    static v := ""
    if (v = "")
        v := FileExist(A_ScriptDir "\version.txt") ? Trim(FileRead(A_ScriptDir "\version.txt"), " `t`r`n") : "1.0.0"
    return v
}

; ---------- verification ----------
global UpdReq := 0, UpdManual := false, UpdInfo := 0

UpdateUrl() => "https://api.github.com/repos/" UPDATE_REPO "/releases?per_page=5"   ; pre-releases comprises

; bouton "Check for updates" : sans bloquer la fenetre
CheckUpdate(manual := false, *) {
    global UpdReq, UpdManual
    if (UPDATE_REPO = "") {
        if manual
            MsgBox "The GitHub update repository is not set up yet.", "Nova Macro", "Icon!"
        return
    }
    if Running && !manual
        return
    UpdManual := manual
    try {
        UpdReq := ComObject("WinHttp.WinHttpRequest.5.1")
        UpdReq.Open("GET", UpdateUrl(), true)
        UpdReq.SetRequestHeader("User-Agent", "NovaMacro")
        UpdReq.SetRequestHeader("Accept", "application/vnd.github+json")
        UpdReq.Send()
        SetTimer UpdatePoll.Bind(A_TickCount), -200
    } catch as e {
        if manual
            MsgBox "Could not check for updates:`n" e.Message, "Nova Macro", "Icon!"
    }
}

UpdatePoll(t0) {
    try done := UpdReq.WaitForResponse(0)
    catch
        done := true
    if !done {
        if (A_TickCount - t0 < 15000)
            SetTimer UpdatePoll.Bind(t0), -250
        else if UpdManual
            MsgBox "GitHub is not answering, try again later.", "Nova Macro", "Icon!"
        return
    }
    try st := UpdReq.Status, txt := UpdReq.ResponseText
    catch as e {
        if UpdManual
            MsgBox "Could not check for updates: " e.Message, "Nova Macro", "Icon!"
        return
    }
    msg := UpdateRead(st, txt)
    if UpdInfo {
        if !Running
            ShowUpdate()
    } else if UpdManual
        MsgBox msg, "Nova Macro", InStr(msg, "latest") ? "Iconi" : "Icon!"
}

; pendant l'ecran de chargement : verification rapide (3 s max), sans message
CheckUpdateNow() {
    if (UPDATE_REPO = "")
        return
    req := ComObject("WinHttp.WinHttpRequest.5.1")
    req.SetTimeouts(1500, 1500, 3000, 3000)
    req.Open("GET", UpdateUrl(), false)
    req.SetRequestHeader("User-Agent", "NovaMacro")
    req.SetRequestHeader("Accept", "application/vnd.github+json")
    req.Send()
    UpdateRead(req.Status, req.ResponseText)
}

; lit la reponse de GitHub : remplit UpdInfo si une version plus recente existe, sinon renvoie un message
UpdateRead(st, txt) {
    global UpdInfo
    UpdInfo := 0
    if (st = 404)
        return "Could not check for updates: the repository " UPDATE_REPO " was not found (is it public?)."
    if (st != 200)
        return "Could not check for updates (response " st ")."
    ; premiere release publiee (les brouillons sont ignores)
    rel := "", p := 1
    while (p := RegExMatch(txt, '"tag_name"\s*:', , p)) {
        q := RegExMatch(txt, '"tag_name"\s*:', , p + 10)
        chunk := q ? SubStr(txt, p, q - p) : SubStr(txt, p)
        if !RegExMatch(chunk, '"draft"\s*:\s*true') {
            rel := chunk
            break
        }
        if !q
            break
        p := q
    }
    if (rel = "")
        return "No release published on GitHub yet."
    ; numero de version : tag (v1.0.3), sinon titre de la release, sinon nom du zip
    ver := ""
    for pat in ['"tag_name"\s*:\s*"v?(\d+(?:\.\d+)+)"', '"name"\s*:\s*"[^"]*?(\d+(?:\.\d+)+)[^"]*"', '"browser_download_url"\s*:\s*"[^"]*?(\d+(?:\.\d+)+)\.zip"']
        if RegExMatch(rel, pat, &m) {
            ver := m[1]
            break
        }
    if (ver = "")
        return "The latest release has no version number (use a tag like v1.0.3)."
    notes := "", url := ""
    if RegExMatch(rel, '"body"\s*:\s*"((?:[^"\\]|\\.)*)"', &b)
        notes := JsonUnescape(b[1])
    if RegExMatch(rel, '"browser_download_url"\s*:\s*"([^"]+\.zip)"', &u)
        url := u[1]
    else if RegExMatch(rel, '"zipball_url"\s*:\s*"([^"]+)"', &u)
        url := u[1]
    if (VerCompare(ver, NovaVersion()) <= 0) || (url = "")
        return "You already have the latest version (" NovaVersion() ")."
    UpdInfo := {ver: ver, notes: notes, url: url}
    Log("Update available: " ver)
    return ""
}

JsonUnescape(s) {
    s := StrReplace(s, "\r\n", "`n"), s := StrReplace(s, "\n", "`n"), s := StrReplace(s, "\r", "")
    s := StrReplace(s, '\"', '"'), s := StrReplace(s, "\/", "/"), s := StrReplace(s, "\t", "  ")
    return StrReplace(s, "\\", "\")
}

; ---------- fenetre grisee + carte de mise a jour ----------
global UpdDim := 0, UpdCard := 0, UpdStatus := 0

ShowUpdate() {
    global UpdDim, UpdCard, UpdStatus
    if !UpdInfo || UpdCard
        return
    WinGetClientPos &gx, &gy, &gw, &gh, MainGui
    ; voile sombre sur toute la macro
    UpdDim := Gui("+Owner" MainGui.Hwnd " -Caption +ToolWindow -DPIScale")
    UpdDim.BackColor := "000000"
    UpdDim.Show(Format("x{} y{} w{} h{} NA", gx, gy, gw, gh))
    WinSetTransparent 150, UpdDim
    MainGui.Opt("+Disabled")
    ; carte au centre
    w := 420, notes := UpdNotes(UpdInfo.notes), h := 196 + (notes != "" ? 20 * Min(6, StrSplit(notes, "`n").Length) : 0)
    g := Gui("+Owner" MainGui.Hwnd " -Caption +ToolWindow -DPIScale")
    g.BackColor := CLR["tile"], g.MarginX := g.MarginY := 0
    g.Add("Picture", "x24 y22 w40 h40", "HBITMAP:*" ImageHBM(A_ScriptDir "\assets\logo\nova_symbol_64.png", 40, 40, CLR["tile"]))
    g.SetFont("s14 c" CLR["txt"], "Segoe UI Semibold")
    g.Add("Text", "x76 y18 w320 BackgroundTrans", "Update available")
    g.SetFont("s10 c" CLR["dim"], "Segoe UI")
    g.Add("Text", "x76 y46 w320 BackgroundTrans", "Nova Macro " UpdInfo.ver " is available (you have " NovaVersion() ").")
    y := 82
    if (notes != "") {
        g.SetFont("s9 c" CLR["txt"], "Segoe UI")
        g.Add("Text", Format("x24 y{} w{} BackgroundTrans", y, w - 48), notes)
        y += 20 * Min(6, StrSplit(notes, "`n").Length) + 8
    }
    g.SetFont("s9 c" CLR["faint"], "Segoe UI")
    UpdStatus := g.Add("Text", Format("x24 y{} w{} BackgroundTrans", y, w - 48), "Your settings, accounts and presets are kept.")
    y += 34
    MakeBtn(g, 24, y, 180, 36, "Install now", CLR["acc"], CLR["accTxt"], (*) => InstallUpdate())
    MakeBtn(g, w - 24 - 150, y, 150, 36, "Later", CLR["pill"], CLR["txt"], (*) => CloseUpdate())
    h := y + 36 + 22
    g.OnEvent("Escape", (*) => CloseUpdate())
    g.Show(Format("x{} y{} w{} h{}", gx + (gw - w) // 2, gy + (gh - h) // 2, w, h))
    WinSetRegion(Format("0-0 w{} h{} R18-18", w, h), g)
    UpdCard := g
}

; quelques lignes des notes de version, sans le markdown
UpdNotes(txt) {
    out := "", n := 0
    for line in StrSplit(txt, "`n") {
        line := Trim(RegExReplace(line, "^[#>*\-\s]+"), " `t`r")
        if (line = "")
            continue
        out .= (n ? "`n" : "") Chr(0x2022) " " SubStr(line, 1, 60)
        if (++n >= 6)
            break
    }
    return out
}

MakeBtn(g, x, y, w, h, text, fill, color, cb) {
    p := g.Add("Picture", Format("x{} y{} w{} h{}", x, y, w, h), "HBITMAP:*" RoundHBM(w, h, 8, fill, CLR["tile"]))
    g.SetFont("s10 bold c" color, "Segoe UI")
    t := g.Add("Text", Format("x{} y{} w{} h{} Center 0x200 BackgroundTrans", x, y, w, h), text)
    p.OnEvent("Click", cb), t.OnEvent("Click", cb)
}

CloseUpdate() {
    global UpdDim, UpdCard
    try UpdCard.Destroy()
    try UpdDim.Destroy()
    UpdCard := UpdDim := 0
    MainGui.Opt("-Disabled")
    WinActivate MainGui
}

; ---------- installation ----------
; telecharge le zip, l'extrait, puis un petit programme remplace les fichiers une fois la macro fermee
InstallUpdate() {
    tmp := A_Temp "\NovaUpdate"
    try DirDelete tmp, true
    DirCreate tmp
    UpdStatus.Value := "Downloading version " UpdInfo.ver "..."
    try Download UpdInfo.url, tmp "\update.zip"
    catch as e {
        UpdStatus.Value := "Download failed: " e.Message
        return
    }
    UpdStatus.Value := "Extracting..."
    RunWait "powershell -NoProfile -ExecutionPolicy Bypass -Command `"Expand-Archive -LiteralPath '" tmp "\update.zip' -DestinationPath '" tmp "\files' -Force`"", , "Hide"
    src := tmp "\files"
    ; zip de GitHub = un seul dossier a l'interieur
    if !FileExist(src "\NovaMacro.ahk")
        Loop Files src "\*", "D"
            if FileExist(A_LoopFileFullPath "\NovaMacro.ahk")
                src := A_LoopFileFullPath
    if !FileExist(src "\NovaMacro.ahk") {
        UpdStatus.Value := "The downloaded file is not a Nova Macro version."
        return
    }
    UpdStatus.Value := "Installing... the macro will restart."
    ; le programme d'installation tourne avec une copie d'AutoHotkey (l'original va etre remplace)
    FileCopy A_AhkPath, tmp "\ahk.exe", 1
    FileCopy A_ScriptDir "\lib\Updater.ahk", tmp "\updater.ahk", 1
    Run '"' tmp '\ahk.exe" "' tmp '\updater.ahk" ' ProcessExist() ' "' src '" "' A_ScriptDir '"'
    Log("Installing update " UpdInfo.ver)
    ExitApp
}
