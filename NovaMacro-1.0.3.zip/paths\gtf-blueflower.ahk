﻿if (MoveMethod = "Cannon") {
    bm_gotoramp()
    bm_gotocannon()
    send "{e down}"
    HyperSleep(100)
    send "{e up}{" LeftKey " down}"
    HyperSleep(675)
    send "{space 2}"
    HyperSleep(2000)
    send "{" LeftKey " up}"
    HyperSleep(1250)
    send "{space}{" RotLeft " 2}"
    Sleep 1000
} else {
    bm_gotoramp()
    bm_Walk(86.875, BackKey, LeftKey) ; 88.875
    bm_Walk(28, LeftKey) ; 27
    send "{" RotLeft " 2}"
}
