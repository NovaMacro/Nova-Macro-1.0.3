﻿bm_gotoramp()
bm_Walk(14, BackKey)
send "{" RotRight " 1}"
bm_Walk(25, RightKey)
bm_Walk(15, FwdKey)
bm_Walk(9, BackKey)
send "{" RotRight " 1}"
