﻿; =====================================================================
;  Deconnexion / reconnexion automatique
; =====================================================================

; renvoie true si une reconnexion a eu lieu
CheckDisconnect(force := false) {
    if !force {
        if GetRobloxHWND() && UpdateWindow() && !WinExist("Roblox Crash") {
            if !FindBitmap("disconnected", windowWidth // 2, windowHeight // 2, 200, 80, 2)
                return false
        }
        Stats["disconnects"]++
        SetStatus("Disconnected", "Roblox closed or disconnected")
        Hook("Disconnected from Roblox", "Roblox is closed or shows a disconnect message. " (S["R_Enable"] ? "Reconnecting automatically..." : "Auto reconnect is off: restart Roblox yourself."), "net", [["Disconnects (session)", Stats["disconnects"]], ["Server", S["R_Link"] ? "prive" : "public"]], true, 1)
    }
    ReleaseAll()
    if !S["R_Enable"] {
        SetStatus("Pause", "auto reconnect off, waiting")
        while !GetRobloxHWND() {
            CheckStop()
            Sleep 5000
        }
        return true
    }
    Reconnect()
    return true
}

Reconnect() {
    start := Now()
    type := "", code := ""
    if (link := Trim(S["R_Link"])) {
        if RegExMatch(link, "i)(?<=privateServerLinkCode=)(.{32})", &m)
            type := "LinkCode", code := m[0]
        else if RegExMatch(link, "i)(?<=share\?code=)(.{32})(?=&type=Server)", &m)
            type := "ShareCode", code := m[0]
        else
            Log("Invalid private server link, using a public server")
    }
    Loop {
        CheckStop()
        i := A_Index
        usePrivate := code && (i <= 10 || !S["R_Public"])
        SetStatus("Reconnect", "try " i (usePrivate ? " (private server)" : " (public server)"))
        if (Mod(i - 1, 5) < 2 || i = 1)
            CloseRoblox()
        RunDeeplink(usePrivate ? type : "", usePrivate ? code : "")

        ; attente de la fenetre Roblox (4 min max, au cas ou Roblox se met a jour)
        ok := false
        Loop 240 {
            CheckStop()
            if GetRobloxHWND() {
                ActivateRoblox()
                ok := true
                break
            }
            Sleep 1000
        }
        if !ok
            continue
        ; attente du chargement du jeu (6 min max)
        loaded := false, seenLoading := false
        Loop 360 {
            CheckStop()
            ActivateRoblox()
            if !UpdateWindow()
                break
            pBM := Gdip_BitmapFromScreen(windowX "|" windowY + 30 "|" windowWidth "|" windowHeight - 30)
            isLoading := (Gdip_ImageSearch(pBM, bitmaps["loading"], , , , , 150, 4) = 1)
            isScience := (Gdip_ImageSearch(pBM, bitmaps["science"], , , , , 150, 2) = 1)
            isDisc := (Gdip_ImageSearch(pBM, bitmaps["disconnected"], , , , , , 2) = 1)
            Gdip_DisposeImage(pBM)
            if isDisc
                break
            if isLoading
                seenLoading := true
            if isScience || (seenLoading && !isLoading) {
                loaded := true
                break
            }
            Sleep 1000
        }
        if !loaded
            continue
        Sleep 2000
        UpdateWindow()
        MouseMove windowX + windowWidth // 2, windowY + windowHeight // 2
        SetTime("collect_clock")   ; l'horloge est remise a zero en changeant de serveur
        SetTime("reconnect_last")
        if ClaimHive() {
            SetStatus("Reconnecte", "en " Round((Now() - start) / 60, 1) " min, " i " try(s)")
            Hook("Reconnecte", "The game is loaded and the hive is claimed.", "good", [["Duration", Round((Now() - start) / 60, 1) " min"], ["Essais", i], ["Server", usePrivate ? "prive" : "public"], ["Hive", "slot " HiveSlot]], true, 1)
            return true
        }
    }

    RunDeeplink(type := "", code := "") {
        switch type {
            case "LinkCode": try Run '"roblox://placeID=1537690962&linkcode=' code '"'
            case "ShareCode": try Run '"roblox://navigation/share_links?code=' code '&type=Server"'
            default: try Run '"roblox://placeID=1537690962"'
        }
    }
}

CloseRoblox() {
    if (hwnd := GetRobloxHWND()) {
        GetRobloxClientPos(hwnd)
        if (windowHeight >= 500) {
            ActivateRoblox()
            SetKeyDelay 250 + KeyDelay
            Send "{" SC_Esc "}{" SC_L "}{" SC_Enter "}"
            SetKeyDelay KeyDelay
        }
        try WinClose "Roblox"
        Sleep 500
        try WinClose "Roblox"
        Sleep 4500
    }
    for p in ComObjGet("winmgmts:").ExecQuery("SELECT * FROM Win32_Process WHERE Name LIKE '%Roblox%' OR CommandLine LIKE '%ROBLOXCORPORATION%'")
        try ProcessClose p.ProcessID
}

; reprend une ruche apres une reconnexion (on garde la sienne si elle est libre)
ClaimHive() {
    global HiveSlot
    Loop 5 {
        CheckStop()
        ActivateRoblox()
        UpdateWindow()
        SafeMouse()
        if (A_Index > 1) {
            SetKeyDelay 250 + KeyDelay
            Send "{" SC_Esc "}{" SC_R "}{" SC_Enter "}"
            SetKeyDelay KeyDelay
            Sleep 8000
        }
        Sleep 500
        Send "{" ZoomOut " 8}"
        ; depuis le spawn, on va devant la ruche 1
        Send "{" RightKey " down}"
        Walk(4)
        Send "{" FwdKey " down}"
        Walk(20)
        Send "{" RightKey " up}{" FwdKey " up}"

        free := Map()
        Loop HiveSlot {
            if (A_Index > 1)
                bm_Walk(9.2, LeftKey)
            Sleep 500
            if ClaimVisible()
                free[A_Index] := 1
        }
        slot := 0
        if free.Has(HiveSlot)
            slot := HiveSlot
        else if free.Count {
            for k in free {
                slot := k
                break
            }
            bm_Walk((HiveSlot - slot) * 9.2, RightKey)
            Sleep 500
            if !ClaimVisible()
                slot := 0
        } else {
            Loop (6 - HiveSlot) {
                bm_Walk(9.2, LeftKey)
                Sleep 500
                if ClaimVisible() {
                    slot := HiveSlot + A_Index
                    break
                }
            }
        }
        if slot {
            Send "{" SC_E " down}"
            Sleep 100
            Send "{" SC_E " up}"
            if (slot != HiveSlot) {
                SaveSetting("HiveSlot", slot)
                ApplyGlobals()
                try RefreshControl("HiveSlot")
            }
            SetStatus("Hive", "slot " slot " claimed")
            Sleep 1000
            return true
        }
        Log("No free hive found (try " A_Index ")")
        if (A_Index = 5)
            Hook("No free hive", "Could not claim a hive after reconnecting.", "bad", "", true, 1)
    }
    return false

    ClaimVisible() {
        UpdateWindow()
        ; ferme les notifications "un ami a rejoint"
        Loop 5 {
            closed := false
            for , bm in bitmaps["FriendJoin"]
                if FindBitmapObj(bm, windowWidth // 2 - 200, offsetY, 400, 125, 6) {
                    MouseMove windowX + windowWidth // 2 - 3, windowY + 24
                    Click
                    SafeMouse()
                    Sleep 500
                    closed := true
                }
            if !closed
                break
        }
        return TopBitmap("claimhive")
    }
}

FindBitmapObj(bm, x, y, w, h, variation := 2) {
    pBM := Gdip_BitmapFromScreen(Round(windowX + x) "|" Round(windowY + y) "|" Round(w) "|" Round(h))
    found := (Gdip_ImageSearch(pBM, bm, , , , , , variation) = 1)
    Gdip_DisposeImage(pBM)
    return found
}
