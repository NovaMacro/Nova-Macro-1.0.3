﻿if (MoveMethod = "walk") {
    bm_gotoramp()
    bm_Walk(67.5, BackKey, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(31, FwdKey)
    bm_Walk(7, FwdKey, LeftKey)
    bm_Walk(30.25, LeftKey)
    bm_Walk(35, FwdKey, LeftKey)
    bm_Walk(3, BackKey, RightKey)
}
else {
    bm_gotoramp()
    bm_gotocannon()
    send "{e down}"
    HyperSleep(100)
    send "{e up}{" RightKey " down}{" BackKey " down}"
    HyperSleep(750)
    send "{space 2}"
    HyperSleep(1000)
    send "{" RightKey " up}{" BackKey " up}"
    HyperSleep(800)
    send "{space}{" RotRight " 2}"
    Sleep 2000
    bm_Walk(10, FwdKey, RightKey)
    bm_Walk(15, RightKey)
    bm_Walk(15, FwdKey)
    bm_Walk(3, BackKey, LeftKey)
}
;path 230729 noobyguy
; edited by Lorddrak
