﻿if (MoveMethod = "Cannon") {
    bm_gotoramp()
    bm_gotocannon()
    send "{" RotLeft " 1}"
    send "{e down}{" FwdKey " down}"
    HyperSleep(100)
    send "{e up}"
    HyperSleep(1100)
    send "{space 2}{" FwdKey " up}"
    HyperSleep(3767) ; OH MY GOD SIX SEVEEEEN
    send "{space}"
    send "{" RotRight " 1}"
    HyperSleep(1500)
} else {
    bm_gotoramp()
    bm_Walk(44.75, BackKey, LeftKey) ; 47.25
    bm_Walk(52.5, LeftKey)
    bm_Walk(2.8, BackKey, RightKey)
    bm_Walk(7.7, BackKey)
    bm_Walk(20.5, LeftKey)
    bm_Walk(5.5, FwdKey)
    ;path 230212 zaappiix
    ;path 230630 noobyguy - changed line 6, 7, 8
    ;path 250927 dully176 - calibrated cannon path
}

; edited by Lorddrak