﻿if (MoveMethod = "Cannon") {
    bm_gotoramp()
    bm_gotocannon()
    send "{e down}"
    HyperSleep(100)
    send "{e up}{" LeftKey " down}"
    HyperSleep(1850)
    send "{space 2}"
    HyperSleep(2750)
    send "{" LeftKey " up}{" RotLeft " 2}{" FwdKey " down}{" LeftKey " down}"
    HyperSleep(900)
    send "{" LeftKey " up}"
    HyperSleep(1650)
    send "{" FwdKey " up}{space}"
    Sleep 1000
} else {
    bm_gotoramp()
    bm_Walk(67.5, BackKey, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(30, FwdKey)
    bm_Walk(20, FwdKey, RightKey)
    send "{" RotRight " 2}"
    bm_Walk(43.5, FwdKey)
    bm_Walk(18, RightKey)
    bm_Walk(6, FwdKey)
    send "{" RotLeft " 2}"
    bm_Walk(43, FwdKey)
    bm_Walk(30, FwdKey, RightKey)
    bm_Walk(24, RightKey)
    bm_Walk(10, BackKey)
    send "{" RotRight " 2}"
    ;path 230630 noobyguy
}
