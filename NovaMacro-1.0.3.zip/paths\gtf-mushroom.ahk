﻿bm_gotoramp()
bm_Walk(36, BackKey, LeftKey)
send "{" RotRight " 4}"
bm_Walk(31.5, FwdKey)
