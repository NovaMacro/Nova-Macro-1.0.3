﻿if (MoveMethod = "walk")
{
    bm_gotoramp()
    bm_Walk(67.5, BackKey, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(31, FwdKey)
    bm_Walk(7.8, LeftKey)
    bm_Walk(10, BackKey)
    bm_Walk(5, RightKey)
    bm_Walk(1.5, FwdKey)
    bm_Walk(60, LeftKey)
    bm_Walk(3.75, RightKey)
    bm_Walk(38, FwdKey)
    send "{" RotLeft " 4}"
    bm_Walk(14, RightKey)
    bm_Walk(15, FwdKey, LeftKey)
    bm_Walk(1, BackKey)
    HyperSleep(200)
    bm_Walk(16, RightKey)
    bm_Walk(49, FwdKey)
    send "{" RotLeft " 4}"
    bm_Walk(10, RightKey)
    bm_Walk(12, RightKey, FwdKey)
    bm_Walk(7, BackKey, LeftKey)
    send "{" RotLeft " 2}"
}
else {
    bm_gotoramp()
    bm_gotocannon()
    send "{e down}"
    HyperSleep(100)
    send "{e up}{" RightKey " down}"
    HyperSleep(550)
    send "{space 2}"
    HyperSleep(2500)
    send "{" RightKey " up}{space}{" RotLeft " 4}"
    HyperSleep(1000)
    bm_Walk(17, FwdKey)
    bm_Walk(10, RightKey)
    bm_Walk(8, FwdKey, RightKey)
    bm_Walk(8, FwdKey)
    bm_Walk(7, BackKey, LeftKey)
    send "{" RotLeft " 2}"
}
;path 230729 noobyguy
