﻿if (MoveMethod = "Cannon") {
    bm_gotoramp()
    bm_gotocannon()
    send "{e down}"
    HyperSleep(100)
    send "{e up}{" RightKey " down}{" BackKey " down}"
    HyperSleep(700)
    send "{space 2}"
    HyperSleep(1700)
    send "{" RightKey " up}{" BackKey " up}{space}{" RotRight " 2}"
    Sleep 2000
} else {
    bm_gotoramp()
    bm_Walk(67.5, BackKey, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(31, FwdKey)
    bm_Walk(7, FwdKey, LeftKey)
    bm_Walk(33.25, LeftKey)
    bm_Walk(6.75, FwdKey, LeftKey)
    send "{" RotLeft " 2}"
    ;path 230630 noobyguy adjusted line 7
}
