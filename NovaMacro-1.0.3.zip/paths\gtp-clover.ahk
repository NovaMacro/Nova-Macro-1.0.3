﻿if (MoveMethod = "walk")
{
    bm_gotoramp()
    bm_Walk(44.75, BackKey, LeftKey) ; 47.25
    bm_Walk(52.5, LeftKey)
    bm_Walk(2.8, BackKey, RightKey)
    bm_Walk(7.7, BackKey)
    bm_Walk(20.5, LeftKey)
    bm_Walk(6.5, FwdKey)

    ; going to corner
    bm_Walk(20, FwdKey, LeftKey)
    bm_Walk(3, FwdKey)
    bm_Walk(3, LeftKey)

    ; out of corner
    bm_Walk(5, RightKey)
    bm_Walk(10, RightKey, FwdKey)
    bm_Walk(3, BackKey)
}
else
{
    bm_gotoramp()
    bm_gotocannon()
    send "{e down}"
    HyperSleep(100)
    send "{e up}{" LeftKey " down}{" FwdKey " down}"
    HyperSleep(525) ; change to 625? idea
    send "{space 2}"
    HyperSleep(1250)
    send "{" FwdKey " up}"
    HyperSleep(3000)
    send "{" LeftKey " up}{space}"
    HyperSleep(700)

    ; going to corner
    bm_Walk(20, FwdKey, LeftKey)
    bm_Walk(3, FwdKey)
    bm_Walk(3, LeftKey)

    ; out of corner
    bm_Walk(5, RightKey)
    bm_Walk(10, RightKey, FwdKey)
    bm_Walk(3, BackKey)
}
; by Lorddrak for beesmas (stockings pmo)
