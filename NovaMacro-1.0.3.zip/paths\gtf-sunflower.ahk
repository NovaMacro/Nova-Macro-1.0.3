﻿bm_gotoramp()
bm_Walk(9, BackKey)
bm_Walk(6.75, BackKey, RightKey)
send "{" RotRight " 2}"
bm_Walk(29, RightKey)
;path 230212 zaappiix
