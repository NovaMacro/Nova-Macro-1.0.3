﻿if (MoveMethod = "Cannon") {
    bm_gotoramp()
    bm_gotocannon()
    send "{" RotRight " 3}"
    send "{e down}{" FwdKey " down}"
    HyperSleep(100)
    send "{e up}"
    HyperSleep(967)
    send "{space 2}{" FwdKey " up}"
    HyperSleep(2600)
    send "{space}"
    HyperSleep(1500)
    send "{" RotLeft " 3}"
} else {
    bm_gotoramp()
    bm_Walk(67.5, BackKey, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(31, FwdKey)
    bm_Walk(7.8, LeftKey)
    bm_Walk(10, BackKey)
    bm_Walk(5, RightKey)
    bm_Walk(1.5, FwdKey)
    bm_Walk(60, LeftKey)
    bm_Walk(49.5, FwdKey)
    send "{" RotRight " 4}"
    bm_Walk(13.5, LeftKey)
    ;path 230630 noobyguy
    ;path 250927 dully176 - calibrated cannon path
}
