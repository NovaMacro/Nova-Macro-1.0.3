﻿if (MoveMethod = "walk")
{
	bm_gotoramp()
	bm_Walk(67.5, BackKey, LeftKey)
	send "{" RotRight " 4}"
	bm_Walk(31.5, FwdKey)
	bm_Walk(9, LeftKey)
	bm_Walk(9, BackKey)
	bm_Walk(58.5, LeftKey)
	bm_Walk(49.5, FwdKey)
	bm_Walk(20.25, LeftKey)
	send "{" RotRight " 4}"
	bm_Walk(60.75, FwdKey)
	send "{" RotRight " 2}"
	bm_Walk(9, BackKey)
	bm_Walk(15.75, BackKey, RightKey)
	bm_Walk(29.7, LeftKey)
	bm_Walk(11.25, FwdKey)
	bm_Walk(13.5, LeftKey)
}
else
{
	bm_gotoramp()
	Send "{space down}{" RightKey " down}"
	Sleep 100
	Send "{space up}"
	Walk(2)
	Send "{" FwdKey " down}"
	Walk(1.8)
	Send "{" FwdKey " up}"
	Walk(30)
	send "{space down}"
	HyperSleep(300)
	send "{space up}{" FwdKey " down}"
	Walk(4)
	send "{" FwdKey " up}"
	Walk(3)
	send "{" RightKey " up}{" RotRight " 2}{space down}"
	HyperSleep(100)
	send "{space up}"
	bm_Walk(3, FwdKey)
	HyperSleep(1000)
	send "{space down}{" RightKey " down}"
	HyperSleep(100)
	send "{space up}"
	HyperSleep(300)
	send "{space}{" RightKey " up}"
	HyperSleep(1000)
	bm_Walk(8, FwdKey, RightKey)
	bm_Walk(1, FwdKey)
	bm_Walk(6.75, RightKey)
	HyperSleep(1000)
	send "{" RotRight " 4}"
	HyperSleep(100)
	bm_Walk(9, FwdKey)
	bm_Walk(3, FwdKey, LeftKey)
	bm_Walk(5, FwdKey, RightKey)
}
;path 230629 noobyguy
