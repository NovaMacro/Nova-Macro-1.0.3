﻿if (MoveMethod = "walk")
{
	bm_gotoramp()
	bm_Walk(67.5, BackKey, LeftKey)
	send "{" RotRight " 4}"
	bm_Walk(31.5, FwdKey)
	bm_Walk(9, LeftKey)
	bm_Walk(9, BackKey)
	bm_Walk(58.5, LeftKey)
	bm_Walk(49.5, FwdKey)
	bm_Walk(2.25, BackKey, LeftKey)
	bm_Walk(36, LeftKey)
	send "{" RotLeft " 2}"
	send "{" FwdKey " down}"
	send "{space down}"
	HyperSleep(300)
	send "{space up}"
	HyperSleep(500)
	send "{" RotRight " 2}"
	HyperSleep(1000)
	send "{space down}"
	HyperSleep(300)
	send "{space up}"
	Walk(6)
	send "{" FwdKey " up}"
	bm_Walk(6, RightKey)
	bm_Walk(7, FwdKey)
	bm_Walk(6, LeftKey)
	bm_Walk(3, RightKey)
	bm_Walk(32, FwdKey)
	bm_Walk(8.5, BackKey)
}
else
{
	bm_gotoramp()
	bm_gotocannon()
	send "{e down}"
	HyperSleep(100)
	send "{e up}{" RightKey " down}{" BackKey " down}"
	HyperSleep(1150)
	send "{space 2}"
	HyperSleep(4050)
	send "{" BackKey " up}"
	HyperSleep(1000)
	send "{" RightKey " up}"
	Sleep 2200
	send "{" RotRight " 4}"
	bm_Walk(14, LeftKey)
	bm_Walk(4, FwdKey)
	bm_Walk(3, BackKey)
	bm_Walk(11, RightKey)
}
