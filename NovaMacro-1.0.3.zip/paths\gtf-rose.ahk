﻿if (MoveMethod = "Cannon") {
    bm_gotoramp()
    bm_gotocannon()
    send "{" RotRight " 2}"
    send "{e down}{" FwdKey " down}"
    HyperSleep(100)
    send "{e up}"
    HyperSleep(580)
    send "{space 2}{" FwdKey " up}"
    HyperSleep(3050)
    send "{space}"
    HyperSleep(2000)
} else {
    bm_gotoramp()
    bm_Walk(67.5, BackKey, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(31, FwdKey)
    bm_Walk(7.8, LeftKey)
    bm_Walk(10, BackKey)
    bm_Walk(5, RightKey)
    bm_Walk(1.5, FwdKey)
    bm_Walk(60, LeftKey)
    bm_Walk(3.75, RightKey)
    bm_Walk(38, FwdKey)
    send "{" RotLeft " 4}"
    bm_Walk(14, RightKey)
    bm_Walk(15, FwdKey, LeftKey)
    bm_Walk(1, BackKey)
    HyperSleep(200)
    bm_Walk(16, RightKey)
    bm_Walk(49, FwdKey)
    send "{" RotRight " 2}"
    ;path 230630 noobyguy
    ;path 250927 dully176 - calibrated cannon path
}
