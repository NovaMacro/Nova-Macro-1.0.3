﻿bm_Walk(42, RightKey)
send "{" RotLeft " 4}"
bm_Walk(45, FwdKey)
bm_Walk(50, LeftKey)
bm_Walk(49, FwdKey)
send "{" RotRight " 2}"
bm_Walk(13.5, FwdKey)
bm_Walk(1.5, BackKey) ;walk backwards to avoid thicker hives
bm_Walk(10, RightKey) ;walk to ramp
bm_Walk(2.7, BackKey) ;center with hive pads

; [2024-01-15/rpertusio] Avoid using corner (Hive 1 and ramp) where character gets stuck after 2024-01-12 BSS update
; [2024-01-15/rpertusio] Updated camera angle to 'follow' user to hive, less disorienting
