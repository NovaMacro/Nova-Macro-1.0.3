﻿; =====================================================================
;  Journal, statut et notifications Discord (webhook)
; =====================================================================

global LogLines := []

Log(msg) {
    LogLines.Push(FormatTime(, "HH:mm:ss") "  " msg)
    if (LogLines.Length > 300)
        LogLines.RemoveAt(1)
    try UI_AppendLog()
    try FileAppend FormatTime(, "yyyy-MM-dd HH:mm:ss") "  " msg "`n", A_ScriptDir "\macro.log", "UTF-8"
}

; note une erreur avec tous les details (variable, fichier, ligne, pile d'appels)
LogError(e, where := "") {
    file := ""
    try SplitPath(e.File, &file)
    Log("ERROR " where " : " e.Message (e.Extra != "" ? " [" e.Extra "]" : "") " - " file " line " e.Line)
    try Hook("Error " where, e.Message, "bad", [["Detail", e.Extra], ["File", file " line " e.Line]], false, 3)
    try {
        for line in StrSplit(e.Stack, "`n", "`r")
            if (A_Index <= 6 && Trim(line) != "")
                Log("    " Trim(line))
    }
}

global LastStatus := ""
SetStatus(a, b := "") {
    global LastStatus
    txt := a (b != "" ? " : " b : "")
    LastStatus := txt
    try UI_SetStatus(txt)
    Log(txt)
}

; =====================================================================
;  Webhook Discord : messages detailles (embed avec champs, couleur,
;  capture d'ecran, heure, duree de session)
;  niveau : 1 = essentiel, 2 = important, 3 = tout
; =====================================================================

global HOOK_STYLE := Map(
    "start", [0x22C55E, 0x1F680], "stop", [0x9CA3AF, 0x23F9], "pause", [0xF59E0B, 0x23F8],
    "farm", [0xF2B01E, 0x1F33B], "honey", [0xF59E0B, 0x1F36F], "travel", [0x60A5FA, 0x1F9ED],
    "collect", [0x14B8A6, 0x1F381], "bug", [0x84CC16, 0x1F41E], "boss", [0xA855F7, 0x2694],
    "vb", [0x7C3AED, 0x1F319], "planter", [0x22C55E, 0x1F331], "quest", [0x3B82F6, 0x1F4DC],
    "net", [0xEF4444, 0x1F50C], "good", [0x22C55E, 0x2705], "bad", [0xEF4444, 0x274C],
    "warn", [0xF59E0B, 0x26A0], "info", [0x3B82F6, 0x1F41D], "report", [0x6366F1, 0x1F4CA],
    "death", [0x991B1B, 0x1F480], "live", [0xF2B01E, 0x1F534])

HookLevel() => (S["D_Level"] = "All") ? 3 : (S["D_Level"] = "Essential") ? 1 : 2
HookReady() => S["D_Enable"] && RegExMatch(S["D_Webhook"], "i)^https://(\w+\.)?discord(app)?\.com/api/webhooks/")

; construit l'embed (titre, description, champs, pied de page, image)
EmbedJson(title, desc, kind, fields, useShot) {
    st := HOOK_STYLE.Has(kind) ? HOOK_STYLE[kind] : HOOK_STYLE["info"]
    f := ""
    if IsObject(fields)
        for fl in fields
            if (fl.Length >= 2 && fl[2] != "")
                f .= (f ? "," : "") '{"name":"' JsonEsc(fl[1]) '","value":"' JsonEsc(String(fl[2])) '","inline":' ((fl.Length >= 3 && !fl[3]) ? "false" : "true") '}'
    return '{"title":"' JsonEsc(Chr(st[2]) "  " title) '"'
        . (desc != "" ? ',"description":"' JsonEsc(desc) '"' : "")
        . ',"color":' st[1]
        . (f ? ',"fields":[' f ']' : "")
        . ',"footer":{"text":"' JsonEsc("Nova Macro  •  account " CurrentAccount() "  •  session " Dur(Running ? A_TickCount - StartTick : 0) "  •  hive " HiveSlot "  •  " Chr(0x1F41D) " " HiveBees " bees") '"}'
        . ',"timestamp":"' FormatTime(A_NowUTC, "yyyy-MM-dd'T'HH:mm:ss") '.000Z"'
        . (useShot ? ',"image":{"url":"attachment://ss.jpg"}' : "") '}'
}

; prepare le corps de la requete (json seul, ou json + capture d'ecran en JPEG)
; small = capture reduite a 960 px de large (message en direct, envoi rapide)
BuildBody(json, useShot, &data, &ctype, small := false) {
    pBM := 0
    if (useShot && UpdateWindow()) {
        pBM := Gdip_BitmapFromScreen(windowX "|" windowY "|" windowWidth "|" windowHeight)
        if (small && windowWidth > 960) {
            pSmall := Gdip_ResizeBitmap(pBM, 960, Round(windowHeight * 960 / windowWidth), 7)
            Gdip_DisposeImage(pBM), pBM := pSmall
        }
    }
    if pBM {
        CreateFormData(&data, &ctype, [Map("name", "payload_json", "content-type", "application/json", "content", json)
            , Map("name", "files[0]", "filename", "ss.jpg", "content-type", "image/jpeg", "pBitmap", pBM, "ext", "JPG", "quality", small ? 60 : 80)])
        Gdip_DisposeImage(pBM)
    } else
        data := Utf8Array(StrReplace(json, ',"image":{"url":"attachment://ss.jpg"}', "")), ctype := "application/json; charset=utf-8"
}

; fields : tableau de [nom, valeur] ou [nom, valeur, false] pour une ligne entiere
Hook(title, desc := "", kind := "info", fields := "", shot := false, level := 2) {
    if !HookReady() || (level > HookLevel())
        return
    ping := ((kind = "bad" || kind = "net" || kind = "death") && S["D_Ping"] && S["D_UserID"] != "") ? "<@" S["D_UserID"] ">" : ""
    useShot := shot && S["D_Shots"]
    json := '{"username":"Nova Macro","content":"' JsonEsc(ping) '","embeds":[' EmbedJson(title, desc, kind, fields, useShot) ']}'
    try {
        BuildBody(json, useShot, &data, &ctype)
        HookQueue.Push([data, ctype, "POST", S["D_Webhook"]])
        SetTimer WebhookPump, -1
    } catch as e
        Log("Discord: message not prepared (" e.Message ")")
}

; ancien format court, garde pour compatibilite
Notify(msg, kind := "info", screenshot := false) => Hook(msg, "", kind, "", screenshot, 1)

WebhookBase(&q) {
    url := S["D_Webhook"], q := ""
    if (p := InStr(url, "?"))
        q := SubStr(url, p), url := SubStr(url, 1, p - 1)
    return url
}

; ---------- message "farm en direct" : UN message modifie en continu (toutes les 1,5 s par defaut) ----------
global LiveId := "", LiveCtx := "", LiveReq := ""

LiveEvery() => Max(1500, Round(Num(StrReplace(StrReplace(S["D_LiveEvery"], " s"), ",", "."), 1.5) * 1000))

; ctx : {c, t, packMax, limitMs} (reglages du champ et debut du farm)
LiveStart(ctx) {
    global LiveId := "", LiveCtx := ctx, LiveReq := ""
    if !HookReady() || !S["D_Live"]
        return
    json := '{"username":"Nova Macro","embeds":[' EmbedJson("Live gather: " ctx.c["Field"], "Updated continuously while gathering.", "live", LiveFields(ctx.c, 0, Pack(), ctx.packMax, ctx.limitMs), true) ']}'
    try {
        BuildBody(json, true, &data, &ctype, true)
        url := WebhookBase(&q)
        wr := ComObject("WinHttp.WinHttpRequest.5.1")
        wr.Option[9] := 2720
        ; envoi sans attendre : l'identifiant du message est lu au tick suivant (la fenetre ne gele pas)
        wr.Open("POST", url (q ? q "&" : "?") "wait=true", true)
        wr.SetRequestHeader("Content-Type", ctype)
        wr.SetTimeouts(0, 8000, 8000, 10000)
        wr.Send(data)
        LiveReq := wr, LiveId := "attente"
        SetTimer LiveTick, LiveEvery()
    } catch as e
        Log("Discord: live message failed (" e.Message ")")
}

; appele par un timer pendant le farm : nouvelle capture + sac + temps
LiveTick() {
    global LiveId
    if (LiveId = "" || !IsObject(LiveCtx)) {
        SetTimer LiveTick, 0
        return
    }
    if (LiveId = "attente") {   ; le message de depart n'est pas encore cree chez Discord
        try {
            if !LiveReq.WaitForResponse(0)
                return
            if RegExMatch(LiveReq.ResponseText, '"id":\s*"(\d+)",\s*"channel_id"', &m)
                LiveId := m[1]
            else
                LiveId := ""
        } catch
            LiveId := ""
        return
    }
    if Paused || InPath
        return
    ; la mise a jour precedente n'est pas encore arrivee chez Discord : on attend la suivante
    if IsObject(LiveReq) {
        try {
            if !LiveReq.WaitForResponse(0)
                return
        }
    }
    el := A_TickCount - LiveCtx.t
    SendLive("Live gather: " LiveCtx.c["Field"], "Updated continuously while gathering."
        , LiveFields(LiveCtx.c, el, Pack(), LiveCtx.packMax, LiveCtx.limitMs))
}

SendLive(title, desc, fields) {
    global LiveReq
    json := '{"embeds":[' EmbedJson(title, desc, "live", fields, true) '],"attachments":[{"id":0,"filename":"ss.jpg"}]}'
    try {
        BuildBody(json, true, &data, &ctype, true)
        url := WebhookBase(&q)
        wr := ComObject("WinHttp.WinHttpRequest.5.1")
        wr.Option[9] := 2720
        wr.Open("PATCH", url "/messages/" LiveId q, true)
        wr.SetRequestHeader("Content-Type", ctype)
        wr.SetTimeouts(0, 10000, 10000, 10000)
        wr.Send(data)
        LiveReq := wr
    }
}

; derniere mise a jour (resultat du farm) puis arret du direct
LiveStop(title, desc, fields) {
    global LiveId, LiveCtx
    SetTimer LiveTick, 0
    if (LiveId = "attente") {
        try {
            LiveReq.WaitForResponse(2)
            LiveId := RegExMatch(LiveReq.ResponseText, '"id":\s*"(\d+)",\s*"channel_id"', &m) ? m[1] : ""
        } catch
            LiveId := ""
    } else if (LiveId != "")
        try LiveReq.WaitForResponse(1)   ; la derniere image doit arriver apres la precedente
    if (LiveId != "")
        SendLive(title, desc, fields)
    LiveId := "", LiveCtx := ""
}

; file d'attente : envoi immediat, 0,45 s minimum entre deux messages (limite de Discord)
global HookQueue := []
WebhookPump(force := false) {
    static pending := [], last := 0
    while (pending.Length && A_TickCount - pending[1][2] > 60000)
        pending.RemoveAt(1)
    if !HookQueue.Length
        return
    if (!force && A_TickCount - last < 450) {
        SetTimer WebhookPump, -(450 - (A_TickCount - last) + 10)
        return
    }
    item := HookQueue.RemoveAt(1), last := A_TickCount
    try {
        wr := ComObject("WinHttp.WinHttpRequest.5.1")
        wr.Option[9] := 2720
        wr.Open(item[3], item[4], true)
        wr.SetRequestHeader("Content-Type", item[2])
        wr.SetTimeouts(0, 30000, 30000, 30000)
        wr.Send(item[1])
        pending.Push([wr, A_TickCount])
    } catch as e
        Log("Discord: sending failed (" e.Message ")")
    if HookQueue.Length
        SetTimer WebhookPump, -460
}

; envoie tout de suite les messages en attente (avant un arret / une pause)
HookFlush() {
    while HookQueue.Length {
        item := HookQueue.RemoveAt(1)
        try {
            wr := ComObject("WinHttp.WinHttpRequest.5.1")
            wr.Option[9] := 2720
            wr.Open(item[3], item[4], false)
            wr.SetRequestHeader("Content-Type", item[2])
            wr.SetTimeouts(0, 5000, 5000, 8000)
            wr.Send(item[1])
        }
        if HookQueue.Length
            Sleep 450
    }
}

Utf8Array(str) {
    len := StrPut(str, "UTF-8") - 1
    arr := ComObjArray(0x11, len)
    if len {
        buf := Buffer(len + 1)
        StrPut(str, buf, "UTF-8")
        DllCall("RtlMoveMemory", "Ptr", NumGet(ComObjValue(arr), 8 + A_PtrSize, "Ptr"), "Ptr", buf.Ptr, "Ptr", len)
    }
    return arr
}

JsonEsc(str) {
    str := StrReplace(str, "\", "\\")
    str := StrReplace(str, '"', '\"')
    str := StrReplace(str, "`r", "")
    str := StrReplace(str, "`n", "\n")
    return StrReplace(str, "`t", " ")
}

; toutes les stats de la session, pret pour un embed
SessionFields() => [["Total time", Dur(Running ? A_TickCount - StartTick : 0)], ["Gathering", Dur(Stats["gather"])]
    , ["Conversion", Dur(Stats["convert"])], ["Gathering cycles", Stats["cycles"]], ["Bug runs", Stats["bugs"]]
    , ["Bosses killed", Stats["bosses"]], ["Vicious Bees", Stats["vb"]], ["Collects", Stats["collects"]]
    , ["Quests turned in", Stats["quests"]], ["Disconnects", Stats["disconnects"]], ["Deaths", Stats["deaths"]]]

; resume des reglages actifs (message de demarrage)
SettingsFields() {
    fieldsTxt := ""
    Loop 3
        if (S["F" A_Index "_Field"] != "None")
            fieldsTxt .= A_Index ". " S["F" A_Index "_Field"] " - " S["F" A_Index "_Pattern"] " " S["F" A_Index "_Size"] "x" S["F" A_Index "_Width"]
                . ", " S["F" A_Index "_Mins"] " min / " S["F" A_Index "_Pack"] "%, return " StrLower(S["F" A_Index "_Return"]) "`n"
    on := []
    for c in COLLECT_LIST
        if S["C_" c[1]]
            on.Push(c[2])
    mobs := [], bosses := [], quests := []
    for m in MOB_LIST
        if S["K_" m[1]]
            mobs.Push(m[2])
    for b in BOSS_LIST
        if S["B_" b[1]]
            bosses.Push(b[2])
    for q in QUEST_LIST
        if S["Q_" q[1]]
            quests.Push(q[2])
    return [["Fields", fieldsTxt ? fieldsTxt : "none", false]
        , ["Speed", S["MoveSpeed"] " + auto haste"]
        , ["Movement", S["MoveMethod"]], ["Account", CurrentAccount()], ["Preset", CurrentPreset()], ["Hive", "slot " HiveSlot ", " HiveBees " bees"], ["Sprinkler", S["SprinklerType"]]
        , ["Collects", on.Length ? JoinList(on) : "none", false]
        , ["Bug run", mobs.Length ? JoinList(mobs) : "no"], ["Boss", bosses.Length ? JoinList(bosses) : "no"]
        , ["Vicious Bee", S["VB_Enable"] ? (S["VB_Daily"] ? "yes (daily bonus)" : "yes") : "no"]
        , ["Quests", quests.Length ? JoinList(quests) : "no"]
        , ["Reconnect", S["R_Enable"] ? (S["R_Link"] ? "yes (private server)" : "yes (public server)") : "no"]]
}

HourlyReport() {
    static last := A_TickCount
    if !Running || !S["D_Enable"] || !S["D_Hourly"] || (A_TickCount - last < 3600000)
        return
    last := A_TickCount
    f := SessionFields()
    f.Push(["Bag", Pack() "%"], ["Etat", Paused ? "paused" : "running"])
    Hook("Hourly report", "Summary of the last hour and the whole session.", "report", f, true, 1)
}

Dur(ms) => Format("{:02}:{:02}:{:02}", ms // 3600000, Mod(ms // 60000, 60), Mod(ms // 1000, 60))

; construit un envoi multipart (texte + image) pour Discord
CreateFormData(&retData, &contentType, fields)
{
	static chars := "0|1|2|3|4|5|6|7|8|9|a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z"

	chars := Sort(chars, "D| Random")
	boundary := SubStr(StrReplace(chars, "|"), 1, 12)
	hData := DllCall("GlobalAlloc", "UInt", 0x2, "UPtr", 0, "Ptr")
	DllCall("ole32\CreateStreamOnHGlobal", "Ptr", hData, "Int", 0, "PtrP", &pStream:=0, "UInt")

	for field in fields
	{
		str :=
		(
		'

		------------------------------' boundary '
		Content-Disposition: form-data; name="' field["name"] '"' (field.Has("filename") ? ('; filename="' field["filename"] '"') : "") '
		Content-Type: ' field["content-type"] '

		' (field.Has("content") ? (field["content"] "`r`n") : "")
		)

		utf8 := Buffer(length := StrPut(str, "UTF-8") - 1), StrPut(str, utf8, length, "UTF-8")
		DllCall("shlwapi\IStream_Write", "Ptr", pStream, "Ptr", utf8.Ptr, "UInt", length, "UInt")

		if field.Has("pBitmap")
		{
			try
			{
				pFileStream := Gdip_SaveBitmapToStream(field["pBitmap"], field.Has("ext") ? field["ext"] : "PNG", field.Has("quality") ? field["quality"] : 90)
				DllCall("shlwapi\IStream_Size", "Ptr", pFileStream, "UInt64P", &size:=0, "UInt")
				DllCall("shlwapi\IStream_Reset", "Ptr", pFileStream, "UInt")
				DllCall("shlwapi\IStream_Copy", "Ptr", pFileStream, "Ptr", pStream, "UInt", size, "UInt")
				ObjRelease(pFileStream)
			}
		}

		if field.Has("file")
		{
			DllCall("shlwapi\SHCreateStreamOnFileEx", "WStr", field["file"], "Int", 0, "UInt", 0x80, "Int", 0, "Ptr", 0, "PtrP", &pFileStream:=0)
			DllCall("shlwapi\IStream_Size", "Ptr", pFileStream, "UInt64P", &size:=0, "UInt")
			DllCall("shlwapi\IStream_Copy", "Ptr", pFileStream, "Ptr", pStream, "UInt", size, "UInt")
			ObjRelease(pFileStream)
		}
	}

	str :=
	(
	'

	------------------------------' boundary '--
	'
	)

	utf8 := Buffer(length := StrPut(str, "UTF-8") - 1), StrPut(str, utf8, length, "UTF-8")
	DllCall("shlwapi\IStream_Write", "Ptr", pStream, "Ptr", utf8.Ptr, "UInt", length, "UInt")
	ObjRelease(pStream)

	pData := DllCall("GlobalLock", "Ptr", hData, "Ptr")
	size := DllCall("GlobalSize", "Ptr", pData, "UPtr")

	retData := ComObjArray(0x11, size)
	pvData := NumGet(ComObjValue(retData), 8 + A_PtrSize, "Ptr")
	DllCall("RtlMoveMemory", "Ptr", pvData, "Ptr", pData, "Ptr", size)

	DllCall("GlobalUnlock", "Ptr", hData)
	DllCall("GlobalFree", "Ptr", hData, "Ptr")
	contentType := "multipart/form-data; boundary=----------------------------" boundary
}
