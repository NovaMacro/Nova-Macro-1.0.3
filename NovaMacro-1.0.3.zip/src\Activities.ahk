﻿; =====================================================================
;  Farm des champs, collectes, bug runs et boosters
; =====================================================================

FieldCfg(i) {
    c := Map()
    for k in ["Field", "Pattern", "Size", "Width", "InvFB", "InvLR", "RotDir", "RotCount", "Mins", "Pack", "Return", "Sprinkler"
        , "SprLoc", "SprDist", "Drift", "Shift", "AI"]
        c[k] := S["F" i "_" k]
    return c
}

; reglages pour farmer un champ demande par une quete
QuestFieldCfg(field) {
    for i in [1, 2, 3]
        if (S["F" i "_Field"] = field)
            c := FieldCfg(i)
    if !IsSet(c)
        c := FieldCfg(1), c["Field"] := field
    c["Mins"] := Num(S["Q_GatherMins"], 5)
    return c
}

NextFieldSlot() {
    static idx := 0
    Loop 3 {
        idx := Mod(idx, 3) + 1
        if (S["F" idx "_Field"] != "None")
            return idx
    }
    return 0
}

Gather(c) {
    global TCFBKey, AFCFBKey, TCLRKey, AFCLRKey
    field := c["Field"]
    ResetChar()
    GoField(field)
    Sleep 300
    ; sprinkler(s) : nombre et placement selon le type (Basic a Supreme), position et distance choisies
    if (c["Sprinkler"] && SprinklerType != "None") {
        loc := SPR_LOCS.Has(c["SprLoc"]) ? SPR_LOCS[c["SprLoc"]] : "Center"
        try bm_setSprinkler(field, loc, Max(1, Min(10, Num(c["SprDist"], 10))))
        catch as e
            LogError(e, "placing the sprinkler")
        Sleep 500
    }
    drift := c["Drift"] && (SprinklerType = "Supreme")
    if c["Shift"]
        try bm_setShiftLock(1)
    rot := c["RotDir"], n := Num(c["RotCount"], 1)
    if (rot = "Left")
        Send "{" RotLeft " " n "}"
    else if (rot = "Right")
        Send "{" RotRight " " n "}"
    TCFBKey := c["InvFB"] ? BackKey : FwdKey, AFCFBKey := c["InvFB"] ? FwdKey : BackKey
    TCLRKey := c["InvLR"] ? RightKey : LeftKey, AFCLRKey := c["InvLR"] ? LeftKey : RightKey

    reps := Max(1, Num(c["Width"], 3)), size := SIZE_VAL.Has(c["Size"]) ? SIZE_VAL[c["Size"]] : 1
    limitMs := Num(c["Mins"], 15) * 60000, packMax := Num(c["Pack"], 95)
    t := A_TickCount, reason := "", bag := 0
    global YouDied := 0
    ai := c["AI"] ? AIInit(c) : 0   ; Farm IA : pas de pattern, on vise les tokens
    LiveStart({c: c, t: t, packMax: packMax, limitMs: limitMs})
    SetStatus("Gathering", field (ai ? " (AI Gather, " ai.tokens.Length " token type(s))" : " (" c["Pattern"] " " c["Size"] " x" reps ")"))
    Hook("Gathering started: " field, QuestGatherField = field ? "Field requested by a quest." : "", "farm"
        , [["Pattern", ai ? "AI Gather" : c["Pattern"]], ["Size", ai ? "-" : c["Size"] " x" reps], ["Max time", c["Mins"] " min"]
        , ["Max bag", packMax "%"], ["Sprinkler", c["Sprinkler"] ? "yes" : "no"], ["Return", c["Return"]]], false, 3)
    fails := 0
    Loop {
        CheckStop()
        ; une erreur de detection ne doit pas faire perdre le farm : on la note et on continue
        try {
            if ai
                AIStep(ai)   ; quelques secondes d'IA : chasse de tokens / tour du sprinkler / retour au sprinkler
            else {
                RunPattern(c["Pattern"], reps, size)
                if drift   ; on se recale sur le saturator pour ne pas sortir du champ
                    bm_fieldDriftCompensation()
            }
            CheckBoosts("field")
            el := A_TickCount - t, bag := Pack()
            try UI_SetStatus(Format("Gather {} - {}:{:02} - bag {}%", field, el // 60000, Mod(el // 1000, 60), bag))
            if YouDied
                reason := "character died"
            else if (el >= limitMs)
                reason := "time is up"
            else if (bag >= packMax)
                reason := "bag full"
            else if VBReady()
                reason := "night (Vicious Bee)"
            else if (Mod(A_Index, 3) = 0 && CheckDisconnect()) {
                Stats["gather"] += A_TickCount - t
                LiveStop("Gathering interrupted: " field, "Disconnected from Roblox.", "")
                return
            }
            fails := 0
        } catch MacroStop as e {
            throw e
        } catch as e {
            ReleaseAll()
            LogError(e, "while gathering")
            if (++fails >= 3)
                reason := "detection errors"
            else if (A_TickCount - t >= limitMs)
                reason := "time is up"
        }
        if (reason != "")
            break
    }
    ReleaseAll()
    if ai
        AIFinish(ai)
    if c["Shift"]
        try bm_setShiftLock(0)
    farmMs := A_TickCount - t
    Stats["gather"] += farmMs
    Log("Gathering ended: " reason)
    LiveStop("Gathering done: " field, "Reason: " reason, LiveFields(c, farmMs, bag, packMax, limitMs))
    Hook("Gathering done: " field, "Reason: " reason, "farm"
        , [["Duration", Dur(farmMs)], ["Bag", bag "%"], ["Pattern", ai ? "AI Gather (" ai.chased " tokens targeted)" : c["Pattern"] " " c["Size"] " x" reps]
        , ["Return", c["Return"] = "Walk" ? "on foot" : "reset"], ["Cycle", Stats["cycles"] + 1], ["Total gathering", Dur(Stats["gather"])]], true, 2)
    if (rot = "Left")
        Send "{" RotRight " " n "}"
    else if (rot = "Right")
        Send "{" RotLeft " " n "}"
    if YouDied {
        ; mort : on reapparait deja a la ruche, pas de chemin retour
        YouDied := 0
        ResetChar()
    } else if (c["Return"] = "Walk") {
        ; on repart toujours du meme point : le saturator au centre du champ
        if (c["Sprinkler"] && SprinklerType = "Supreme" && c["SprLoc"] = "Center")
            try bm_fieldDriftCompensation()
        SetStatus("Return", "hive (on foot)")
        CallPath("wf-" FieldKey(field))
        FindHive()
    } else
        ResetChar()
    ConvertHoney()
    Stats["cycles"]++
}

DoCollect() {
    for c in COLLECT_LIST {
        CheckStop()
        wanted := S["C_" c[1]] || (c[1] = "antpass" && QuestAnt)
        if !wanted || (Now() - GetTime("collect_" c[1]) < c[3])
            continue
        CollectItem(c[1], c[2])
    }
}

CollectItem(key, name) {
    Loop 2 {
        ResetChar()
        SetStatus("Collect", name)
        CallPath("gtc-" key)
        Sleep 500
        if PressE() {
            Sleep 1500
            SetTime("collect_" key)
            Stats["collects"]++
            Log(name " collected")
            for c in COLLECT_LIST
                if (c[1] = key)
                    Hook(name " collected", "", "collect", [["Next time", "in " FmtSecs(c[3])], ["Collects (session)", Stats["collects"]]], true, 2)
            return true
        }
        Log(name ": E prompt not found" (A_Index = 1 ? ", retrying" : ""))
    }
    ; on reessaie plus tard sans bloquer la macro
    SetTime("collect_" key, Now() - 1800)
    Hook(name ": collect failed", "The E button did not show up (bad alignment or item on cooldown). Retrying in 30 min.", "warn", "", true, 2)
    return false
}

; boosters de champ : ceux coches dans Collect > Buffs + ceux demandes par une quete (Bucko / Riley)
DoBoosters() {
    todo := Map()
    for loc in ["blue", "red", "mountain"]
        if S["BO_" loc] || QuestBoosts.Has(loc)
            todo[loc] := 1
    for loc in todo {
        if (Now() - GetTime("booster_" loc) < 2700)
            continue
        ResetChar()
        SetStatus("Booster", loc)
        CallPath("gtb-" loc)
        if PressE() {
            Sleep 1000
            SetTime("booster_" loc)
            Log("Booster " loc " used")
            Hook("Booster used", "Booster " loc (QuestBoosts.Has(loc) ? " (requested by a quest)." : "."), "collect", "", false, 2)
        } else
            SetTime("booster_" loc, Now() - 2400)
    }
}

; ---------- bug run : on tourne dans le champ, les abeilles tuent les mobs ----------
DoKills() {
    global TCFBKey, AFCFBKey, TCLRKey, AFCLRKey
    todo := Map()
    for m in MOB_LIST
        if S["K_" m[1]] || QuestKills.Has(m[1])
            for f in m[3]
                if (Now() - GetTime("kill_" m[1] "_" f) >= m[4])
                    todo[f] := Max(todo.Has(f) ? todo[f] : 0, m[5])
    for f, secs in todo {
        CheckStop()
        if VBReady()
            return
        ResetChar()
        GoField(f)
        SetStatus("Bug run", f)
        TCFBKey := FwdKey, AFCFBKey := BackKey, TCLRKey := LeftKey, AFCLRKey := RightKey
        t := A_TickCount
        while (A_TickCount - t < secs * 1000) {
            CheckStop()
            Jump()
            RunPattern("Squares", 1, 0.5)
        }
        ReleaseAll()
        for m in MOB_LIST
            if S["K_" m[1]] || QuestKills.Has(m[1])
                for mf in m[3]
                    if (mf = f)
                        SetTime("kill_" m[1] "_" f)
        Stats["bugs"]++
        Log("Bug run done: " f)
        mobs := []
        for m in MOB_LIST
            if (S["K_" m[1]] || QuestKills.Has(m[1]))
                for mf in m[3]
                    if (mf = f)
                        mobs.Push(m[2] (QuestKills.Has(m[1]) ? " (quest)" : ""))
        Hook("Bug run done: " f, "", "bug", [["Mobs", JoinList(mobs)], ["Duration", secs " s"], ["Bug runs (session)", Stats["bugs"]]], false, 2)
    }
}

; balaye une zone pour ramasser les tokens
bm_loot(length, reps, direction) {
    key := (direction = "left") ? LeftKey : RightKey
    Loop reps {
        CheckStop()
        bm_Walk(length, FwdKey)
        bm_Walk(1.5, key)
        bm_Walk(length, BackKey)
        bm_Walk(1.5, key)
    }
}

; champs du message "farm en direct"
LiveFields(c, el, bag, packMax, limitMs) {
    bar := ""
    Loop 10
        bar .= (A_Index <= Round(bag / 10)) ? Chr(0x1F7E8) : Chr(0x2B1B)
    return [["Field", c["Field"]], ["Pattern", Num(c["AI"]) ? "AI Gather" : c["Pattern"] " " c["Size"] " x" c["Width"]], ["Time", Dur(el) " / " Dur(limitMs)]
        , ["Bag", bar "  " bag "% (max " packMax "%)", false], ["Cycle", Stats["cycles"] + 1], ["Tokens targeted", Stats["tokens"]], ["Deaths", Stats["deaths"]]
        , ["Total gathering", Dur(Stats["gather"] + el)]]
}
