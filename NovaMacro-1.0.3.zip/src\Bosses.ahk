﻿; =====================================================================
;  Boss et Vicious Bee
; =====================================================================

DoBosses() {
    for b in BOSS_LIST {
        CheckStop()
        if VBReady()
            return
        if !S["B_" b[1]] || (Now() - GetTime("boss_" b[1]) < b[3])
            continue
        t0 := A_TickCount
        result := %"Boss_" b[1]%()
        if (result = "dead") {
            SetTime("boss_" b[1])
            Stats["bosses"]++
            Hook(b[2] " defeated!", "", "boss", [["Fight time", Dur(A_TickCount - t0)], ["Bosses killed (session)", Stats["bosses"]], ["Next check", "in " FmtSecs(b[3])]], true, 1)
        } else if (result = "missing") {
            SetTime("boss_" b[1], Now() - b[3] + 7200)   ; pas la : on revient dans 2h
            Log(b[2] " not there, retrying in 2h")
            Hook(b[2] " not there", "Not found there, retrying in 2 h.", "warn", [["Search", Dur(A_TickCount - t0)]], false, 2)
        } else {
            SetTime("boss_" b[1], Now() - b[3] + 1800)   ; echec : on revient dans 30 min
            Log(b[2] " not killed, retrying in 30 min")
            Hook(b[2] ": fight failed", "Retrying in 30 min.", "warn", [["Duration", Dur(A_TickCount - t0)]], true, 2)
        }
    }
}

; attend apres le reset que les abeilles reviennent (moins d'abeilles = plus d'attente)
WaitBees() => Sleep(Min(20000, Max(0, 50 - HiveBees) * 1000))

; barre de vie d'un boss a l'ecran ? (vert/rouge, repris)
WaitHealthBar(tries := 20, delay := 250, rightHalf := 0) {
    Loop tries {
        CheckStop()
        if bm_HealthDetection(rightHalf).Length
            return true
        Sleep delay
    }
    return false
}

; fenetre "garder / remplacer l'amulette"
AmuletPrompt() {
    if !UpdateWindow()
        return false
    if !FindBitmap("keep", windowWidth // 2 - 250, 0, 500, windowHeight, 2, &pos)
        return false
    x := windowX + windowWidth // 2 - 250 + pos[1], y := windowY + pos[2]
    if (S["Amulet"] = "Replace") {
        MouseMove x + 190, y + 10, 5
        Click
        Loop 25 {
            if FindBitmap("yes", windowWidth // 2 - 250, 0, 500, windowHeight, 2, &p) {
                MouseMove windowX + windowWidth // 2 - 250 + p[1], windowY + p[2], 5
                Click
                break
            }
            Sleep 100
        }
        Log("Amulet replaced")
    } else {
        Loop 10 {
            if !FindBitmap("keep", windowWidth // 2 - 250, 0, 500, windowHeight, 2, &p)
                break
            MouseMove windowX + windowWidth // 2 - 250 + p[1] + 10, windowY + p[2] + 10, 5
            Sleep 200
            Click
            SafeMouse()
        }
        Log("Old amulet kept")
    }
    SafeMouse()
    return true
}

; ---------------- King Beetle ----------------
Boss_King() {
    Loop 2 {
        ResetChar()
        WaitBees()
        SetStatus("Boss", "King Beetle (travel)")
        GoField("Blue Flower")
        MoveMs(5000, RightKey, FwdKey)
        MoveMs(4000, FwdKey)
        Send "{" RotRight " 2}"
        Sleep 1000
        bm_Walk(5, RightKey)
        Jump()
        bm_Walk(3, RightKey)
        bm_Walk(5, RightKey, FwdKey)
        Send "{" RotLeft " 2}"
        lair := false
        Loop 5 {
            if ImgFound("kingfloor.png", 10, "low") {
                lair := true
                break
            }
            Sleep 200
        }
        if !lair
            continue
        SetStatus("Boss", "King Beetle (search)")
        if !WaitHealthBar(20, 250, 1) {
            if (A_Index = 2)
                return "missing"
            continue
        }
        SetStatus("Boss", "King Beetle (attack)")
        Sleep 2000
        dead := KingDodge()
        if dead {
            if !AmuletPrompt() {
                SetStatus("Butin", "King Beetle")
                bm_loot(13.5, 7, "right")
            }
            return "dead"
        }
    }
    return "failed"
}

KingDead() => ImgFound("king.png", 25, "lowright")

; esquive du King Beetle
KingDodge() {
    if KingDead()
        return (MoveMs(1000, BackKey, RightKey), MoveMs(2500, BackKey), MoveMs(500, RightKey), true)
    MoveMs(2000, BackKey)
    Sleep 1000
    if KingDead()
        return (MoveMs(1000, BackKey, RightKey), MoveMs(1000, BackKey), MoveMs(500, RightKey), true)
    MoveMs(2000, RightKey)
    Sleep 100
    if KingDead()
        return (MoveMs(1500, BackKey), MoveMs(1000, LeftKey), true)
    MoveMs(2000, BackKey)
    Sleep 1000
    if KingDead()
        return (MoveMs(1250, FwdKey), MoveMs(1000, LeftKey), true)
    MoveMs(2000, RightKey)
    Sleep 1000
    if KingDead()
        return (MoveMs(1250, FwdKey), MoveMs(2000, LeftKey), true)
    Loop 2 {
        MoveMs(2000, BackKey, RightKey)
        if KingDead()
            return (MoveMs(2500, FwdKey, LeftKey), MoveMs(2500, LeftKey), true)
    }
    Sleep 500
    Send "{" RotLeft "}"
    Loop 300 {   ; 5 minutes max
        CheckStop()
        if KingDead() {
            Send "{" RotRight "}"
            MoveMs(3500, FwdKey, LeftKey)
            MoveMs(2500, LeftKey)
            return true
        }
        Sleep 1000
    }
    Send "{" RotRight "}"
    return false
}

; ---------------- Tunnel Bear ----------------
Boss_Tunnel() {
    Loop 2 {
        ResetChar()
        WaitBees()
        SetStatus("Boss", "Tunnel Bear (travel)")
        bm_gotoramp()
        bm_gotoramp()   ; deuxieme passage : on se cale contre la rampe
        if (MoveMethod = "Walk") {
            bm_Walk(67.5, BackKey, LeftKey)
            Send "{" RotRight " 4}"
            bm_Walk(23.5, FwdKey)
            bm_Walk(31.5, FwdKey, RightKey)
            bm_Walk(10, RightKey)
            Send "{" RotRight " 2}"
            bm_Walk(28, FwdKey)
            bm_Walk(13, LeftKey)
            bm_Walk(25, RightKey)
            Send "{" SC_Space " down}{" FwdKey " down}"
            Walk(12)
            Send "{" SC_Space " up}{" FwdKey " up}{" RotLeft " 2}"
            bm_Walk(35, FwdKey)
            bm_Walk(25, RightKey)
            bm_Walk(12, FwdKey)
            bm_Walk(3.5, RightKey)
            Send "{" RotRight " 4}"
            bm_Walk(37, FwdKey)
        } else {
            bm_gotocannon()
            Send "{" SC_E " down}"
            Sleep 100
            Send "{" SC_E " up}"
            HyperSleep(1000)
            Send "{" LeftKey " down}"
            HyperSleep(100)
            Send "{" SC_Space " 2}"
            HyperSleep(900)
            Send "{" LeftKey " up}"
            HyperSleep(6000)
        }
        bm_Walk(10, FwdKey, LeftKey)
        bm_Walk(5, BackKey)
        bm_Walk(15, RightKey)
        bm_Walk(10, BackKey)
        Sleep 3000
        Send "{" RotRight " 4}{" RotUp " 3}"
        ; on verifie qu'on est bien dans le tunnel
        UpdateWindow()
        pBM := Gdip_BitmapFromScreen(windowX "|" windowY "|" windowWidth "|" windowHeight // 2)
        inTunnel := false
        for , bm in bitmaps["tunnelbearconfirm"]
            if (Gdip_ImageSearch(pBM, bm, , , , , , 15) = 1) {
                inTunnel := true
                break
            }
        Gdip_DisposeImage(pBM)
        if !inTunnel
            continue
        Send "{" RotLeft " 2}{" RotDown " 3}"
        Sleep 2000
        SetStatus("Boss", "Tunnel Bear (search)")
        MoveMs(6000, BackKey)
        MoveMs(550, LeftKey)
        if !WaitHealthBar(20, 250)
            return "missing"
        Send "{" RotUp " 3}"
        SetStatus("Boss", "Tunnel Bear (attack)")
        Loop 120 {
            CheckStop()
            Loop 15 {
                if ImgFound("tunnelbear.png", 5, "high")
                    MoveMs(200, BackKey)
                else
                    break
            }
            if ImgFound("tunnelbeardead.png", 25, "lowright") {
                Send "{" RotDown " 3}"
                SetStatus("Butin", "Tunnel Bear")
                MoveMs(12000, FwdKey)
                MoveMs(18000, BackKey)
                return "dead"
            }
            Sleep 1000
        }
    }
    return "failed"
}

; ---------------- Stump Snail ----------------
Boss_Snail() {
    ResetChar()
    WaitBees()
    SetStatus("Boss", "Stump Snail (travel)")
    GoField("Stump")
    if !WaitHealthBar(20, 150)
        return "missing"
    bm_Walk(1, FwdKey)
    SetStatus("Boss", "Stump Snail (attack)")
    Send "{" SC_1 "}"
    Send "{" RotUp " 2}"
    limit := Num(S["SnailMins"]) * 60000, t := A_TickCount, lastBar := A_TickCount
    moves := [[2.5, RightKey], [2.5, FwdKey], [2.5, LeftKey], [5, BackKey], [2.5, LeftKey], [2.5, FwdKey], [5, RightKey]
        , [2.5, BackKey], [2.5, LeftKey], [5, FwdKey], [2.5, LeftKey], [2.5, BackKey], [2.5, RightKey]]
    try {
        Loop {
            CheckStop()
            Click "Down"
            for mv in moves {
                bm_Walk(mv[1], mv[2])
                if AmuletPrompt() {
                    Click "Up"
                    Send "{" RotDown " 2}"
                    return "dead"
                }
            }
            if bm_HealthDetection().Length
                lastBar := A_TickCount
            else if (A_TickCount - lastBar > 60000) {   ; plus de barre de vie depuis 1 min
                Click "Up"
                return AmuletPrompt() ? "dead" : "failed"
            }
            if (limit && A_TickCount - t > limit) {
                Click "Up"
                SetStatus("Boss", "Stump Snail: max time reached")
                return "failed"
            }
            if (Mod(A_Index, 10) = 0 && CheckDisconnect())
                return "failed"
        }
    } finally
        Click "Up"
}

; ---------------- Coco Crab ----------------
Boss_Crab() {
    Loop 2 {
        ResetChar()
        WaitBees()
        SetStatus("Boss", "Coco Crab (travel)")
        GoField("Coconut")
        Send "{" SC_1 "}"
        MoveMs(1400, RightKey)
        MoveMs(1000, BackKey)
        if !WaitHealthBar(20, 250)
            return "missing"
        SetStatus("Boss", "Coco Crab (attack)")
        t := A_TickCount
        while (A_TickCount - t < 900000) {   ; 15 minutes max
            CheckStop()
            if CrabCycle() {
                SetStatus("Butin", "Coco Crab")
                Loop 3 {
                    bm_loot(9, 4, "right")
                    bm_loot(9, 4, "left")
                }
                return "dead"
            }
        }
    }
    return "failed"
}

CrabDead() => ImgFound("crab.png", 70, "lowright")

; un cycle d'esquive de 24 s, renvoie true si le crabe est mort
CrabCycle() {
    start := A_TickCount, md := 310, moves := 14
    bm_Walk(4, FwdKey)
    if WaitUntil(start + 500)
        return true
    Loop 2 {
        i := A_Index
        bm_Walk(1, FwdKey)
        Loop moves {
            bm_Walk(2, LeftKey)
            if WaitUntil(start + (i - 1) * 2 * md * moves + 500 + A_Index * md)
                return true
        }
        bm_Walk(1, BackKey)
        Loop moves {
            bm_Walk(2, RightKey)
            if WaitUntil(start + (i - 1) * 2 * md * moves + md * moves + 500 + A_Index * md)
                return true
        }
    }
    if WaitUntil(start + 19000)
        return true
    bm_Walk(6.5, BackKey)
    return WaitUntil(start + 24000)

    WaitUntil(target) {
        Loop {
            Click
            if CrabDead()
                return true
            if (A_TickCount >= target)
                return false
            Sleep 50
        }
    }
}

; ---------------- Commando Chick ----------------
Boss_Commando() {
    Loop 2 {
        ResetChar()
        SetStatus("Boss", "Commando Chick (travel)")
        bm_gotoramp()
        if (MoveMethod = "Walk") {
            bm_Walk(44.75, BackKey, LeftKey)
            bm_Walk(42.5, LeftKey)
            bm_Walk(8.5, BackKey)
            bm_Walk(22.5, LeftKey)
            Send "{" RotLeft " 2}"
            bm_Walk(27, FwdKey)
            bm_Walk(12, LeftKey, FwdKey)
            bm_Walk(11, FwdKey)
        } else {
            bm_gotocannon()
            Send "{" SC_E " down}"
            HyperSleep(100)
            Send "{" SC_E " up}"
            HyperSleep(400)
            Send "{" LeftKey " down}{" FwdKey " down}"
            HyperSleep(1050)
            Send "{" SC_Space " 2}"
            HyperSleep(5850)
            Send "{" FwdKey " up}"
            HyperSleep(750)
            Send "{" SC_Space "}{" RotLeft " 2}"
            HyperSleep(1500)
            Send "{" LeftKey " up}"
            bm_Walk(4, BackKey)
            bm_Walk(4.5, LeftKey)
        }
        fast := (Num(S["MoveSpeed"], 28) >= 34)
        bm_Walk(10, LeftKey), HyperSleep(50)
        bm_Walk(6, RightKey), HyperSleep(50)
        bm_Walk(2, LeftKey), HyperSleep(50)
        bm_Walk(7, FwdKey), HyperSleep(750)
        Jump(), bm_Walk(fast ? 4.5 : 5.5, FwdKey), HyperSleep(750)
        Loop 3
            Jump(), bm_Walk(fast ? 5 : 6, FwdKey), HyperSleep(750)
        bm_Walk(1, FwdKey)
        Jump(), bm_Walk(6, FwdKey), HyperSleep(750)
        CommandoStep()

        ; si le poussin s'est enfui on recommence le petit aller-retour
        fled := false
        while ImgFound("ChickFled.png", 50, "lowright") {
            if (A_Index = 5) {
                fled := true
                break
            }
            CommandoStep()
        }
        if fled
            continue
        SetStatus("Boss", "Commando Chick (search)")
        Send "{" ZoomIn " 4}"
        if !WaitHealthBar(20, 250) {
            Send "{" ZoomOut " 4}"
            return "missing"
        }
        SetStatus("Boss", "Commando Chick (attack)")
        limit := Num(S["ChickMins"], 10) * 60000, t := A_TickCount, strikes := 0
        Loop {
            CheckStop()
            Click
            Sleep 100
            if ImgFound("ChickDead.png", 50, "lowright")
                return (Send("{" ZoomOut " 4}"), "dead")
            if (limit && A_TickCount - t > limit)
                return (Send("{" ZoomOut " 4}"), "failed")
            if (Mod(A_Index, 5) = 0) && !bm_HealthDetection().Length {
                if (++strikes > 10)
                    return (Send("{" ZoomOut " 4}"), "dead")
            } else if (Mod(A_Index, 5) = 0)
                strikes := 0
        }
    }
    return "failed"

    CommandoStep() {
        bm_Walk(5, FwdKey), HyperSleep(50)
        bm_Walk(9, BackKey)
        Sleep 4000
        Jump(), bm_Walk(0.5, BackKey)
        HyperSleep(1500)
    }
}

; =====================================================================
;  Vicious Bee (la nuit)
; =====================================================================
DoViciousBee() {
    global NightDetected
    if !VBReady()
        return
    if !ConfirmNight() {
        NightDetected := 0
        return
    }
    start := Now(), checked := 0
    SetStatus("Vicious Bee", "starting the search")
    static data := Map(
        "Pepper", {bees: 35, reps: 1, lr: 20, fb: 7, r: 10, f: 7},
        "Mountain Top", {bees: 25, reps: 2, lr: 17, fb: 5.5, r: 8.5, f: 10.5},
        "Rose", {bees: 15, reps: 2, lr: 13, fb: 6, r: 6.5, f: 12},
        "Cactus", {bees: 15, reps: 1, lr: 26, fb: 5.5, r: 13, f: 3.7},
        "Spider", {bees: 5, reps: 2, lr: 21, fb: 5.7, r: 10.5, f: 9.5},
        "Clover", {bees: 0, reps: 2, lr: 22, fb: 5.7, r: 11, f: 10})
    for field in VB_FIELDS {
        d := data[field]
        if !S["VB_" StrReplace(field, " ")] || (d.bees >= HiveBees)
            continue
        if (Now() - start > 300)
            break
        checked++
        ResetChar()
        SetStatus("Vicious Bee", "searching " field)
        GoField(field)
        OpenChat()
        res := VBWalk([[d.r, RightKey], [d.f, FwdKey]])
        Loop d.reps {
            if res
                break
            res := VBWalk([[d.lr, LeftKey], [d.fb, BackKey], [d.lr, RightKey], [d.fb, BackKey]])
        }
        if !res
            res := VBWalk([[d.lr, LeftKey]])
        if (res = "dead") {
            Log("Vicious Bee already killed by another player")
            Hook("Vicious Bee already killed", "Another player got it first.", "vb", "", false, 2)
            break
        }
        if (res = "found") {
            Hook("Vicious Bee found!", "Field: " field ". Attacking.", "vb", [["Fields searched", checked], ["Bees", HiveBees]], true, 1)
            if KillVB(field) {
                SetTime("vb_kill")
                Stats["vb"]++
                Hook("Vicious Bee killed!", "Field: " field, "vb", [["Total time", Now() - start " s"], ["Vicious Bees (session)", Stats["vb"]]], true, 1)
            }
            break
        }
    }
    try Click "Up"
    NightDetected := 0
    SetStatus("Vicious Bee", "done (" checked " field(s) visited)")
    Hook("Vicious Bee search done", "", "vb", [["Fields searched", checked], ["Duration", Now() - start " s"]], false, 3)
}

ConfirmNight() {
    ResetChar()
    SetStatus("Night", "verification")
    UpdateWindow()
    Send "{" RotUp " 10}"
    Loop 7
        Send("{" ZoomOut "}"), Sleep(25)
    pBM := Gdip_BitmapFromScreen(windowX + 300 "|" windowY + windowHeight // 2 + 50 "|" windowWidth - 600 "|" windowHeight // 2 - 50)
    night := false
    for , bm in bitmaps["confirm_night"]
        if (Gdip_ImageSearch(pBM, bm) = 1)
            night := true
    Gdip_DisposeImage(pBM)
    Send "{" RotDown " 4}"
    Log(night ? "Night confirmed" : "It is not night")
    return night
}

OpenChat() {
    SetKeyDelay 50
    Send "{" SC_Slash "}`n"
    SetKeyDelay KeyDelay
}

; marche par petits bouts en surveillant le chat ; renvoie "found", "dead" ou ""
VBWalk(steps, attacking := false) {
    for st in steps {
        left := st[1]
        while (left > 0) {
            CheckStop()
            part := Min(2, left)
            bm_Walk(part, st[2])
            left -= part
            r := VBCheck()
            if (r = "dead" || (r = "found" && !attacking))
                return r
        }
    }
    return ""
}

VBCheck() {
    static lastChat := 0
    if !UpdateWindow()
        return ""
    if (A_TickCount - lastChat > 40000) {   ; le texte du chat disparait apres 40 s
        OpenChat()
        lastChat := A_TickCount
    }
    w := (windowWidth >= 1195) ? 475 : windowWidth / 2.5
    h := (windowHeight >= 1156) ? 334 : windowHeight / 3.464
    pBM := Gdip_BitmapFromScreen(Round(windowX + windowWidth - 8 - w) "|" windowY + offsetY + 40 "|" Round(w) "|" Round(h))
    res := ""
    for , bm in bitmaps["viciousbee"]["dead"]
        if Gdip_ImageSearch(pBM, bm, , , , , , 5) {
            res := "dead"
            break
        }
    if (res = "")
        for , bm in bitmaps["viciousbee"]["found"]
            if Gdip_ImageSearch(pBM, bm, , , , , , 5) {
                res := "found"
                break
            }
    Gdip_DisposeImage(pBM)
    return res
}

KillVB(field) {
    SetStatus("Vicious Bee", "attacking at " field)
    t := A_TickCount
    Click "Down"
    while (A_TickCount - t < 300000) {   ; 5 minutes max
        for st in [[4, FwdKey], [4, RightKey], [4, BackKey], [4, LeftKey]] {
            if (VBWalk([st], true) = "dead") {
                Click "Up"
                return true
            }
            Sleep 1000
        }
    }
    Click "Up"
    Log("Vicious Bee: max time reached")
    return false
}
