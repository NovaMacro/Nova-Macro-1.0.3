﻿if (MoveMethod = "walk")
{
    bm_gotoramp()
    bm_Walk(67.5, BackKey, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(31, FwdKey)
    bm_Walk(7.8, LeftKey)
    bm_Walk(10, BackKey)
    bm_Walk(5, RightKey)
    bm_Walk(1.5, FwdKey)
    bm_Walk(60, LeftKey)
    bm_Walk(3.75, RightKey)
    bm_Walk(38, FwdKey)
    send "{" RotLeft " 4}"
    bm_Walk(14, RightKey)
    bm_Walk(15, FwdKey, LeftKey)
    bm_Walk(1, BackKey)
    HyperSleep(200)
    bm_Walk(25, RightKey)
    Hypersleep(200)
    send "{" RotRight " 2}"
    Hypersleep(200)
    ;inside badge shop
    bm_Walk(15, FwdKey)
    bm_Walk(1, FwdKey, RightKey)
    ;align with corner
    bm_Walk(7, FwdKey)
    bm_Walk(3, BackKey)
    bm_Walk(26, LeftKey)
    bm_Walk(1, FwdKey, LeftKey)
    HyperSleep(300)
}
else
{
    bm_gotoramp()
    bm_gotocannon()
    send "{e down}"
    HyperSleep(100)
    send "{e up}{" RightKey " down}{" BackKey " down}"
    HyperSleep(925)
    send "{space 2}"
    HyperSleep(2850)
    send "{" BackKey " up}"
    HyperSleep(1450)
    send "{space}{" RightKey " up}"
    HyperSleep(600)
    ;corner align
    bm_Walk(10, FwdKey, LeftKey)
    bm_Walk(10, LeftKey, FwdKey)
    bm_Walk(1, BackKey)
    HyperSleep(200)
    bm_Walk(25, RightKey)
    Hypersleep(200)
    send "{" RotRight " 2}"
    Hypersleep(200)
    ;inside badge shop
    bm_Walk(15, FwdKey)
    bm_Walk(1, FwdKey, RightKey)
    ;align with corner
    bm_Walk(7, FwdKey)
    bm_Walk(3, BackKey)
    bm_Walk(26, LeftKey)
    bm_Walk(1, FwdKey, LeftKey)
    HyperSleep(300)
}