﻿; =====================================================================
;  Farm IA : pas de pattern. Pendant le farm, l'IA regarde l'ecran,
;  reconnait les tokens (signatures de couleur tirees des images de
;  assets\tokens), marche vers le plus prioritaire en se recalant a
;  chaque image, puis revient au sprinkler. Avec le drift compensation,
;  elle reste immobile sur le saturator entre deux tokens.
; =====================================================================

TokenDir() => A_ScriptDir "\assets\tokens"

; images d'un token : Haste.png, Haste_2.png, Haste_3.png...
TokenImages(key) {
    files := []
    Loop Files TokenDir() "\" key "*.png"
        if RegExMatch(A_LoopFileName, "i)^" key "(_\d+)?\.png$")
            files.Push(A_LoopFileFullPath)
    return files
}

; ---------- signatures de couleur ----------
; chaque pixel tombe dans une des 15 cases : 12 teintes vives (30 degres chacune), puis sombre, gris, clair.
; une signature = la part de chaque case dans le disque du token. Robuste a la rotation, a la taille et
; (en partie) a la lumiere, contrairement a une comparaison pixel par pixel.
ColorBin(r, g, b) {
    mx := Max(r, g, b), mn := Min(r, g, b), d := mx - mn
    if (mx < 46)
        return 13
    if (d < mx * 0.22)
        return (mx > 178) ? 15 : 14
    h := (mx = r) ? Mod((g - b) / d + 6, 6) : (mx = g) ? (b - r) / d + 2 : (r - g) / d + 4
    return Min(12, Floor(h * 2) + 1)
}

; histogrammes des couleurs autour d'un point (bitmap verrouille : scan0/stride) :
;  h   = 30 cases : centre du token (0 a 0.55 rayon) puis son anneau (0.55 a 1 rayon)
;  all = tout le disque, sur = ce qui entoure le token (1.15 a 1.6 rayon), + couleur moyenne de chaque case
DiscHist(scan0, stride, bw, bh, cx, cy, rad, around := true) {
    h := [], all := [], sur := [], sr := [], sg := [], sb := []
    h.Length := 30, all.Length := sur.Length := sr.Length := sg.Length := sb.Length := 15
    Loop 30
        h[A_Index] := 0
    Loop 15
        all[A_Index] := sur[A_Index] := sr[A_Index] := sg[A_Index] := sb[A_Index] := 0
    ext := around ? rad * 1.6 : rad, nIn := 0, nRing := 0, nSur := 0
    rIn2 := (rad * 0.55) ** 2, r2 := rad * rad, rs2 := (rad * 1.15) ** 2, re2 := ext * ext
    x0 := Max(0, Floor(cx - ext)), x1 := Min(bw - 1, Ceil(cx + ext)), y0 := Max(0, Floor(cy - ext)), y1 := Min(bh - 1, Ceil(cy + ext))
    y := y0
    while (y <= y1) {
        dy2 := (y - cy) ** 2, x := x0, row := scan0 + y * stride
        while (x <= x1) {
            d2 := (x - cx) ** 2 + dy2
            if (d2 <= re2) && (d2 <= r2 || d2 >= rs2) {
                c := NumGet(row, x * 4, "UInt"), r := (c >> 16) & 255, g := (c >> 8) & 255, b := c & 255
                if !(r > 240 && g < 20 && b > 240) && ((c >> 24) & 255) > 127 {   ; magenta ou transparent = zone ignoree
                    k := ColorBin(r, g, b)
                    if (d2 > r2)
                        sur[k]++, nSur++
                    else {
                        all[k]++, sr[k] += r, sg[k] += g, sb[k] += b
                        if (d2 <= rIn2)
                            h[k]++, nIn++
                        else
                            h[k + 15]++, nRing++
                    }
                }
            }
            x++
        }
        y++
    }
    n := nIn + nRing
    Loop 15 {
        k := A_Index
        if all[k]
            sr[k] := sr[k] // all[k], sg[k] := sg[k] // all[k], sb[k] := sb[k] // all[k], all[k] /= n
        if nIn
            h[k] /= nIn
        if nRing
            h[k + 15] /= nRing
        if nSur
            sur[k] /= nSur
    }
    return {h: h, all: all, sur: sur, r: sr, g: sg, b: sb, n: n, nSur: nSur}
}

; ressemblance de deux histogrammes (0 a 1)
HistMatch(a, b) {
    s := 0
    Loop a.Length
        s += Min(a[A_Index], b[A_Index])
    return s * 15 / a.Length
}

; part des couleurs du token presentes dans le disque mais pas autour (0 = partout pareil, 1 = bien detache)
TokenContrast(hs, sg) {
    if (hs.nSur < 4)
        return 1
    num := 0, den := 0
    Loop 15 {
        k := A_Index, w := Max(sg.h[k], sg.h[k + 15])
        if (w < 0.08)
            continue
        num += w * Max(0, hs.all[k] - hs.sur[k]), den += w * hs.all[k]
    }
    return den ? num / den : 0
}

; signature d'une image de token (icone ou capture F6), ramenee a 32x32
TokenSignature(file) {
    if !(src := Gdip_CreateBitmapFromFile(file))
        return 0
    pBM := Gdip_ResizeBitmap(src, 32, 32, 3)
    Gdip_DisposeImage(src)
    Gdip_LockBits(pBM, 0, 0, 32, 32, &stride, &scan0, &bd, 1)
    hs := DiscHist(scan0, stride, 32, 32, 15.5, 15.5, 13.5, false)
    Gdip_UnlockBits(pBM, &bd)
    Gdip_DisposeImage(pBM)
    if !hs.n
        return 0
    ; couleurs-cles : les teintes vives qui couvrent une bonne partie du token (sinon sa couleur claire/grise)
    order := []
    Loop 12
        if (hs.all[A_Index] >= 0.12)
            order.Push(A_Index)
    if !order.Length
        for k in [15, 14]
            if (hs.all[k] >= 0.2) {
                order.Push(k)
                break
            }
    while (order.Length > 2) {   ; on garde les 2 plus presentes
        lo := 1
        for i, k in order
            if (hs.all[k] < hs.all[order[lo]])
                lo := i
        order.RemoveAt(lo)
    }
    keys := []
    for k in order
        keys.Push((hs.r[k] << 16) | (hs.g[k] << 8) | hs.b[k])
    return {h: hs.h, keys: keys, all: hs.all}
}

ColorDist(a, b) => Sqrt((((a >> 16) & 255) - ((b >> 16) & 255)) ** 2 + (((a >> 8) & 255) - ((b >> 8) & 255)) ** 2 + ((a & 255) - (b & 255)) ** 2)

AIInit(c) {
    tokens := [], keys := []
    for tk in TOKEN_LIST {
        prio := Num(S["AI_P_" tk[1]], tk[3])
        if (prio <= 0) || !HiveHas(S["AI_Hive"], tk[1])   ; token d'une autre couleur de ruche : ignore
            continue
        sigs := []
        for f in TokenImages(tk[1])
            if (sg := TokenSignature(f))
                sigs.Push(sg)
        if !sigs.Length
            continue
        t := {key: tk[1], name: tk[2], prio: prio, sigs: sigs}
        tokens.Push(t)
        ; regroupe les couleurs-cles proches : une seule recherche par couleur pour plusieurs tokens
        for sg in sigs
            for col in sg.keys {
                hit := 0
                for kc in keys
                    if (ColorDist(kc.c, col) < 40) {
                        hit := kc
                        break
                    }
                if !hit {
                    nd := Gdip_CreateBitmap(1, 1)
                    Gdip_SetPixel(nd, 0, 0, 0xFF000000 | col)
                    keys.Push(hit := {c: col, needle: nd, toks: Map()})
                }
                hit.toks[t] := 1
            }
    }
    if !tokens.Length
        Log("AI Gather: no token images (assets\tokens): the AI only walks around the sprinkler")
    static freq := (DllCall("QueryPerformanceFrequency", "Int64*", &f := 0), f)
    stay := c.Has("Drift") && Num(c["Drift"]) && Num(S["AI_Stay"])
    return {c: c, tokens: tokens, keys: keys, x: 0.0, y: 0.0, kx: 0, ky: 0, v: base_movespeed, lastV: 0, dets: []
        , qpc: 0, freq: freq, lastHome: stay ? 0 : A_TickCount, lastSeen: A_TickCount, lastCam: A_TickCount, field: [], fieldAt: 0, ghosts: [], chased: 0, leg: 0, stay: stay, moved: true, idle: 0}
}

AIFinish(ai) {
    AISetKeys(ai, 0, 0)
    AICamRestore()   ; camera d'origine avant le retour a la ruche
    AIOverlay()
    for kc in ai.keys
        Gdip_DisposeImage(kc.needle)
    ai.keys := [], ai.tokens := []
}

; ---------- vision ----------
; zone de recherche (coordonnees client) et position du personnage a l'ecran
AIView() {
    UpdateWindow()
    px := windowWidth // 2, py := Round(windowHeight * Num(S["AI_PlayerY"], 55) / 100)
    z := Max(30, Min(100, Num(S["AI_Zone"], 80))) / 100
    rw := Round(windowWidth * z), rh := Round(windowHeight * z)
    ; on evite la barre du haut du jeu (miel, buffs) et la barre d'objets du bas
    top := offsetY + Round(windowHeight * 0.14), bottom := Round(windowHeight * 0.87)
    rx := Max(0, px - rw // 2), ry := Max(top, py - rh // 2)
    rw := Min(rw, windowWidth - rx), rh := Min(rh, bottom - ry)
    return {px: px, py: py, x: rx, y: ry, w: rw, h: rh}
}

; capture d'une zone : "Screen" (BitBlt, le plus rapide) ou "Window" (PrintWindow, marche meme si la fenetre est couverte)
AIGrab(x, y, w, h) {
    if (S["AI_Capture"] = "Window") && (hwnd := GetRobloxHWND()) {
        full := Gdip_BitmapFromHWND(hwnd)
        WinGetPos(&wx, &wy, , , hwnd)
        pBM := Gdip_CloneBitmapArea(full, windowX - wx + x, windowY - wy + y, w, h)
        Gdip_DisposeImage(full)
        return pBM
    }
    return Gdip_BitmapFromScreen(Round(windowX + x) "|" Round(windowY + y) "|" Round(w) "|" Round(h))
}

; taille d'un token a l'ecran (px) et echelle de la recherche (25 % = rapide, 50 % = precis)
AITokenPx(winH := 0) => Num(S["AI_TokSize"], 42) * (winH ? winH : windowHeight) / 1080
AIScale() => (S["AI_Res"] = "100%") ? 0.5 : 0.25

; ---------- modele du champ ----------
; l'IA regarde le champ et retient les motifs de couleur qui se repetent partout (fleurs, herbe,
; decor). Un objet qui ressemble a ces motifs n'est pas un token, meme s'il en a les couleurs.
AIFieldLearn(ai, pBM, w, h, winH := 0) {
    ds := AIScale(), sw := Max(8, Round(w * ds)), sh := Max(8, Round(h * ds))
    small := Gdip_ResizeBitmap(pBM, sw, sh, 3)
    D := Max(4, AITokenPx(winH) * ds), r := D * 0.45, stp := Max(3, Round(D * 0.7))
    Gdip_LockBits(small, 0, 0, sw, sh, &stride, &scan0, &bd, 1)
    protos := []
    y := Round(r) + 1
    while (y < sh - r) {
        x := Round(r) + 1
        while (x < sw - r) {
            hs := DiscHist(scan0, stride, sw, sh, x, y, r, false)
            hit := 0
            for pr in protos
                if (HistMatch(hs.all, pr.h) >= 0.82) {
                    hit := pr
                    break
                }
            if hit
                hit.n++
            else
                protos.Push({h: hs.all, n: 1})
            x += stp
        }
        y += stp
    }
    Gdip_UnlockBits(small, &bd)
    Gdip_DisposeImage(small)
    ; seuls les motifs repetes comptent : un token est rare, il ne devient pas "du champ"
    ai.field := []
    for pr in protos
        if (pr.n >= 3)
            ai.field.Push(pr.h)
    ai.fieldAt := A_TickCount
}

; ressemble au champ ?
AIFieldLike(ai, hist) {
    for h in ai.field
        if (HistMatch(hist, h) >= 0.75)
            return true
    return false
}

; detection dans une image : renvoie [{tk, x, y, score}] (coordonnees de l'image)
;  1) couleurs-cles des tokens cherchees en basse resolution (code machine, rapide)
;  2) les pixels trouves sont regroupes en taches de la taille d'un token
;  3) chaque tache est comparee aux signatures des tokens qui ont cette couleur
AIDetect(ai, pBM, w, h, only := "", winH := 0) {
    ds := AIScale(), sw := Max(8, Round(w * ds)), sh := Max(8, Round(h * ds))
    small := Gdip_ResizeBitmap(pBM, sw, sh, 3)
    ; etape 1 sur une image encore 2 fois plus petite (4 fois moins de pixels a trier)
    tw := Max(8, sw // 2), th := Max(8, sh // 2), q := tw / sw
    tiny := Gdip_ResizeBitmap(small, tw, th, 3)
    D := Max(4, AITokenPx(winH) * ds), cell := Max(2, Round(D * 0.6 * q))
    var := Max(8, Round(Num(S["AI_Var"], 45) * 0.6)), cap := Round(Max(tw * th * 0.04, 0.785 * (D * q) ** 2 * 8))   ; jamais moins que 8 tokens : sinon un token proche, sur une petite zone, serait pris pour la couleur du champ
    cells := Map()
    for kc in ai.keys {
        if only && !kc.toks.Has(only)
            continue
        n := Gdip_ImageSearch(tiny, kc.needle, &list, , , , , var, , 1, cap + 1)
        if (n <= 0 || n > cap)   ; trop de pixels = c'est la couleur du champ, pas un token
            continue
        for pt in StrSplit(list, "`n") {
            xy := StrSplit(pt, ",")
            if (xy.Length < 2)
                continue
            k := (xy[1] // cell) * 10000 + (xy[2] // cell)
            if !cells.Has(k)
                cells[k] := {n: 0, sx: 0, sy: 0, kc: Map()}
            cl := cells[k], cl.n += 4, cl.sx += xy[1] * 4 / q, cl.sy += xy[2] * 4 / q, cl.kc[kc] := 1
        }
    }
    Gdip_DisposeImage(tiny)
    dets := []
    if cells.Count {
        ; regroupement : la case la plus remplie absorbe ses voisines (meme token)
        pool := []
        for k, cl in cells
            pool.Push(cl)
        area := 0.785 * D * D, minHits := Max(2, Round(area * 0.08)), cands := []
        while pool.Length {
            bi := 1
            for i, cl in pool
                if (cl.n > pool[bi].n)
                    bi := i
            top := pool.RemoveAt(bi), cx := top.sx / top.n, cy := top.sy / top.n
            m := {n: top.n, sx: top.sx, sy: top.sy, kc: top.kc}
            i := pool.Length
            while (i >= 1) {
                cl := pool[i]
                if (Abs(cl.sx / cl.n - cx) < D * 0.8 && Abs(cl.sy / cl.n - cy) < D * 0.8) {
                    m.n += cl.n, m.sx += cl.sx, m.sy += cl.sy
                    for kc in cl.kc
                        m.kc[kc] := 1
                    pool.RemoveAt(i)
                }
                i--
            }
            ; une tache bien plus grande qu'un token = fleurs, ballon, decor : on l'ignore
            if (m.n >= minHits && m.n <= area * 1.3 * m.kc.Count)
                cands.Push(m)
            if (cands.Length >= 60)
                break
        }
        if cands.Length {
            Gdip_LockBits(small, 0, 0, sw, sh, &stride, &scan0, &bd, 1)
            thr := Num(S["AI_Match"], 55) / 100
            for m in cands {
                cx := m.sx / m.n, cy := m.sy / m.n
                hs := DiscHist(scan0, stride, sw, sh, cx, cy, D * 0.45)
                ; un token se detache de ce qui l'entoure ; une texture de champ ou d'interface, non
                if (hs.n < 4) || AIFieldLike(ai, hs.all)   ; fleurs, herbe... du champ
                    continue
                best := 0, bs := 0, bsg := 0
                for kc in m.kc
                    for t in kc.toks {
                        if only && (t != only)
                            continue
                        for sg in t.sigs
                            if ((sc := HistMatch(hs.h, sg.h)) > bs)
                                bs := sc, best := t, bsg := sg
                    }
                ; contraste : les couleurs du token doivent etre dans le disque, pas tout autour
                ; (une texture de champ ou un decor a les memes couleurs dedans et dehors)
                ctr := bsg ? TokenContrast(hs, bsg) : 0
                if best && (bs >= thr) && (ctr >= 0.3)
                    dets.Push({tk: best, x: cx / ds, y: cy / ds, score: bs})
            }
            Gdip_UnlockBits(small, &bd)
        }
    }
    Gdip_DisposeImage(small)
    return dets
}

; ce token est-il toujours au meme endroit (a tol pixels pres) ? On regarde une zone assez grande
; autour : le detecteur a besoin de voir ce qui entoure le token pour le reconnaitre.
AIFindNear(ai, tk, x, y, tol, zone := 3) {
    vw := AIView(), rad := AITokenPx() * zone
    gx := Max(vw.x, Round(x - rad)), gy := Max(vw.y, Round(y - rad))
    gw := Min(vw.x + vw.w, Round(x + rad)) - gx, gh := Min(vw.y + vw.h, Round(y + rad)) - gy
    if (gw < 16 || gh < 16)
        return 0
    pBM := AIGrab(gx, gy, gw, gh)
    dets := AIDetect(ai, pBM, gw, gh, tk)
    Gdip_DisposeImage(pBM)
    best := 0, bd := tol
    for d in dets {
        dd := Sqrt((gx + d.x - x) ** 2 + (gy + d.y - y) ** 2)
        if (dd <= bd)
            bd := dd, best := {tk: d.tk, x: gx + d.x, y: gy + d.y, score: d.score}
    }
    return best
}

; la chose a cet endroit est-elle immobile ? deux images a 0,15 s d'intervalle : un token pose au sol
; change a peine (il tourne sur lui-meme), une abeille ou un nom de joueur qui passe change beaucoup
AIStill(x, y) {
    sz := Round(AITokenPx() * 1.2), h1 := AIPatchHist(x, y, sz)
    Sleep 150
    h2 := AIPatchHist(x, y, sz)
    return h1 && h2 && (HistMatch(h1, h2) >= 0.75)
}

AIPatchHist(x, y, sz) {
    pBM := AIGrab(Round(x - sz / 2), Round(y - sz / 2), sz, sz)
    if !pBM
        return 0
    Gdip_LockBits(pBM, 0, 0, sz, sz, &stride, &scan0, &bd, 1)
    hs := DiscHist(scan0, stride, sz, sz, sz / 2, sz / 2, sz * 0.45, false)
    Gdip_UnlockBits(pBM, &bd)
    Gdip_DisposeImage(pBM)
    return hs.n ? hs.all : 0
}

; meilleur token visible (priorite d'abord, puis le plus proche). only/near : suivi d'un seul token autour d'un point
AIScan(ai, only := "", nearX := 0, nearY := 0, rad := 0) {
    if !ai.keys.Length || !GetRobloxHWND()
        return 0
    vw := AIView(), x := vw.x, y := vw.y, w := vw.w, h := vw.h
    if rad {
        x := Max(vw.x, nearX - rad), y := Max(vw.y, nearY - rad)
        w := Min(vw.x + vw.w, nearX + rad) - x, h := Min(vw.y + vw.h, nearY + rad) - y
        if (w < 16 || h < 16)
            return 0
    }
    pBM := AIGrab(x, y, w, h)
    if !rad && (A_TickCount - ai.fieldAt > 90000)   ; le champ est (re)appris toutes les 90 s (lumiere, camera)
        AIFieldLearn(ai, pBM, w, h)
    dets := AIDetect(ai, pBM, w, h, only)
    Gdip_DisposeImage(pBM)
    best := 0, loot := Num(S["AI_Loot"]), gr := AITokenPx() * 0.8
    for d in dets {
        d.x += x, d.y += y
        ghost := false
        for gh in ai.ghosts
            if (A_TickCount - gh.t < 4000) && (Abs(gh.x - d.x) < gr) && (Abs(gh.y - d.y) < gr)
                ghost := true
        if ghost
            continue
        ; le personnage et le nom au-dessus de sa tete ne sont jamais des tokens
        if (Abs(d.x - vw.px) < AITokenPx() * 1.2) && (d.y > vw.py - AITokenPx() * 4) && (d.y < vw.py + AITokenPx() * 0.5)
            continue
        d.d := Sqrt((d.x - vw.px) ** 2 + (d.y - vw.py) ** 2)
        d.rank := (loot ? 0 : d.tk.prio * 10000) - d.d   ; mode loot : le plus proche d'abord
        if !best || (d.rank > best.rank)
            best := d
    }
    if !rad
        ai.dets := dets
    if S["AI_Overlay"]
        AIOverlay(dets, best)
    return best
}

; cadres autour des tokens reconnus (vert = celui qui est vise)
AIOverlay(dets := "", best := 0) {
    static boxes := []
    if !dets && !boxes.Length
        return
    if !boxes.Length
        Loop 8 {
            g := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 -DPIScale")
            DllCall("user32\SetWindowDisplayAffinity", "Ptr", g.Hwnd, "UInt", 0x11)   ; WDA_EXCLUDEFROMCAPTURE
            boxes.Push(g)
        }
    sz := Round(AITokenPx() * 1.2)
    for i, g in boxes {
        if (dets && i <= dets.Length) {
            d := dets[i]
            g.BackColor := (d = best) ? "22E06B" : "FF3B3B"
            g.Show(Format("NA x{} y{} w{} h{}", Round(windowX + d.x - sz / 2), Round(windowY + d.y - sz / 2), sz, sz))
            WinSetRegion(Format("0-0 {1}-0 {1}-{1} 0-{1} 0-0 3-3 3-{2} {2}-{2} {2}-3 3-3", sz, sz - 3), g)
        } else
            g.Hide()
    }
}

; ---------- camera : demi-tour pour voir les tokens de l'autre cote ----------
; seulement des demi-tours (180 degres) : les touches sont alors simplement inversees,
; donc la position estimee depuis le sprinkler reste juste.
global AICamRot := 0   ; 0 = camera d'origine, 4 = demi-tour (4 crans de 45 degres)

AICamTurn() {
    global AICamRot
    bm_cameraRotation("right", 4)
    AICamRot := Mod(AICamRot + 4, 8)
    Sleep 250   ; le temps que la camera finisse de tourner
}

; remet la camera comme au debut du farm (avant le retour a la ruche, a l'arret...)
AICamRestore() {
    global AICamRot
    if AICamRot {
        bm_cameraRotation("left", AICamRot)
        AICamRot := 0
        Sleep 250
    }
}

AICamSign() => (AICamRot = 4) ? -1 : 1

; ---------- mouvement et position (en cases, depuis le sprinkler) ----------
AISetKeys(ai, nx, ny) {
    if (nx != ai.kx) {
        if ai.kx
            Send "{" (ai.kx > 0 ? RightKey : LeftKey) " up}"
        if nx
            Send "{" (nx > 0 ? RightKey : LeftKey) " down}"
    }
    if (ny != ai.ky) {
        if ai.ky
            Send "{" (ai.ky > 0 ? FwdKey : BackKey) " up}"
        if ny
            Send "{" (ny > 0 ? FwdKey : BackKey) " down}"
    }
    ai.kx := nx, ai.ky := ny
}

; met a jour la position estimee selon les touches tenues et la vitesse reelle (haste comprise)
AITrack(ai) {
    DllCall("QueryPerformanceCounter", "Int64*", &now := 0)
    if (ai.qpc && (ai.kx || ai.ky)) {
        if (A_TickCount - ai.lastV > 400)   ; la vitesse (buffs) est relue regulierement
            ai.v := DetectMovespeed(&s, &e), ai.lastV := A_TickCount
        tiles := ai.v * (now - ai.qpc) / ai.freq / 4
        k := ((ai.kx && ai.ky) ? 0.7071 : 1) * AICamSign()   ; camera retournee : les touches vont dans l'autre sens
        ai.x += ai.kx * tiles * k, ai.y += ai.ky * tiles * k
    }
    ai.qpc := now
}

AIStop(ai) {
    AITrack(ai)
    AISetKeys(ai, 0, 0)
    ai.qpc := 0
}

; ---------- une etape de farm IA (rend la main toutes les quelques secondes) ----------
; drift compensation active = l'IA reste immobile sur le saturator, part chercher chaque token
; repere puis revient aussitot se recaler dessus.
AIStep(ai) {
    leash := Num(S["AI_Leash"], 10)
    if (A_TickCount - ai.lastHome > Num(S["AI_Home"], 20) * 1000) || (Abs(ai.x) > leash) || (Abs(ai.y) > leash)
        return AIGoHome(ai)
    if (best := AIScan(ai))
        return AIGet(ai, best)
    AICamCheck(ai)
    if (!ai.stay && S["AI_Wander"]) {
        if (found := AIWander(ai))
            AIChase(ai, found)
        return
    }
    if ai.stay
        SetStatus("AI Gather", "on the sprinkler, watching for tokens")
    Loop 10 {   ; on attend sur place en regardant
        CheckStop()
        ai.idle++
        ; mode eco : on regarde moins souvent quand il ne se passe rien
        Sleep 1000 // Max(1, Num(S["AI_FPS"], 15)) * ((S["AI_Eco"] && ai.idle > 30) ? 2 : 1)
        if (best := AIScan(ai))
            return AIGet(ai, best)
        AICamCheck(ai)
    }
}

; rien vu depuis un moment : la camera fait demi-tour pour regarder de l'autre cote
AICamCheck(ai) {
    if !Num(S["AI_Cam"])
        return
    if (A_TickCount - Max(ai.lastSeen, ai.lastCam) >= Num(S["AI_CamEvery"], 4) * 1000) {
        AIStop(ai)
        SetStatus("AI Gather", "turning the camera")
        AICamTurn()
        ai.lastCam := A_TickCount
    }
}

; va chercher un token ; en mode "reste sur le sprinkler" on revient aussitot apres
AIGet(ai, tgt) {
    ai.idle := 0
    if !AIStill(tgt.x, tgt.y) {   ; elle bouge : abeille, nom de joueur... on l'oublie un moment
        ai.ghosts.Push({x: tgt.x, y: tgt.y, t: A_TickCount})
        if (ai.ghosts.Length > 12)
            ai.ghosts.RemoveAt(1)
        return
    }
    AIChase(ai, tgt)
    if ai.stay
        AIGoHome(ai)
}

; va droit sur le token : sa position a l'ecran est convertie une fois en cases, puis on marche
; jusque-la a la vitesse reelle (haste comprise). Pas de suivi image par image : le detecteur
; perd trop souvent le token quand on bouge. Un vrai token est ramasse en passant dessus.
AIChase(ai, tgt) {
    ai.chased++, Stats["tokens"]++, ai.moved := true, ai.lastSeen := A_TickCount
    SetStatus("AI Gather", "going for " tgt.tk.name)
    vw := AIView(), tp := AITokenPx(), sg := AICamSign(), leash := Num(S["AI_Leash"], 10)
    ; ecart en cases (la camera est penchee : la profondeur est plus tassee a l'ecran)
    kx := (tgt.x - vw.px) / tp, ky := (vw.py - tgt.y) / (tp * 0.75)
    ; objectif dans le repere du champ, sans depasser la laisse
    gx := Max(-leash, Min(leash, ai.x + sg * kx)), gy := Max(-leash, Min(leash, ai.y + sg * ky))
    deadline := A_TickCount + Num(S["AI_Chase"], 4) * 1000, reached := false
    ai.qpc := 0
    try {
        Loop {
            CheckStop()
            AITrack(ai)
            rx := gx - ai.x, ry := gy - ai.y
            if (Abs(rx) < 0.35 && Abs(ry) < 0.35) {
                reached := true
                break
            }
            if (A_TickCount > deadline)
                break
            ; touches relatives a la camera : camera retournee = sens inverse
            AISetKeys(ai, Abs(rx) >= 0.35 ? (rx > 0 ? sg : -sg) : 0, Abs(ry) >= 0.35 ? (ry > 0 ? sg : -sg) : 0)
            Sleep 15
        }
    } finally
        AIStop(ai)
    if reached
        Sleep 150   ; le temps de ramasser
    return reached
}

; tour autour du sprinkler pour recolter, en guettant les tokens ; renvoie le token vu
AIWander(ai) {
    static dirs := [[0, 1], [1, 0], [0, -1], [-1, 0]]
    d := dirs[Mod(ai.leg++, 4) + 1], len := Num(S["AI_WanderTiles"], 2)
    frame := 1000 // Max(1, Num(S["AI_FPS"], 15))
    sx := ai.x, sy := ai.y, found := 0
    ai.qpc := 0, ai.moved := true
    try {
        AISetKeys(ai, d[1], d[2])
        Loop {
            CheckStop()
            ft := A_TickCount
            AITrack(ai)
            if (Abs(ai.x - sx) + Abs(ai.y - sy) >= len)
                break
            if (found := AIScan(ai))
                break
            if ((wait := frame - (A_TickCount - ft)) > 0)
                Sleep wait
        }
    } finally
        AIStop(ai)
    return found
}

; retour au sprinkler : saturator (Supreme) si visible, sinon on refait le chemin a l'envers
AIGoHome(ai) {
    AIStop(ai)
    if !ai.moved {   ; pas bouge depuis le dernier recalage : rien a faire
        ai.lastHome := A_TickCount
        return
    }
    SetStatus("AI Gather", "back to the sprinkler")
    AICamRestore()   ; on revient avec la camera d'origine
    if !(SprinklerType = "Supreme" && bm_LocateSprinkler(&sx, &sy) = 1) {
        if (Abs(ai.x) > 0.3)
            bm_Walk(Abs(ai.x), ai.x > 0 ? LeftKey : RightKey)
        if (Abs(ai.y) > 0.3)
            bm_Walk(Abs(ai.y), ai.y > 0 ? BackKey : FwdKey)
    }
    if (SprinklerType = "Supreme")   ; recalage precis sur le pixel bleu du saturator
        try bm_fieldDriftCompensation()
    ai.x := 0.0, ai.y := 0.0, ai.lastHome := A_TickCount, ai.moved := false
}
