﻿bm_gotoramp()
bm_Walk(39, BackKey, LeftKey)
bm_Walk(14, LeftKey)
send "{" RotLeft " 2}"
