﻿bm_Walk(8, BackKey)
bm_Walk(10, LeftKey, BackKey)
bm_Walk(14.5, BackKey)
bm_Walk(28, LeftKey)
bm_Walk(36, FwdKey)
bm_Walk(3, RightKey)
bm_Walk(4, FwdKey)
bm_Walk(4, LeftKey)
bm_Walk(27, FwdKey)
bm_Walk(2.75, FwdKey, LeftKey)
bm_Walk(90, FwdKey)

switch HiveSlot
    {
    case 3:
    bm_Walk(2.7, BackKey) ;center on hive pad 3

    default:
    bm_Walk(1.5, BackKey) ;walk backwards to avoid thicker hives
    bm_Walk(35, RightKey) ;walk to ramp
    bm_Walk(2.7, BackKey) ;center with hive pads
    }

; [2024-01-15/rpertusio] Avoid using corner (Hive 1 and ramp) where character gets stuck after 2024-01-12 BSS update
; [2024-01-15/rpertusio] Aligns with default SpawnLocation, saves walking if player chose Hive 3
