﻿if (MoveMethod = "walk")
{
	bm_gotoramp()
	bm_Walk(88.875, BackKey, LeftKey)
	bm_Walk(27, LeftKey)
	HyperSleep(50)
	send "{" RotLeft " 2}"
	;inside
	bm_Walk(50, FwdKey)	
}
else
{
	bm_gotoramp()
	bm_gotocannon()
	send "{e down}"
	HyperSleep(100)
	send "{e up}{" LeftKey " down}"
	HyperSleep(700)
	send "{space 2}"
	HyperSleep(4450)
	send "{" LeftKey " up}{space}"
	HyperSleep(1000)
	send "{" RotLeft " 2}"
	bm_Walk(4, BackKey, LeftKey)
	bm_Walk(8, FwdKey, LeftKey)
	bm_Walk(6, FwdKey)
	bm_Walk(5, BackKey)
	bm_Walk(8, RightKey)
	;inside
	bm_Walk(30, FwdKey)
}
send "{space down}"
HyperSleep(100)
send "{space up}"
bm_Walk(6, FwdKey)
bm_Walk(5, RightKey)
bm_Walk(9, RightKey, BackKey)
bm_Walk(4, RightKey)
bm_Walk(2, LeftKey)
bm_Walk(21, BackKey)
bm_Walk(3.4, FwdKey, LeftKey)
bm_Walk(16, LeftKey)
;path 230630 noobyguy
