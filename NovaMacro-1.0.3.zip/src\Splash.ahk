; =====================================================================
;  Ecran de chargement : logo, etape en cours et barre de progression,
;  affiche pendant le chargement de la macro et la recherche de mise a jour.
;  N'utilise que des controles simples (marche avant le demarrage de Gdip).
; =====================================================================

global SplashGui := 0, SplashStep := 0, SplashBar := 0, SplashPct := 0

; affiche ou met a jour l'ecran de chargement
Splash(pct, step) {
    global SplashGui, SplashStep, SplashBar, SplashPct
    if !SplashGui {
        acc := SplashAccent()
        g := Gui("-Caption +ToolWindow +AlwaysOnTop -DPIScale", "Nova Macro")
        g.BackColor := "1B1B1B", g.MarginX := g.MarginY := 0
        try g.Add("Picture", "x174 y34 w72 h72 BackgroundTrans", A_ScriptDir "\assets\logo\nova_symbol_64.png")
        g.SetFont("s18 cEDEDED", "Segoe UI Semibold")
        g.Add("Text", "x0 y116 w420 Center BackgroundTrans", "Nova Macro")
        g.SetFont("s9 c" acc, "Segoe UI Semibold")
        g.Add("Text", "x0 y150 w420 Center BackgroundTrans", "version " SplashVersion())
        g.SetFont("s9 cA3A3A3", "Segoe UI")
        SplashStep := g.Add("Text", "x24 y196 w372 Center BackgroundTrans", step)
        SplashBar := g.Add("Progress", "x40 y222 w340 h5 Background2C2C2C c" acc " -Theme", 0)
        g.SetFont("s7 c6E6E6E", "Segoe UI")
        g.Add("Text", "x0 y240 w420 Center BackgroundTrans", "Created by 5lmj")
        g.Show(Format("w420 h264{}", EnvGet("NOVA_TEST") = "1" ? " NA" : ""))
        WinSetRegion("0-0 w420 h264 R22-22", g)
        SplashGui := g
    }
    SplashStep.Value := step
    ; la barre avance en douceur jusqu'a la nouvelle valeur
    while (SplashPct < pct) {
        SplashPct := Min(pct, SplashPct + 4)
        SplashBar.Value := SplashPct
        Sleep 8
    }
}

SplashClose() {
    global SplashGui
    if SplashGui
        try SplashGui.Destroy()
    SplashGui := 0
}

; version et couleur d'accent lues directement (les reglages ne sont pas encore charges)
SplashVersion() => FileExist(A_ScriptDir "\version.txt") ? Trim(FileRead(A_ScriptDir "\version.txt"), " `t`r`n") : "1.0.0"
SplashAccent() {
    static colors := Map("Nova", "7C3AED", "Blue", "2F7FEA", "Honey", "F2B01E", "Purple", "8B5CF6", "Green", "22C55E", "Pink", "EC4899")
    a := IniRead(A_ScriptDir "\settings.ini", "cfg", "UI_Accent", "Nova")
    return colors.Has(a) ? colors[a] : "7C3AED"
}
