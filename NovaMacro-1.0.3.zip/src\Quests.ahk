﻿; =====================================================================
;  Quetes : lecture du journal de quetes, rendu des quetes, objectifs
; 
; =====================================================================

global QuestGatherField := "", QuestKills := Map(), QuestAnt := 0, QuestBoosts := Map()
global QuestText := Map()

global QUEST_INFO := Map(
    "Polar", {titles: ["polar_bear.png", "polar_bear2.png", "polar_bear3.png"], data: PolarBear, nameVar: 10},
    "Black", {titles: ["black_bear.png", "black_bear2.png", "black_bear3.png", "black_bear4.png", "black_bear5.png", "black_bear6.png"], data: BlackBear, nameVar: 100},
    "Bucko", {titles: ["bucko.png", "bucko2.png"], data: BuckoBee, nameVar: 100},
    "Riley", {titles: ["riley.png", "riley2.png"], data: RileyBee, nameVar: 100},
    "Honey", {titles: ["honeyhunt.png"], data: 0, nameVar: 0})

AnyQuestEnabled() {
    for q in QUEST_LIST
        if S["Q_" q[1]]
            return true
    return false
}

DoQuests() {
    global QuestGatherField := "", QuestKills := Map(), QuestAnt := 0, QuestBoosts := Map()
    if !AnyQuestEnabled()
        return
    for q in QUEST_LIST {
        giver := q[1]
        if !S["Q_" giver]
            continue
        CheckStop()
        r := QuestProg(giver)
        ; Black et Brown : une quete par heure maximum
        cooldownOk := (giver != "Black" && giver != "Brown") || (Now() - GetTime("quest_" giver) >= 3600)
        ; si le journal n'a pas pu etre lu, on ne retourne pas voir le PNJ plus d'une fois par 10 min
        if !r.found && (Now() - GetTime("questtry_" giver) < 600)
            cooldownOk := false
        if (r.complete && cooldownOk) {
            SetTime("questtry_" giver)
            SetStatus("Quest", q[2] ": turn in / new quest")
            if GoQuestGiver(giver) {
                SetTime("quest_" giver)
                Stats["quests"]++
                Hook("Quest turned in: " q[2], (r.name ? "Quest done: " r.name : "New quest requested."), "quest", [["Quests turned in (session)", Stats["quests"]]], false, 2)
                r := QuestProg(giver)
                Hook("New quest: " q[2], QuestText.Has(giver) ? QuestText[giver] : "", "quest", "", false, 2)
            }
        }
        ; on additionne ce qu'il reste a faire
        for mob in r.kills
            QuestKills[mob] := 1
        if r.ant
            QuestAnt := 1
        for b in r.boosts
            QuestBoosts[b] := 1
        if (QuestGatherField = "" && r.field != "")
            QuestGatherField := r.field
    }
    try bm_OpenMenu()
    if (QuestGatherField != "")
        Log("Quest: gathering at " QuestGatherField)
}

; ---------- trouve le titre d'une quete en faisant defiler le journal ----------
FindQuestTitle(titles, aim := "quest") {
    bm_OpenMenu("questlog")
    UpdateWindow()
    pBMLog := 0, Qfound := [1, 0, 0]
    Loop 70 {
        for t in titles {
            Qfound := bm_imgSearch(t, 50, aim)
            if (Qfound[1] = 0) {
                if pBMLog
                    Gdip_DisposeImage(pBMLog)
                return Qfound
            }
        }
        ActivateRoblox()
        UpdateWindow()
        if (A_Index = 1) {
            Loop 50 {   ; remonte tout en haut
                MouseMove windowX + 30, windowY + offsetY + 200, 5
                SendInput "{WheelUp}"
                Sleep 50
            }
            pBMLog := Gdip_BitmapFromScreen(windowX + 30 "|" windowY + offsetY + 180 "|30|400")
        } else {
            MouseMove windowX + 30, windowY + offsetY + 200, 5
            SendInput "{WheelDown}"
            Sleep 500
            pBMScreen := Gdip_BitmapFromScreen(windowX + 30 "|" windowY + offsetY + 180 "|30|400")
            if (Gdip_ImageSearch(pBMScreen, pBMLog, , , , , , 50) = 1) {   ; fin du journal
                Gdip_DisposeImage(pBMLog), Gdip_DisposeImage(pBMScreen)
                return [1, 0, 0]
            }
            Gdip_DisposeImage(pBMLog), pBMLog := Gdip_CloneBitmap(pBMScreen), Gdip_DisposeImage(pBMScreen)
        }
    }
    if pBMLog
        Gdip_DisposeImage(pBMLog)
    return [1, 0, 0]
}

QuestBarStart(titleY) {
    UpdateWindow()
    SafeMouse()
    try result := ImageSearch(&fx, &fy, windowX, windowY + titleY, windowX + 306, windowY + windowHeight, "*5 " A_ScriptDir "\assets\questbargap.png")
    catch
        result := 0
    return (result = 1) ? fy - windowY : 0
}

; couleur de la barre d'un objectif : "Incomplete", "Complete" ou "Unknown"
ObjectiveState(startY, slot) {
    c := PixelGetColor(windowX + QuestBarInset + 10, windowY + QuestBarSize * (slot - 1) + startY + QuestBarGapSize + 5)
    if (c = 0xF46C55 || c = 0x6EFF60)
        return "Incomplete"
    if (c != 0x96C3DE && c != 0xE5F0F7 && c != 0x1B2A35)
        return "Complete"
    return "Unknown"
}

; champ a farmer pour une couleur de pollen, selon le nombre d'abeilles
PollenField(where) {
    switch where, 0 {
        case "Red": return HiveBees >= 35 ? "Pepper" : HiveBees >= 15 ? "Rose" : HiveBees >= 5 ? "Strawberry" : "Mushroom"
        case "Blue": return HiveBees >= 15 ? "Pine Tree" : HiveBees >= 5 ? "Bamboo" : "Blue Flower"
        case "White": return HiveBees >= 10 ? "Pineapple" : HiveBees >= 5 ? "Spider" : "Sunflower"
        case "Any": return S["F1_Field"] != "None" ? S["F1_Field"] : "Sunflower"
    }
    return where
}

; ---------- progression d'une quete ----------
QuestProg(giver) {
    r := {found: false, complete: true, name: "", field: "", kills: [], ant: 0, boosts: [], feed: ""}
    if (giver = "Brown")
        return BrownQuestProg()
    info := QUEST_INFO[giver]
    q := FindQuestTitle(info.titles)
    if (q[1] != 0) {
        QuestText[giver] := "No quest found"
        try UI_UpdateQuests()
        return r   ; pas de quete en cours -> on ira en chercher une
    }
    r.found := true
    startY := QuestBarStart(q[3])
    if !startY {
        r.complete := false
        return r
    }
    if (giver = "Honey") {
        st := ObjectiveState(startY, 1)
        r.complete := (st = "Complete"), r.name := "Honey Hunt"
        QuestText[giver] := "Honey Hunt: " st
        try UI_UpdateQuests()
        return r
    }
    ; nom de la quete
    for key, objs in info.data {
        try found := ImageSearch(&fx, &fy, windowX, windowY + startY - 30, windowX + 306, windowY + startY, "*" info.nameVar " " A_ScriptDir "\assets\" key ".png")
        catch
            found := 0
        if (found = 1) {
            r.name := key
            break
        }
    }
    if (r.name = "") {
        QuestText[giver] := "Quest not recognized"
        r.complete := false
        try UI_UpdateQuests()
        return r
    }
    objs := info.data[r.name]
    ; on fait defiler si tous les objectifs ne sont pas visibles
    Loop 5 {
        found := 0, nextY := windowY + startY
        Loop objs.Length {
            try res := ImageSearch(&fx, &fy, windowX + QuestBarInset, nextY, windowX + QuestBarInset + 300, nextY + QuestBarGapSize, "*5 " A_ScriptDir "\assets\questbargap.png")
            catch
                res := 0
            if (res != 1)
                break
            nextY += QuestBarSize, found++
        }
        if (found >= objs.Length)
            break
        MouseMove windowX + 30, windowY + offsetY + 225
        Send "{WheelDown 1}"
        Sleep 550
        startY -= 150
    }
    txt := r.name
    for o in objs {
        st := ObjectiveState(startY, o[1]), action := o[2], where := o[3]
        if (st = "Incomplete") {
            r.complete := false
            switch action, 0 {
                case "Kill":
                    if (where = "All")
                        for m in MOB_LIST
                            r.kills.Push(m[1])
                    else
                        r.kills.Push(where)
                case "Collect":
                    if (r.field = "")
                        r.field := PollenField(where)
                case "Get":
                    if (where = "Ant")
                        r.ant := 1
                    else
                        r.boosts.Push(where = "RedBoost" ? "red" : where = "BlueBoost" ? "blue" : "mountain")
                case "Feed":
                    r.feed := where
            }
        }
        txt .= "`n  " action " " where " : " (st = "Incomplete" ? "to do" : st = "Complete" ? "fait" : "?")
    }
    QuestText[giver] := txt
    try UI_UpdateQuests()
    return r
}

; ---------- quete Brown Bear (objectifs lus objet par objet) ----------
BrownQuestProg() {
    r := {found: false, complete: true, name: "", field: "", kills: [], ant: 0, boosts: [], feed: ""}
    static objectiveList := Map("dandelion", "Dand", "sunflower", "Sunf", "mushroom", "Mush", "blueflower", "Bluf", "clover", "Clove"
        , "strawberry", "Straw", "spider", "Spide", "bamboo", "Bamb", "pineapple", "Pinap", "stump", "Stump"
        , "cactus", "Cact", "pumpkin", "Pump", "pinetree", "Pine", "rose", "Rose", "mountaintop", "Mount"
        , "pepper", "Pepp", "coconut", "Coco", "redpollen", "Red", "bluepollen", "Blue", "whitepollen", "White")
    titles := ["brown_bear1.png", "brown_bear2.png", "brown_bear3.png", "brown_bear4.png", "brown_bear5.png"]
    q := FindQuestTitle(titles, "questbrown")
    if (q[1] != 0)
        q := FindQuestTitle(titles, "quest")
    if (q[1] != 0) {
        QuestText["Brown"] := "No quest found"
        try UI_UpdateQuests()
        return r
    }
    r.found := true
    startY := QuestBarStart(q[3])
    if !startY {
        r.complete := false
        return r
    }
    objectives := []
    while ((objectives.Length < 4) && (A_Index <= 5)) {
        pos := objectives.Length * QuestBarSize, size := 0
        pBM := Gdip_BitmapFromScreen(windowX "|" windowY + startY + QuestBarGapSize + pos "|304|" QuestBarSize - QuestBarGapSize)
        if (Gdip_ImageSearch(pBM, bitmaps["questbarinset"], , , , 6, , 5) = 1) {
            for sz in [16, 15, 14, 18, 17]
                if (Gdip_ImageSearch(pBM, bitmaps["s" sz "collect"], , 6, , , , 30) = 1) {
                    size := sz
                    break
                }
            if (size = 0)
                objectives.Push("unknown")
            else {
                for k in objectiveList {
                    for v in objectives
                        if (k = v)
                            continue 2
                    if (bitmaps.Has("s" size k) && (Gdip_ImageSearch(pBM, bitmaps["s" size k], , 6, , , , 30) = 1)) {
                        objectives.Push(k)
                        break
                    }
                }
            }
            Gdip_DisposeImage(pBM)
        } else {
            Gdip_DisposeImage(pBM)
            break
        }
    }
    txt := "", objField := ""
    for i, obj in objectives {
        where := (obj = "redpollen") ? PollenField("Red") : (obj = "bluepollen") ? PollenField("Blue")
            : (obj = "whitepollen") ? PollenField("White") : (obj = "blueflower") ? "Blue Flower"
            : (obj = "pinetree") ? "Pine Tree" : (obj = "mountaintop") ? "Mountain Top" : StrTitle(obj)
        st := ObjectiveState(startY, i)
        if (st = "Incomplete" && obj != "unknown") {
            r.complete := false
            ; un objectif de champ passe avant un objectif de couleur
            if (r.field = "" || InStr(objField, "pollen"))
                r.field := where, objField := obj
        }
        r.name .= (r.name ? "-" : "") (objectiveList.Has(obj) ? objectiveList[obj] : "?")
        txt .= "`n  Collect " where " : " (st = "Incomplete" ? "to do" : st = "Complete" ? "fait" : "?")
    }
    QuestText["Brown"] := (r.name ? r.name : "Brown") txt
    try UI_UpdateQuests()
    return r
}

; ---------- aller voir le donneur de quete ----------
GoQuestGiver(giver) {
    Loop 2 {
        ResetChar()
        SetStatus("Travel", "quest giver " giver)
        CallPath("gtq-" StrLower(giver))
        Loop 2 {
            Sleep 500
            if PressE(5) {
                Sleep 2000
                ClearScreen()
                return true
            }
        }
    }
    Log("Quest giver " giver " not found")
    return false
}
