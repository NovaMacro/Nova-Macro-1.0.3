﻿bm_gotoramp()
Send "{space down}{" RightKey " down}"
Sleep 100
Send "{space up}"
Walk(2)
Send "{" FwdKey " down}"
Walk(1.8)
Send "{" FwdKey " up}"
Walk(30)
send "{" RightKey " up}{space down}"
HyperSleep(300)
send "{space up}"
bm_Walk(4, RightKey)
bm_Walk(5, FwdKey)
bm_Walk(3, RightKey)
send "{space down}"
HyperSleep(300)
send "{space up}"
bm_Walk(5, FwdKey)
bm_Walk(2, LeftKey, FwdKey)
bm_Walk(8, FwdKey)
Send "{" FwdKey " down}{" RightKey " down}"
Walk(11)
send "{space down}{" RightKey " up}"
HyperSleep(200)
send "{space up}"
HyperSleep(1100)
send "{space down}"
HyperSleep(200)
send "{space up}"
Walk(18)
Send "{" FwdKey " up}"
bm_Walk(7, LeftKey)
;path 230212 zaappiix
