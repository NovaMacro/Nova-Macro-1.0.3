﻿bm_Walk(12, FwdKey)
bm_Walk(20, LeftKey)
bm_Walk(8, RightKey)
send "{" RotLeft " 2}"
bm_Walk(35, LeftKey)
bm_Walk(41, FwdKey)
bm_Walk(9, LeftKey)
bm_Walk(28, FwdKey)
bm_Walk(8, LeftKey)
bm_Walk(6, FwdKey, LeftKey)
bm_Walk(6, FwdKey)
bm_Walk(1.5, BackKey) ;walk backwards to avoid thicker hives
bm_Walk(35, RightKey) ;walk to ramp
bm_Walk(2.7, BackKey) ;center with hive pads

;path 230212 zaappiix
; [2024-01-15/rpertusio] Avoid using corner (Hive 1 and ramp) where character gets stuck after 2024-01-12 BSS update
