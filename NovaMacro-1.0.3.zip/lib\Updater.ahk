﻿; =====================================================================
;  Installation d'une mise a jour de Nova Macro (lance par la macro)
;  attend que la macro soit fermee, copie les nouveaux fichiers sans
;  toucher aux reglages des joueurs, puis relance la macro.
;  Arguments : pid de la macro, dossier de la nouvelle version, dossier de la macro
; =====================================================================
#Requires AutoHotkey v2.0
#NoTrayIcon

pid := A_Args[1], src := A_Args[2], dst := A_Args[3]
ProcessWaitClose pid, 20
Sleep 300

keepFiles := Map("settings.ini", 1, "macro.log", 1, "diagnostic.txt", 1)
keepFiles.CaseSense := 0
keepDirs := Map("profils", 1, "presets", 1)
keepDirs.CaseSense := 0
fails := 0
Loop Files src "\*", "FR" {
    rel := SubStr(A_LoopFileFullPath, StrLen(src) + 2)
    if keepFiles.Has(rel) || keepDirs.Has(StrSplit(rel, "\")[1])
        continue
    SplitPath dst "\" rel, , &dir
    DirCreate dir
    try FileCopy A_LoopFileFullPath, dst "\" rel, 1
    catch
        fails++
}
try FileDelete dst "\lib\Dynamic.ahk"   ; regenere au demarrage avec les nouveaux chemins et patterns
if fails
    MsgBox fails " file(s) could not be replaced (file open?).`nRun the update again later.", "Nova Macro", "Icon!"
Run '"' dst '\START.bat"', dst
