﻿bm_gotoramp()
bm_Walk(13, LeftKey, BackKey)
bm_Walk(10, BackKey)
send "{" RotRight " 3}"
Sleep 2000
