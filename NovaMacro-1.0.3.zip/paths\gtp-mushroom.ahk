﻿bm_gotoramp()
bm_Walk(36, BackKey, LeftKey)
send "{" RotRight " 4}"
bm_Walk(47, FwdKey)
bm_Walk(23, RightKey)
bm_Walk(3, BackKey, LeftKey)

; edited by Lorddrak