﻿bm_Walk(40.5, RightKey)
send "{" RotRight " 2}"
bm_Walk(22.5, RightKey)
bm_Walk(22.5, BackKey)
bm_Walk(13, RightKey)
bm_Walk(40.5, FwdKey)
bm_Walk(5.5, BackKey)
bm_Walk(10, RightKey)
if (HiveBees < 12) { ;walk
	bm_Walk(12, FwdKey)
	bm_Walk(8, RightKey)
	send "{" RotRight " 2}"
	send "{" FwdKey " down}"
	send "{space down}"
	Hypersleep(200)
	send "{space up}"
	send "{" FwdKey " up}"
	bm_walk(30, FwdKey)
	bm_walk(3, BackKey)
	send "{" RotLeft " 2}"
	bm_walk(30, FwdKey)
	bm_Walk(4.5, BackKey)
	bm_Walk(40.5, RightKey)
	bm_Walk(40.5, FwdKey)
	bm_Walk(34.5, RightKey)
	bm_Walk(27, FwdKey)
	}
else { ;use yellow cannon
    send "{space down}"
    Hypersleep(50)
    send "{space up}"
    bm_walk(4, rightkey)
    Hypersleep(1100)
    send "{e down}"
    HyperSleep(100)
    send "{e up}"
    Hypersleep(3000)
    bm_Walk(34, FwdKey)
    }

switch HiveSlot
	{
	case 3:
	bm_Walk(2.7, BackKey) ;center on hive pad 3

	default:
	bm_Walk(1.5, BackKey) ;walk backwards to avoid thicker hives
	bm_Walk(35, RightKey) ;walk to ramp
	bm_Walk(2.7, BackKey) ;center with hive pads
	}

; [2024-01-15/rpertusio] Avoid using corner (Hive 1 and ramp) where character gets stuck after 2024-01-12 BSS update
; [2024-01-15/rpertusio] Now can walk without yellow cannon if < 12 bees
; [2024-01-15/rpertusio] Aligns with default SpawnLocation, saves walking if player chose Hive 3
