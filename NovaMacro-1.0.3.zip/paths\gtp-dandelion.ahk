﻿bm_gotoramp()
send "{" RotRight "}"
bm_Walk(39, BackKey) ;
send "{" RotLeft " 3}"
bm_Walk(51, FwdKey) ;
bm_Walk(6, RightKey)
bm_Walk(9, BackKey)


; edited by Lorddrak