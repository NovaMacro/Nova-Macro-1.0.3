﻿if (MoveMethod = "Cannon") {
    bm_gotoramp()
    bm_gotocannon()
    send "{e down}"
    HyperSleep(100)
    send "{e up}{" RightKey " down}{" BackKey " down}"
    HyperSleep(950)
    send "{space 2}"
    HyperSleep(2700)
    send "{" RightKey " up}"
    HyperSleep(500)
    send "{" BackKey " up}"
    HyperSleep(600)
    send "{space}{" RotLeft " 4}"
    Sleep 1500
} else {
    bm_gotoramp()
    bm_Walk(67.5, BackKey, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(31, FwdKey)
    bm_Walk(7.8, LeftKey)
    bm_Walk(10, BackKey)
    bm_Walk(5, RightKey)
    bm_Walk(1.5, FwdKey)
    bm_Walk(60, LeftKey)
    bm_Walk(3.75, RightKey)
    bm_Walk(38, FwdKey)
    bm_Walk(18, RightKey, FwdKey)
    bm_Walk(10, FwdKey)
    ;path 230630 noobyguy
}
