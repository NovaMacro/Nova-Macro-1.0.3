if (MoveMethod = "walk")
{
	bm_gotoramp()
	bm_Walk(69, BackKey, LeftKey)
	send "{" RotRight " 4}"
	bm_Walk(30, FwdKey)
	bm_Walk(20, FwdKey, RightKey)
	send "{" RotRight " 2}"
	bm_Walk(43.5, FwdKey)
	bm_Walk(16, RightKey)
	send "{" FwdKey " down}"
	HyperSleep(200)
	send "{space down}"
	HyperSleep(100)
	send "{space up}"
	HyperSleep(800)
	send "{" FwdKey " up}{" RotLeft " 2}"
	bm_Walk(29.25, FwdKey)
	bm_Walk(15, FwdKey, LeftKey)
	bm_Walk(8, LeftKey)
	bm_Walk(15, FwdKey, LeftKey)
	bm_Walk(3.5, RightKey)
	bm_Walk(11, BackKey)
	send "{" RotLeft " 2}"
}
else
{
	bm_gotoramp()
	bm_gotocannon()
	send "{e down}"
	HyperSleep(100)
	send "{e up}"
	HyperSleep(2500)
	bm_Walk(30, FwdKey)
	bm_Walk(2, BackKey)
	bm_Walk(22, LeftKey)
	bm_Walk(12, RightKey)
	bm_Walk(3, LeftKey)
	bm_Walk(5, FwdKey)
	send "{" RotRight " 2}"
}
Sleep 1000
;path 230630 noobyguy - walk updated
;adjusted for memory match OAC
