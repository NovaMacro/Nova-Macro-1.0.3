﻿if (MoveMethod = "walk") {
    bm_gotoramp()
    bm_Walk(67.5, BackKey, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(37.5, FwdKey)
    bm_Walk(38, LeftKey, FwdKey)
    bm_Walk(9, BackKey, RightKey)
}
else {
    bm_gotoramp()
    bm_gotocannon()
    send "{e down}"
    HyperSleep(100)
    send "{e up}{" BackKey " down}"
    HyperSleep(1050)
    send "{space 2}"
    HyperSleep(300)
    send "{" BackKey " up}{space}{" RotLeft " 4}"
    Sleep 1500
    bm_Walk(20, FwdKey)
    bm_Walk(10, FwdKey, LeftKey)
    bm_Walk(10, LeftKey)
    bm_Walk(9, BackKey, RightKey)
}
;path 230729 noobyguy
