﻿if (MoveMethod = "walk")
{
	bm_gotoramp()
	bm_Walk(44.75, BackKey, LeftKey) ; 47.25
	bm_Walk(28, LeftKey)
	bm_Walk(10, BackKey)
	bm_Walk(6, LeftKey)
	bm_Walk(12, BackKey, LeftKey) ;corner align
	sleep 500
	bm_Walk(1.5, RightKey)
	bm_Walk(12.2, FwdKey)
	bm_Walk(14, LeftKey) ; ladder 1 ; 12.5
	bm_Walk(1.5, RightKey, BackKey)
	bm_Walk(15, BackKey)
	bm_Walk(7.5, LeftKey) ;corner align 2
	sleep 500
	bm_Walk(1.75, RightKey)
	bm_Walk(4, FwdKey)
	bm_Walk(22.5, LeftKey) ; ladder 2
	send "{" RotLeft " 2}"
	bm_Walk(40, FwdKey)
	bm_Walk(1, BackKey)
	bm_Walk(20, RightKey) ; additional corner align for haste
	bm_Walk(5, FwdKey)
	bm_Walk(16, LeftKey) ; 5
	bm_Walk(15, FwdKey)
}
else
{
	bm_gotoramp()
	bm_gotocannon()
	Send "{e down}"
	HyperSleep(100)
	Send "{e up}{" FwdKey " down}{" LeftKey " down}"
	HyperSleep(1500)
	send "{space 2}"
	Sleep 8000
	Send "{" FwdKey " up}{" LeftKey " up}"
	bm_Walk(15, BackKey)
	bm_Walk(3.5, RightKey)
	bm_Walk(2, RightKey, BackKey)
	bm_Walk(1, BackKey)
}
