﻿If (MoveMethod = "walk")
{
    bm_gotoramp()
    bm_Walk(67.5, BackKey, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(31, FwdKey)
    bm_Walk(7.8, LeftKey)
    bm_Walk(10, BackKey)
    bm_Walk(5, RightKey)
    bm_Walk(1.5, FwdKey)
    bm_Walk(60, LeftKey)
    bm_Walk(45, FwdKey)
    bm_walk(3, BackKey)
    bm_Walk(3, LeftKey)
    bm_Walk(47, LeftKey, FwdKey)
    send "{" RotLeft " 2}"
    bm_Walk(9, RightKey)
    bm_Walk(9, FwdKey)
    bm_walk(3, LeftKey)
    bm_walk(3, BackKey)
}
else {
    bm_gotoramp()
    bm_gotocannon()
    send "{e down}"
    HyperSleep(100)
    send "{e up}{" RightKey " down}{" BackKey " down}"
    HyperSleep(925)
    send "{space 2}"
    HyperSleep(5000)
    send "{" BackKey " up}{" RightKey " up}{space}"
    Sleep 1000
    send "{" RotRight " 3}{" FwdKey " down}{space down}"
    HyperSleep(300)
    send "{space up}"
    send "{space}"
    HyperSleep(2000)
    send "{" FwdKey " up}{" RotLeft " 1}"
    bm_Walk(15, RightKey)
    bm_Walk(15, FwdKey)
    bm_walk(3, LeftKey)
    bm_walk(3, BackKey)
}
;path 230212 zaappiix
;path 230729 noobyguy
; edited by Lorddrak