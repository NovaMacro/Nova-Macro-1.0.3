﻿; =====================================================================
;  Interface Nova Macro
;  onglets (haut) -> sections (icones a gauche) -> pages (pastilles)
;  reglages en lignes : nom a gauche, controle a droite, "?" d'aide
; =====================================================================

global ACCENTS := Map("Nova", ["7C3AED", "FFFFFF"], "Blue", ["2F7FEA", "FFFFFF"], "Honey", ["F2B01E", "1A1406"], "Purple", ["8B5CF6", "FFFFFF"]
    , "Green", ["22C55E", "0B1A10"], "Pink", ["EC4899", "FFFFFF"])
global CLR := Map("win", "1B1B1B", "top", "232323", "body", "282828", "rail", "222222", "tile", "323232"
    , "pill", "333333", "input", "1E1E1E", "txt", "EDEDED", "dim", "A3A3A3", "faint", "6E6E6E"
    , "ok", "34D399", "bad", "F87171", "warn", "F5B921", "btn", "333333")
global MainGui, Ctl := Map(), UI := Map(), TipText := Map()
global PageCtl := Map(), PillCtl := Map(), RailCtl := Map(), TabCtl := Map(), CurKey := ""
global CurTab := "", CurSec := Map(), CurPg := Map()
global WIN_W := 760, WIN_H := 492, TOP_H := 42, BODY_Y := 42, BODY_H := 360
global RAIL_X := 8, RAIL_W := 60, COL1 := 80, COL2 := 416, COLW := 326, ROW0 := 88, ROWH := 36, TILE_H := 30

; themes : [fenetre, barre du haut, corps, barre d'icones, ligne, pastille, champ de saisie]
global THEMES := Map("Dark", ["1B1B1B", "232323", "282828", "222222", "323232", "333333", "1E1E1E"]
    , "Black", ["0B0B0C", "121214", "161618", "111113", "1F1F22", "222226", "0E0E10"]
    , "Slate", ["161B22", "1C222B", "212833", "1A2029", "2A323E", "2C3542", "141920"]
    , "Midnight", ["0F1424", "141A2E", "182036", "121830", "222B47", "26304E", "0D1120"]
    , "Forest", ["121A15", "17211B", "1B2720", "151F19", "24332A", "27372D", "0F1612"])

SetAccent() {
    a := ACCENTS.Has(S["UI_Accent"]) ? ACCENTS[S["UI_Accent"]] : ACCENTS["Nova"]
    CLR["acc"] := a[1], CLR["accTxt"] := a[2]
    t := THEMES.Has(S["UI_Theme"]) ? THEMES[S["UI_Theme"]] : THEMES["Dark"]
    for i, k in ["win", "top", "body", "rail", "tile", "pill", "input"]
        CLR[k] := t[i]
    CLR["btn"] := t[5]
}

ARGB(hex) => 0xFF000000 | Integer("0x" hex)

; ---------- dessin (Gdip, mis en cache) ----------
HBM(key, w, h, draw) {
    static cache := Map()
    if cache.Has(key)
        return cache[key]
    pBM := Gdip_CreateBitmap(w, h)
    G := Gdip_GraphicsFromImage(pBM)
    Gdip_SetSmoothingMode(G, 4)
    draw(G, w, h)
    Gdip_DeleteGraphics(G)
    hb := Gdip_CreateHBITMAPFromBitmap(pBM)
    Gdip_DisposeImage(pBM)
    return cache[key] := hb
}

RoundHBM(w, h, r, fill, bg, border := "") {
    return HBM("r|" w "|" h "|" r "|" fill "|" bg "|" border, w, h, Draw)
    Draw(G, w, h) {
        Gdip_GraphicsClear(G, ARGB(bg))
        br := Gdip_BrushCreateSolid(ARGB(fill))
        if r
            Gdip_FillRoundedRectangle(G, br, 0, 0, w - 1, h - 1, r)
        else
            Gdip_FillRectangle(G, br, 0, 0, w, h)
        Gdip_DeleteBrush(br)
        if (border != "") {
            pen := Gdip_CreatePen(ARGB(border), 1)
            Gdip_DrawRoundedRectangle(G, pen, 0, 0, w - 1, h - 1, r)
            Gdip_DeletePen(pen)
        }
    }
}

; onglet actif : arrondi en haut seulement, se fond dans le corps de la fenetre
TabHBM(w, h, fill, bg) {
    return HBM("tab|" w "|" h "|" fill "|" bg, w, h, Draw)
    Draw(G, w, h) {
        Gdip_GraphicsClear(G, ARGB(bg))
        br := Gdip_BrushCreateSolid(ARGB(fill))
        Gdip_FillRoundedRectangle(G, br, 0, 0, w - 1, h + 12, 9)
        Gdip_DeleteBrush(br)
    }
}

ToggleHBM(on, bg) {
    return HBM("t|" on "|" bg "|" CLR["acc"], 46, 24, Draw)
    Draw(G, w, h) {
        Gdip_GraphicsClear(G, ARGB(bg))
        br := Gdip_BrushCreateSolid(ARGB(on ? CLR["acc"] : "1E1E1E"))
        Gdip_FillRoundedRectangle(G, br, 0, 0, 45, 23, 11)
        Gdip_DeleteBrush(br)
        if on {
            knob := Gdip_BrushCreateSolid(0xFFFFFFFF)
            Gdip_FillEllipse(G, knob, 26, 4, 15, 15)
            Gdip_DeleteBrush(knob)
            dot := Gdip_BrushCreateSolid(ARGB(CLR["acc"]))
            Gdip_FillEllipse(G, dot, 30, 8, 7, 7)
            Gdip_DeleteBrush(dot)
        } else {
            pen := Gdip_CreatePen(0xFFE5E5E5, 2.2)
            Gdip_DrawEllipse(G, pen, 6, 5, 13, 13)
            Gdip_DeletePen(pen)
            pen := Gdip_CreatePen(0xFF3C3C3C, 1)
            Gdip_DrawRoundedRectangle(G, pen, 0, 0, 45, 23, 11)
            Gdip_DeletePen(pen)
        }
    }
}

CircleHBM(d, fill, bg, border := "") {
    return HBM("c|" d "|" fill "|" bg "|" border, d, d, Draw)
    Draw(G, w, h) {
        Gdip_GraphicsClear(G, ARGB(bg))
        br := Gdip_BrushCreateSolid(ARGB(fill))
        Gdip_FillEllipse(G, br, 0, 0, d - 1, d - 1)
        Gdip_DeleteBrush(br)
        if (border != "") {
            pen := Gdip_CreatePen(ARGB(border), 1)
            Gdip_DrawEllipse(G, pen, 0, 0, d - 1, d - 1)
            Gdip_DeletePen(pen)
        }
    }
}

; ---------- ajout de controles ----------
AddC(type, opts := "", text := "") {
    c := MainGui.Add(type, opts, text)
    if (CurKey != "")
        PageCtl[CurKey].Push(c)
    if IsObject(CaptureList)   ; controles d'un groupe qu'on peut masquer (ex : pattern en mode IA)
        CaptureList.Push(c)
    if (type = "DropDownList" || type = "Edit")
        DllCall("uxtheme\SetWindowTheme", "Ptr", c.Hwnd, "Str", "DarkMode_CFD", "Ptr", 0)
    else if (type = "UpDown")
        DllCall("uxtheme\SetWindowTheme", "Ptr", c.Hwnd, "Str", "DarkMode_Explorer", "Ptr", 0)
    return c
}

Font(opts := "", name := "Segoe UI") => MainGui.SetFont("norm " opts, name)

Tip(ctl, txt) => TipText[ctl.Hwnd] := txt

; une ligne de reglage : fond arrondi, nom a gauche, petit "?" d'aide
Tile(x, y, w, label, help := "", h := TILE_H) {
    AddC("Picture", Format("x{} y{} w{} h{}", x, y, w, h), "HBITMAP:*" RoundHBM(w, h, 8, CLR["tile"], CLR["body"]))
    Font("s10 c" CLR["txt"])
    t := AddC("Text", Format("x{} y{} h{} 0x200 BackgroundTrans", x + 12, y, h), label)
    if (help != "") {
        t.GetPos(, , &tw)
        qx := x + 12 + tw + 7, qy := y + (h - 15) // 2
        q := AddC("Picture", Format("x{} y{} w15 h15", qx, qy), "HBITMAP:*" CircleHBM(15, "3D3D3D", CLR["tile"]))
        Font("s7 bold c" CLR["dim"])
        qt := AddC("Text", Format("x{} y{} w15 h15 Center 0x200 BackgroundTrans", qx, qy), "?")
        show := (*) => (ToolTip(help), SetTimer(() => ToolTip(), -7000))
        q.OnEvent("Click", show), qt.OnEvent("Click", show)
        Tip(q, help), Tip(qt, help)
    }
    Font("s10 c" CLR["txt"])
    return {x: x, y: y, w: w, h: h, r: x + w - 10, m: y + (h - 24) // 2}
}

global RowBase := ROW0
Cell(col, row) => {x: col = 1 ? COL1 : COL2, y: RowBase + (row - 1) * ROWH}

; titre de groupe au-dessus d'une colonne (les lignes commencent juste en dessous)
Group(col, title) {
    global RowBase := ROW0 + 24
    Font("s8 bold c" CLR["faint"])
    AddC("Text", Format("x{} y{} w{} BackgroundTrans", (col = 1 ? COL1 : COL2) + 4, ROW0 + 2, COLW), StrUpper(title))
    Font("s10 c" CLR["txt"])
}

SaveKey(key, ctl, *) {
    SaveSetting(key, (ctl.Type = "DDL") ? ctl.Text : ctl.Value)
    ApplyGlobals()
    OnFieldSetting(key)
}

DDLAt(x, y, w, key, items) {
    Font("s9 c" CLR["txt"])
    c := AddC("DropDownList", Format("x{} y{} w{}", x, y, w), items)
    for i, v in items
        if (v = S[key])
            c.Value := i
    if !c.Value
        c.Value := 1
    c.OnEvent("Change", SaveKey.Bind(key))
    Ctl[key] := c
    return c
}

SpinAt(x, y, w, key, lo, hi) {
    Font("s10 c" CLR["txt"])
    c := AddC("Edit", Format("x{} y{} w{} h24 Right -E0x200 Background{} c{}", x, y, w, CLR["input"], CLR["txt"]), S[key])
    AddC("UpDown", Format("Range{}-{} 0x80", lo, hi), Num(S[key], lo))
    c.OnEvent("Change", SaveKey.Bind(key))
    Ctl[key] := c
    return c
}

EditAt(x, y, w, key, opts := "") {
    Font("s9 c" CLR["txt"])
    c := AddC("Edit", Format("x{} y{} w{} h24 -E0x200 Background{} c{} {}", x, y, w, CLR["input"], CLR["txt"], opts), S[key])
    c.OnEvent("Change", SaveKey.Bind(key))
    Ctl[key] := c
    return c
}

ToggleAt(x, y, key, bg := "") {
    bg := bg ? bg : CLR["tile"]
    pic := AddC("Picture", Format("x{} y{} w46 h24", x, y), "HBITMAP:*" ToggleHBM(Num(S[key]) ? 1 : 0, bg))
    pic.OnEvent("Click", (*) => (SaveSetting(key, Num(S[key]) ? 0 : 1), ApplyGlobals(), OnToggle(key)
        , pic.Value := "HBITMAP:*" ToggleHBM(Num(S[key]) ? 1 : 0, bg)))
    return pic
}

; met a jour un controle si le reglage a change ailleurs (ex : slot de ruche apres reconnexion)
RefreshControl(key) {
    if Ctl.Has(key) {
        c := Ctl[key]
        if (c.Type = "DDL") {
            try c.Choose(S[key])
        } else
            c.Value := S[key]
    }
}

OnToggle(key) {
    if (key = "UI_OnTop")
        MainGui.Opt((S["UI_OnTop"] ? "+" : "-") "AlwaysOnTop")
    OnFieldSetting(key)
}

global CaptureList := "", Hidden := Map()

; met a jour les cartes et leur texte quand un reglage du champ change
OnFieldSetting(key) {
    if RegExMatch(key, "^F(\d)_", &m) && (FieldCards.Length >= Integer(m[1])) {
        if (key ~= "_AI$")
            CardAIState(Integer(m[1]))
        FieldSub(Integer(m[1]))
    }
}

; lignes completes (nom + controle a droite)
RowToggle(col, row, label, key, help := "") {
    p := Cell(col, row), t := Tile(p.x, p.y, COLW, label, help)
    return ToggleAt(t.r - 46, t.m, key)
}
RowDDL(col, row, label, key, items, w := 150, help := "") {
    p := Cell(col, row), t := Tile(p.x, p.y, COLW, label, help)
    return DDLAt(t.r - w, t.m, w, key, items)
}
RowSpin(col, row, label, key, lo, hi, help := "", w := 80) {
    p := Cell(col, row), t := Tile(p.x, p.y, COLW, label, help)
    return SpinAt(t.r - w, t.m, w - 18, key, lo, hi)
}
RowText(col, row, label, valueKey) {
    p := Cell(col, row), t := Tile(p.x, p.y, COLW, label)
    Font("s10 c" CLR["txt"], "Segoe UI Semibold")
    UI[valueKey] := AddC("Text", Format("x{} y{} w160 h{} Right 0x200 BackgroundTrans", t.r - 160, p.y, TILE_H), "-")
    Font("s10 c" CLR["txt"])
}
RowWide(row, label, help := "") => Tile(COL1, ROW0 + (row - 1) * ROWH, COL2 + COLW - COL1, label, help)
RowBtn(col, row, text, cb, primary := false) {
    p := Cell(col, row)
    return Btn(p.x, p.y, COLW, TILE_H, text, primary ? CLR["acc"] : CLR["tile"], primary ? CLR["accTxt"] : CLR["txt"], CLR["body"], cb, primary ? "s10 bold" : "s10")
}

; bouton arrondi
Btn(x, y, w, h, text, fill, txtColor, bg, cb, fontOpts := "s10 bold", keyHint := "") {
    pic := AddC("Picture", Format("x{} y{} w{} h{}", x, y, w, h), "HBITMAP:*" RoundHBM(w, h, 7, fill, bg))
    Font(fontOpts " c" txtColor)
    t := AddC("Text", Format("x{} y{} w{} h{} {} 0x200 BackgroundTrans", keyHint ? x + 14 : x, y, keyHint ? w - 50 : w, h, keyHint ? "" : "Center"), text)
    pic.OnEvent("Click", cb), t.OnEvent("Click", cb)
    if keyHint {
        Font("s10 c" (fill = CLR["acc"] ? CLR["accTxt"] : CLR["faint"]))
        k := AddC("Text", Format("x{} y{} w30 h{} Right 0x200 BackgroundTrans", x + w - 42, y, h), keyHint)
        k.OnEvent("Click", cb)
    }
    Font("s10 c" CLR["txt"])
    return t
}

; ---------- structure : onglet -> sections (icone) -> pages (pastilles) ----------
global NAV := [
    ["Gather", Chr(0xE707), [["Fields", Chr(0xE707), ["Fields"], "Fields"]
                          , ["Boost", Chr(0xE945), ["Hotbar"], "Boost"]
                          , ["Settings", Chr(0xE713), ["General", "Conversion"], "Options"]
                          , ["AI Gather", Chr(0xE890), ["Settings", "Tokens", "Detection", "Movement"], "AI Gather"]]],
    ["Collect", Chr(0xE719), [["Items", Chr(0xE719), ["Dispensers", "Passes"], "Items"]
                            , ["Bug run", Chr(0xEBE8), ["Mobs"], "Mobs"], ["Boss", Chr(0xE7C1), ["Boss", "Vicious Bee"], "Boss"]
                            , ["Quests", Chr(0xE9D5), ["Givers", "Progress"], "Quests"], ["Buffs", Chr(0xE945), ["Boosters"], "Buffs"]
                            , ["Memory Match", Chr(0xE8A9), ["Games"], "Memory"]]],
    ["Planters", Chr(0xE8F1), [["Planters", Chr(0xE8F1), ["Planters"], "Planters"]]],
    ["Status", Chr(0xE9D9), [["Session", Chr(0xE9D9), ["Stats", "Log"], "Session"]]],
    ["Tools", Chr(0xE90F), [["Hive Check", Chr(0xE721), ["Setup", "Common-Epic", "Legendary-Event"], "Hive"]]],
    ["Settings", Chr(0xE713), [["Macro", Chr(0xE713), ["Reconnect", "Discord", "Captures"], "Macro"]
                             , ["Hotkeys", Chr(0xE765), ["Hotkeys"], "Hotkeys"], ["Game", Chr(0xE7FC), ["Speed", "Hive & sprinkler"], "Game"]
                             , ["Profiles", Chr(0xE77B), ["Account", "Preset"], "Profiles"], ["Appearance", Chr(0xE790), ["Theme"], "Theme"]
                             , ["Misc", Chr(0xE712), ["Misc", "Credits"], "Misc"]]]]

; melange deux couleurs (t = part de a)
Mix(a, b, t) {
    ca := Integer("0x" a), cb := Integer("0x" b), out := ""
    for sh in [16, 8, 0]
        out .= Format("{:02X}", Round(((ca >> sh) & 255) * t + ((cb >> sh) & 255) * (1 - t)))
    return out
}

; bloque / relance le dessin de la fenetre (changements de page sans clignotement)
Freeze(on) {
    static depth := 0
    depth := Max(0, depth + (on ? 1 : -1))
    if on && (depth = 1)
        SendMessage 0x000B, 0, 0, MainGui      ; WM_SETREDRAW off
    else if !on && (depth = 0) {
        SendMessage 0x000B, 1, 0, MainGui
        DllCall("RedrawWindow", "Ptr", MainGui.Hwnd, "Ptr", 0, "Ptr", 0, "UInt", 0x0185)
    }
}

NavTab(tab) {
    for t in NAV
        if (t[1] = tab)
            return t
}
NavSec(tab, sec) {
    for s in NavTab(tab)[3]
        if (s[1] = sec)
            return s
}

Page(tab, sec, pg) {
    global CurKey := tab "|" sec "|" pg, RowBase := ROW0
    PageCtl[CurKey] := []
}

ShowTab(tab, *) {
    global CurTab := tab
    for t, c in TabCtl {
        active := (t = tab)
        c.bg.Value := "HBITMAP:*" (active ? TabHBM(c.w, 36, CLR["body"], CLR["top"]) : RoundHBM(c.w, 36, 0, CLR["top"], CLR["top"]))
        c.icon.SetFont("c" (active ? CLR["acc"] : CLR["dim"]))
        c.label.SetFont("c" (active ? CLR["txt"] : CLR["dim"]))
    }
    Freeze(true)
    for t, list in RailCtl
        for it in list
            it.bg.Visible := it.icon.Visible := it.lab.Visible := (t = tab)
    ShowSection(CurSec.Has(tab) ? CurSec[tab] : NavTab(tab)[3][1][1])
    Freeze(false)
}

ShowSection(sec, *) {
    CurSec[CurTab] := sec
    for it in RailCtl[CurTab] {
        active := (it.sec = sec)
        it.bg.Value := "HBITMAP:*" RoundHBM(RAIL_W - 8, 50, 10, active ? Mix(CLR["acc"], CLR["rail"], 0.22) : CLR["rail"], CLR["rail"])
        it.icon.SetFont("c" (active ? CLR["acc"] : CLR["dim"]))
        it.lab.SetFont("c" (active ? CLR["txt"] : CLR["dim"]))
    }
    key := CurTab "|" sec
    for k, list in PillCtl
        for it in list
            it.bg.Visible := it.txt.Visible := (k = key)
    pages := NavSec(CurTab, sec)[3]
    ShowPg(CurPg.Has(key) ? CurPg[key] : pages[1])
}

ShowPg(pg, *) {
    FieldPickerClose()
    Freeze(true)
    skey := CurTab "|" CurSec[CurTab]
    CurPg[skey] := pg
    if (skey = "Gather|Fields" && pg = "Fields")
        RefreshFieldList()
    key := skey "|" pg
    for k, list in PageCtl
        if (k != key)
            for c in list
                c.Visible := false
    for c in PageCtl[key]
        c.Visible := !Hidden.Has(c.Hwnd)
    for it in PillCtl[skey] {
        active := (it.pg = pg)
        it.bg.Value := "HBITMAP:*" RoundHBM(it.w, 28, 13, active ? CLR["acc"] : CLR["pill"], CLR["body"], active ? "" : "3E3E3E")
        it.txt.SetFont("c" (active ? CLR["accTxt"] : CLR["txt"]))
    }
    Freeze(false)
}

; fleches < > : page precedente / suivante de la section
StepPage(dir, *) {
    skey := CurTab "|" CurSec[CurTab]
    pages := NavSec(CurTab, CurSec[CurTab])[3]
    for i, p in pages
        if (p = CurPg[skey]) {
            n := i + dir
            if (n >= 1 && n <= pages.Length)
                ShowPg(pages[n])
            return
        }
}

OpenPage(tab, sec, pg, *) {
    ShowTab(tab)
    ShowSection(sec)
    ShowPg(pg)
}

; ---------- mises a jour en direct ----------
UI_SetStatus(txt) {
    if UI.Has("status")
        UI["status"].Value := txt
}

CurrentField(f) {
    if UI.Has("field")
        UI["field"].Value := f
}

UI_Chip(state) {
    if !UI.Has("dot")
        return
    UI["dot"].Value := "HBITMAP:*" CircleHBM(9, state = "Running" ? CLR["ok"] : state = "Pause" ? CLR["warn"] : "6E6E6E", CLR["tile"])
    Tip(UI["dot"], state)
}

; ajoute seulement la nouvelle ligne au journal (pas de reecriture complete = pas de clignotement)
UI_AppendLog() {
    static added := 0
    if !UI.Has("log") || !LogLines.Length
        return
    c := UI["log"]
    if (++added > 400) {   ; de temps en temps on repart des 300 dernieres lignes
        out := ""
        for l in LogLines
            out .= l "`r`n"
        c.Value := out, added := 0
    } else {
        line := LogLines[LogLines.Length] "`r`n"
        n := DllCall("GetWindowTextLength", "Ptr", c.Hwnd)
        SendMessage 0xB1, n, n, c                   ; EM_SETSEL a la fin
        SendMessage 0xC2, 0, StrPtr(line), c        ; EM_REPLACESEL
    }
    SendMessage 0x115, 7, 0, c
}

UI_UpdateQuests() {
    for q in QUEST_LIST
        if UI.Has("quest_" q[1])
            UI["quest_" q[1]].Value := QuestText.Has(q[1]) ? QuestText[q[1]] : (S["Q_" q[1]] ? "Not read yet" : "Desactivee")
}

FmtSecs(sec) => (sec >= 3600) ? (sec // 3600 "h" Format("{:02}", Mod(sec // 60, 60))) : (sec // 60 " min")

UpdateStats() {
    static tick := 0
    tick++
    if !UI.Has("st_run")
        return
    UI["st_run"].Value := Dur(Running ? A_TickCount - StartTick : 0)
    UI["st_gather"].Value := Dur(Stats["gather"])
    UI["st_convert"].Value := Dur(Stats["convert"])
    for k in ["cycles", "bugs", "bosses", "vb", "collects", "quests", "disconnects", "deaths"]
        UI["st_" k].Value := Stats[k]
    rob := GetRobloxHWND()
    UI["st_roblox"].Value := rob ? "Detected" : "Not found"
    UI["st_roblox"].SetFont("c" (rob ? CLR["ok"] : CLR["bad"]))
    if (Mod(tick, 5) = 1) {
        for c in COLLECT_LIST {
            left := c[3] - (Now() - GetTime("collect_" c[1]))
            UI["next_" c[1]].Value := left > 0 ? FmtSecs(left) : "ready"
        }
    }
}

; =====================================================================
BuildGui() {
    global MainGui, CurKey
    SetAccent()
    MainGui := Gui("-MaximizeBox -DPIScale" (S["UI_OnTop"] ? " +AlwaysOnTop" : ""), "Nova Macro")
    MainGui.BackColor := CLR["win"]
    MainGui.MarginX := MainGui.MarginY := 0
    MainGui.OnEvent("Close", (*) => ExitApp())
    CurKey := ""

    ; ---------------- onglets ----------------
    MainGui.Add("Picture", Format("x0 y0 w{} h{}", WIN_W, TOP_H), "HBITMAP:*" RoundHBM(WIN_W, TOP_H, 0, CLR["top"], CLR["top"]))
    ; logo Nova a gauche des onglets
    lg := MainGui.Add("Picture", "x10 y8 w30 h30", "HBITMAP:*" ImageHBM(A_ScriptDir "\assets\logo\nova_symbol_64.png", 30, 30, CLR["top"]))
    lg.OnEvent("Click", (*) => OpenPage("Settings", "Misc", "Credits")), Tip(lg, "Nova Macro")
    x := 46
    for t in NAV {
        w := 38 + StrLen(t[1]) * 8
        bg := MainGui.Add("Picture", Format("x{} y6 w{} h36", x, w), "HBITMAP:*" RoundHBM(w, 36, 0, CLR["top"], CLR["top"]))
        Font("s11 c" CLR["dim"], "Segoe MDL2 Assets")
        icon := MainGui.Add("Text", Format("x{} y6 w20 h36 0x200 BackgroundTrans", x + 12), t[2])
        Font("s10 c" CLR["dim"], "Segoe UI Semibold")
        label := MainGui.Add("Text", Format("x{} y6 w{} h36 0x200 BackgroundTrans", x + 35, w - 36), t[1])
        for c in [bg, icon, label]
            c.OnEvent("Click", ShowTab.Bind(t[1]))
        TabCtl[t[1]] := {bg: bg, icon: icon, label: label, w: w}
        x += w + 2
    }
    ; bouton rond a droite : aide
    hb := MainGui.Add("Picture", Format("x{} y8 w28 h28", WIN_W - 38), "HBITMAP:*" CircleHBM(28, CLR["acc"], CLR["top"]))
    Font("s10 c" CLR["accTxt"], "Segoe MDL2 Assets")
    ht := MainGui.Add("Text", Format("x{} y8 w28 h28 Center 0x200 BackgroundTrans", WIN_W - 38), Chr(0xE897))
    for c in [hb, ht]
        c.OnEvent("Click", (*) => OpenPage("Settings", "Misc", "Credits")), Tip(c, "Help")

    ; ---------------- corps ----------------
    MainGui.Add("Picture", Format("x0 y{} w{} h{}", BODY_Y, WIN_W, BODY_H), "HBITMAP:*" RoundHBM(WIN_W, BODY_H, 0, CLR["body"], CLR["body"]))
    MainGui.Add("Picture", Format("x{} y{} w{} h{}", RAIL_X, BODY_Y + 8, RAIL_W, BODY_H - 16), "HBITMAP:*" RoundHBM(RAIL_W, BODY_H - 16, 12, CLR["rail"], CLR["body"]))

    for t in NAV {
        RailCtl[t[1]] := []
        for i, sc in t[3] {
            y := BODY_Y + 14 + (i - 1) * 54, rw := RAIL_W - 8
            bg := MainGui.Add("Picture", Format("x{} y{} w{} h50", RAIL_X + 4, y, rw), "HBITMAP:*" RoundHBM(rw, 50, 10, CLR["rail"], CLR["rail"]))
            Font("s12 c" CLR["dim"], "Segoe MDL2 Assets")
            icon := MainGui.Add("Text", Format("x{} y{} w{} h28 Center 0x200 BackgroundTrans", RAIL_X + 4, y + 4, rw), sc[2])
            Font("s7 c" CLR["dim"], "Segoe UI Semibold")
            lab := MainGui.Add("Text", Format("x{} y{} w{} h16 Center BackgroundTrans", RAIL_X + 4, y + 31, rw), sc[4])
            for c in [bg, icon, lab]
                c.OnEvent("Click", ShowSection.Bind(sc[1])), Tip(c, sc[1])
            RailCtl[t[1]].Push({sec: sc[1], bg: bg, icon: icon, lab: lab})
            ; pastilles des pages de cette section
            key := t[1] "|" sc[1], PillCtl[key] := [], px := COL1
            for pg in sc[3] {
                pw := 28 + StrLen(pg) * 7
                pbg := MainGui.Add("Picture", Format("x{} y{} w{} h28", px, BODY_Y + 12, pw), "HBITMAP:*" RoundHBM(pw, 28, 13, CLR["pill"], CLR["body"], "3E3E3E"))
                Font("s9 c" CLR["txt"], "Segoe UI Semibold")
                ptx := MainGui.Add("Text", Format("x{} y{} w{} h28 Center 0x200 BackgroundTrans", px, BODY_Y + 12, pw), pg)
                pbg.OnEvent("Click", ShowPg.Bind(pg)), ptx.OnEvent("Click", ShowPg.Bind(pg))
                PillCtl[key].Push({pg: pg, bg: pbg, txt: ptx, w: pw})
                px += pw + 6
            }
        }
    }
    ; separateur entre les pastilles et le contenu
    MainGui.Add("Picture", Format("x{} y{} w{} h1", COL1, BODY_Y + 46, COL2 + COLW - COL1), "HBITMAP:*" RoundHBM(COL2 + COLW - COL1, 1, 0, "333333", "333333"))
    ; fleches < >
    for d in [[-1, Chr(0xE76B), WIN_W - 88], [1, Chr(0xE76C), WIN_W - 54]] {
        ab := MainGui.Add("Picture", Format("x{} y{} w28 h28", d[3], BODY_Y + 12), "HBITMAP:*" CircleHBM(28, CLR["pill"], CLR["body"], "3E3E3E"))
        Font("s8 c" CLR["txt"], "Segoe MDL2 Assets")
        at := MainGui.Add("Text", Format("x{} y{} w28 h28 Center 0x200 BackgroundTrans", d[3], BODY_Y + 12), d[2])
        ab.OnEvent("Click", StepPage.Bind(d[1])), at.OnEvent("Click", StepPage.Bind(d[1]))
    }

    BuildPages()

    ; ---------------- barre du bas ----------------
    CurKey := ""
    y1 := BODY_Y + BODY_H + 8, y2 := y1 + 40
    BarTile(8, y1, 260, "Status", "status", "Ready")
    UI["dot"] := MainGui.Add("Picture", Format("x{} y{} w9 h9", 74, y1 + 13), "HBITMAP:*" CircleHBM(9, "6E6E6E", CLR["tile"]))
    ; case "Account" et case "Preset" avec fleches < >
    for box in [["Account", "account", CurrentAccount(), 274, SwitchAccount, "Account"], ["Preset", "preset", CurrentPreset(), 518, SwitchPreset, "Preset"]] {
        BarTile(box[4], y1, 238, box[1], box[2], box[3], 76)
        UI[box[2]].Move(, , 100)
        for d in [[-1, Chr(0xE76B), box[4] + 178], [1, Chr(0xE76C), box[4] + 206]] {
            ab := MainGui.Add("Picture", Format("x{} y{} w24 h24", d[3], y1 + 5), "HBITMAP:*" CircleHBM(24, "3A3A3A", CLR["tile"]))
            Font("s7 c" CLR["txt"], "Segoe MDL2 Assets")
            at := MainGui.Add("Text", Format("x{} y{} w24 h24 Center 0x200 BackgroundTrans", d[3], y1 + 5), d[2])
            ab.OnEvent("Click", box[5].Bind(d[1])), at.OnEvent("Click", box[5].Bind(d[1]))
            Tip(ab, box[6] (d[1] < 0 ? " previous" : " next")), Tip(at, box[6] (d[1] < 0 ? " previous" : " next"))
        }
    }
    Btn(8, y2, 118, 34, Chr(0x25B6) "  Start", CLR["acc"], CLR["accTxt"], CLR["win"], StartMacro, "s10 bold", S["HK_Start"])
    Btn(132, y2, 118, 34, Chr(0x275A) Chr(0x275A) "  Pause", CLR["btn"], CLR["txt"], CLR["win"], TogglePause, "s10 bold", S["HK_Pause"])
    Btn(256, y2, 118, 34, Chr(0x25A0) "  Stop", CLR["btn"], CLR["txt"], CLR["win"], StopMacro, "s10 bold", S["HK_Stop"])
    BarTile(380, y2, 334, "Fields", "field", FieldNames(), 80)
    gb := MainGui.Add("Picture", Format("x{} y{} w30 h30", 720, y2 + 2), "HBITMAP:*" CircleHBM(30, CLR["acc"], CLR["win"]))
    Font("s10 c" CLR["accTxt"], "Segoe MDL2 Assets")
    gt := MainGui.Add("Text", Format("x{} y{} w30 h30 Center 0x200 BackgroundTrans", 720, y2 + 2), Chr(0xE713))
    for c in [gb, gt]
        c.OnEvent("Click", (*) => OpenPage("Settings", "Profiles", "Account")), Tip(c, "Settings")

    DllCall("dwmapi\DwmSetWindowAttribute", "Ptr", MainGui.Hwnd, "Int", 20, "Int*", 1, "Int", 4)
    bgr := Integer("0x" SubStr(CLR["top"], 5, 2) SubStr(CLR["top"], 3, 2) SubStr(CLR["top"], 1, 2))
    DllCall("dwmapi\DwmSetWindowAttribute", "Ptr", MainGui.Hwnd, "Int", 35, "Int*", bgr, "Int", 4)
    OnMessage(0x200, HoverTip)
    RefreshFieldList()
    ShowTab("Gather")   ; les pages sont triees avant l'affichage : pas de flash au demarrage
    MainGui.Show(Format("w{} h{} Hide", WIN_W, WIN_H))   ; affichee a la fin du chargement
    UI_UpdateQuests()
    UpdateStats()
}

BarTile(x, y, w, label, key, value, valueX := 70) {
    MainGui.Add("Picture", Format("x{} y{} w{} h34", x, y, w), "HBITMAP:*" RoundHBM(w, 34, 7, CLR["tile"], CLR["win"]))
    Font("s10 c" CLR["txt"], "Segoe UI Semibold")
    MainGui.Add("Text", Format("x{} y{} h34 0x200 BackgroundTrans", x + 12, y), label)
    Font("s10 c" CLR["dim"])
    UI[key] := MainGui.Add("Text", Format("x{} y{} w{} h34 Right 0x200 BackgroundTrans", x + valueX, y, w - valueX - 12), value)
}

; info-bulle au survol
HoverTip(wParam, lParam, msg, hwnd) {
    static last := 0
    if (hwnd = last)
        return
    last := hwnd
    if TipText.Has(hwnd) {
        ToolTip TipText[hwnd]
        SetTimer () => ToolTip(), -2000
    }
}

; ---------- presets (profils de reglages) ----------
PresetDir() => A_ScriptDir "\presets"
CurrentPreset() => GetState("preset", "Default")

PresetList() {
    list := []
    DirCreate PresetDir()
    if !FileExist(PresetDir() "\Default.ini")
        IniWrite IniRead(CFG_FILE, "cfg", , ""), PresetDir() "\Default.ini", "cfg"
    Loop Files PresetDir() "\*.ini"
        list.Push(SubStr(A_LoopFileName, 1, -4))
    return list
}

SavePreset(name) {
    DirCreate PresetDir()
    try FileDelete PresetDir() "\" name ".ini"
    IniWrite IniRead(CFG_FILE, "cfg", , ""), PresetDir() "\" name ".ini", "cfg"
}

; un preset ne change jamais les reglages du compte (vitesse, ruche, sprinkler...)
LoadPreset(name) {
    SaveAccount(CurrentAccount())
    data := IniRead(PresetDir() "\" name ".ini", "cfg", , "")
    IniDelete CFG_FILE, "cfg"
    if (data != "")
        IniWrite data, CFG_FILE, "cfg"
    SetState("preset", name)
    for k in ACCOUNT_KEYS
        IniWrite S[k], CFG_FILE, "cfg", k
}

; ---------- profils de compte ----------
SwitchAccount(dir, *) {
    if Running
        return MsgBox("Stop the macro (F3) before switching account.", "Nova Macro", "Icon!")
    list := AccountList(), cur := CurrentAccount(), idx := 1
    for i, n in list
        if (n = cur)
            idx := i
    if (list.Length < 2) {
        ToolTip "Only one account: create one in Settings > Profiles"
        SetTimer () => ToolTip(), -2500
        return
    }
    SaveAccount(cur)
    LoadAccount(list[Mod(idx - 1 + dir + list.Length, list.Length) + 1])
    Reload
}

NewAccount(*) {
    if Running
        return
    r := InputBox("Account name (e.g. MyAccount, Alt 1...).`nIt starts from the current settings: then change its speed, hive...", "Nova Macro - new account", "w340 h140")
    name := RegExReplace(Trim(r.Value), "[\\/:*?`"<>|]")
    if (r.Result != "OK" || name = "")
        return
    SaveAccount(CurrentAccount())
    SaveAccount(name)
    SetState("account", name)
    Log("Account created: " name)
    Reload
}

RenameAccount(*) {
    cur := CurrentAccount()
    if Running
        return
    r := InputBox("New name for account '" cur "' :", "Nova Macro - rename", "w320 h120", cur)
    name := RegExReplace(Trim(r.Value), "[\\/:*?`"<>|]")
    if (r.Result != "OK" || name = "" || name = cur)
        return
    SaveAccount(cur)
    try FileMove AccountFile(cur), AccountFile(name), 1
    SetState("account", name)
    Reload
}

DeleteAccount(*) {
    cur := CurrentAccount(), list := AccountList()
    if Running
        return
    if (list.Length < 2)
        return MsgBox("This is your only account, it cannot be deleted.", "Nova Macro")
    if (MsgBox("Delete account '" cur "' and its settings?", "Nova Macro", "YesNo Icon?") != "Yes")
        return
    try FileDelete AccountFile(cur)
    for n in list
        if (n != cur) {
            LoadAccount(n)
            break
        }
    Reload
}

SwitchPreset(dir, *) {
    if Running
        return MsgBox("Stop the macro (F3) before switching preset.", "Nova Macro", "Icon!")
    list := PresetList(), cur := CurrentPreset(), idx := 1
    for i, n in list
        if (n = cur)
            idx := i
    if (list.Length < 2)
    {
        ToolTip "Only one preset: create one in Settings > Profiles"
        SetTimer () => ToolTip(), -2500
        return
    }
    SavePreset(cur)
    LoadPreset(list[Mod(idx - 1 + dir + list.Length, list.Length) + 1])
    Reload
}

NewPreset(*) {
    if Running
        return
    r := InputBox("New preset name (e.g. Pine Farm, Quests...)", "Nova Macro - new preset", "w320 h120")
    name := RegExReplace(Trim(r.Value), "[\\/:*?`"<>|]")
    if (r.Result != "OK" || name = "")
        return
    SavePreset(CurrentPreset())
    SavePreset(name)
    SetState("preset", name)
    UI["preset"].Value := name
    Log("Preset created: " name)
}

DeletePreset(*) {
    cur := CurrentPreset()
    if Running || (cur = "Default")
        return MsgBox("The 'Default' preset cannot be deleted.", "Nova Macro")
    if (MsgBox("Delete preset '" cur "' ?", "Nova Macro", "YesNo Icon?") != "Yes")
        return
    try FileDelete PresetDir() "\" cur ".ini"
    LoadPreset("Default")
    Reload
}

; =====================================================================
BuildPages() {
    fields := ["None"]
    for f in FIELD_LIST
        fields.Push(f)
    W := COL2 + COLW - COL1   ; largeur du contenu

    ; ================= GATHER =================
    ; liste des champs : vide au depart, "+" pour en ajouter un (3 max), une carte par champ
    Page("Gather", "Fields", "Fields")
    Font("s10 c" CLR["dim"])
    FieldEmpty.Push(AddC("Text", Format("x{} y{} w{} Center BackgroundTrans", COL1, ROW0 + 90, W), "No field yet."))
    Font("s9 c" CLR["faint"])
    FieldEmpty.Push(AddC("Text", Format("x{} y{} w{} Center BackgroundTrans", COL1, ROW0 + 114, W), "Press + to pick a field."))
    cw := (W - 24 - 3 * 8) // 4   ; 4 cases par ligne dans une carte ouverte
    Loop 3 {
        i := A_Index, x := COL1, y := ROW0, p := "F" i "_"
        c := {i: i, inner: [], pat: []}
        c.bg := AddC("Picture", Format("x{} y{} w{} h48", x, y, W), "HBITMAP:*" RoundHBM(W, 48, 8, CLR["tile"], CLR["body"]))
        c.bar := AddC("Picture", Format("x{} y{} w4 h32", x + 8, y + 8), "HBITMAP:*" RoundHBM(4, 32, 2, CLR["acc"], CLR["tile"]))
        c.icon := AddC("Picture", Format("x{} y{} w32 h32", x + 20, y + 8), "")
        Font("s10 c" CLR["txt"], "Segoe UI Semibold")
        c.name := AddC("Text", Format("x{} y{} w300 h20 BackgroundTrans", x + 62, y + 6), "")
        Font("s8 c" CLR["dim"])
        c.sub := AddC("Text", Format("x{} y{} w480 h18 BackgroundTrans", x + 62, y + 26), "")
        Font("s11 c" CLR["dim"], "Segoe MDL2 Assets")
        c.edit := AddC("Text", Format("x{} y{} w28 h48 Center 0x200 BackgroundTrans", x + W - 70, y), Chr(0xE70F))
        c.del := AddC("Text", Format("x{} y{} w28 h48 Center 0x200 BackgroundTrans", x + W - 38, y), Chr(0xE74D))
        ; pas de clic sur le fond : il passerait devant les reglages de la carte ouverte
        for ctl in [c.name, c.sub, c.edit]
            ctl.OnEvent("Click", ToggleFieldCard.Bind(i))
        c.icon.OnEvent("Click", ((n, *) => FieldPicker(PickField.Bind(n))).Bind(i))
        c.del.OnEvent("Click", RemoveField.Bind(i))
        Tip(c.icon, "Change field"), Tip(c.edit, "Open / close settings"), Tip(c.del, "Delete this field")
        ; reglages du champ, ranges en cases (caches tant que la carte est fermee)
        global CaptureList := []
        cc := (col, row, label, help := "") => CardCell(x + 12 + (col - 1) * (cw + 8), y + 52 + (row - 1) * 36, cw, label, help)
        t := cc(1, 1, "Time (min)", "Maximum time in the field.")
        SpinAt(t.r - 64, t.m, 46, p "Mins", 1, 600)
        pat := CaptureList.Length
        t := cc(2, 1, "Pattern", "Shape of the path in the field.`nAdd your own patterns to the patterns\ folder.")
        DDLAt(t.r - 96, t.m, 96, p "Pattern", PATTERN_NAMES)
        t := cc(3, 1, "Size")
        DDLAt(t.r - 58, t.m, 58, p "Size", SIZE_LIST)
        t := cc(4, 1, "Width", "Number of pattern repeats.")
        SpinAt(t.r - 52, t.m, 34, p "Width", 1, 8)
        patEnd := CaptureList.Length
        t := cc(1, 2, "Max bag %", "Goes back to convert at this percentage.")
        SpinAt(t.r - 60, t.m, 42, p "Pack", 10, 100)
        t := cc(2, 2, "Return", "Walk = walks back to the hive.`nReset = the character respawns at the hive.")
        DDLAt(t.r - 84, t.m, 84, p "Return", ["Walk", "Reset"])
        t := cc(3, 2, "Sprinkler", "Places your sprinkler(s) based on your type.")
        ToggleAt(t.r - 46, t.m, p "Sprinkler", CLR["pill"])
        t := cc(4, 2, "Position", "Where to place the sprinkler in the field.")
        DDLAt(t.r - 90, t.m, 90, p "SprLoc", SPR_LOC_LIST)
        t := cc(1, 3, "Distance", "Sprinkler distance from the center (1 to 10).")
        SpinAt(t.r - 52, t.m, 34, p "SprDist", 1, 10)
        t := cc(2, 3, "AI Gather", "The AI replaces the pattern: it goes for the highest`npriority tokens, then comes back to the sprinkler.")
        ToggleAt(t.r - 46, t.m, p "AI", CLR["pill"])
        t := cc(3, 3, "Drift comp.", "Re-centers on the saturator (Supreme) to stay in`nthe field. In AI Gather: stays still on the saturator.")
        ToggleAt(t.r - 46, t.m, p "Drift", CLR["pill"])
        t := cc(4, 3, "Shift Lock", "Turns Shift Lock on while gathering, then off.")
        ToggleAt(t.r - 46, t.m, p "Shift", CLR["pill"])
        pat2 := CaptureList.Length
        t := cc(1, 4, "Inv. F/B", "Swaps forward and back in the pattern.")
        ToggleAt(t.r - 46, t.m, p "InvFB", CLR["pill"])
        t := cc(2, 4, "Inv. L/R", "Swaps left and right in the pattern.")
        ToggleAt(t.r - 46, t.m, p "InvLR", CLR["pill"])
        pat2End := CaptureList.Length
        t := cc(3, 4, "Camera", "Turns the camera before gathering (1 step = 45 degrees).")
        SpinAt(t.r - 34, t.m, 16, p "RotCount", 1, 4)
        DDLAt(t.r - 34 - 62, t.m, 60, p "RotDir", ["None", "Left", "Right"])
        Font("s8 c" CLR["faint"])
        AddC("Text", Format("x{} y{} w{} h30 0x200 BackgroundTrans", x + 12 + 3 * (cw + 8) + 4, y + 52 + 3 * 36, cw - 4), "AI Gather: see AI Gather tab")
        for k, ctl in CaptureList {
            ctl.GetPos(, &cy)
            c.inner.Push({c: ctl, dy: cy - y})
            Hidden[ctl.Hwnd] := 1
            if (k > pat && k <= patEnd) || (k > pat2 && k <= pat2End)
                c.pat.Push(ctl)
        }
        CaptureList := ""
        FieldCards.Push(c)
        CardAIState(i)
    }
    ; bouton + en bas de la barre d'icones
    pb := AddC("Picture", Format("x{} y{} w44 h44", RAIL_X + (RAIL_W - 44) // 2, BODY_Y + BODY_H - 62), "HBITMAP:*" CircleHBM(44, CLR["acc"], CLR["rail"]))
    Font("s14 c" CLR["accTxt"], "Segoe MDL2 Assets")
    pt := AddC("Text", Format("x{} y{} w44 h44 Center 0x200 BackgroundTrans", RAIL_X + (RAIL_W - 44) // 2, BODY_Y + BODY_H - 62), Chr(0xE710))
    pb.OnEvent("Click", AddField), pt.OnEvent("Click", AddField)
    Tip(pb, "Add a field"), Tip(pt, "Add a field")


    Page("Gather", "Boost", "Hotbar")
    items := ["None"]
    Loop Files A_ScriptDir "\assets\icons\items\*.png"
        items.Push(SubStr(A_LoopFileName, 1, -4))
    Font("s8 c" CLR["faint"])
    AddC("Text", Format("x{} y{} w{} BackgroundTrans", COL1 + 4, ROW0 - 2, W), "ITEM ON EACH KEY AND WHEN TO USE IT")
    Loop 6 {
        k := A_Index + 1, y := ROW0 + 18 + (A_Index - 1) * ROWH
        t := Tile(COL1, y, W, "Key " k, A_Index = 1 ? "In field = while gathering.`nAt hive = while converting.`nThe item is just a reminder for you." : "")
        DDLAt(COL1 + 100, t.m, 156, "B" k "_Item", items)
        DDLAt(COL1 + 270, t.m, 120, "B" k "_Mode", BOOST_MODES)
        Font("s9 c" CLR["dim"])
        AddC("Text", Format("x{} y{} h{} 0x200 BackgroundTrans", COL1 + 404, y, TILE_H), "every")
        SpinAt(COL1 + 468, t.m, 70, "B" k "_Int", 1, 99999)
        Font("s9 c" CLR["dim"])
        AddC("Text", Format("x{} y{} h{} 0x200 BackgroundTrans", t.r - 12, y, TILE_H), "s")
    }

    Page("Gather", "Settings", "General")
    Group(1, "Gathering")
    RowToggle(1, 1, "Disable gathering", "M_GatherOff", "The macro no longer gathers: only collects,`nbosses, quests...")
    RowSpin(1, 2, "Quest gathering (min)", "Q_GatherMins", 1, 120, "Gathering time for a quest field.", 90)
    RowToggle(1, 3, "Fast Pine Tree return", "PineFast", "Returns from Pine Tree with the cannon and glider (faster,`nbut depends on where gathering ends).`nOff = classic walk back, more reliable.")
    Group(2, "Sprinkler")
    RowDDL(2, 1, "Sprinkler type", "SprinklerType", SPRINKLER_TYPES, 120, "Basic / Supreme = 1 sprinkler, Silver = 2,`nGolden = 3, Diamond = 4 (placed while jumping).`nDrift compensation needs the Supreme.")
    RowSpin(2, 2, "Sprinkler key", "SprinklerSlot", 1, 7, "Hotbar slot of your sprinkler.", 90)

    Page("Gather", "Settings", "Conversion")
    Group(1, "Conversion")
    RowSpin(1, 1, "Max conversion (s)", "ConvertMax", 10, 3600, "Maximum wait at the hive.", 90)
    RowSpin(1, 2, "Extra wait (s)", "ConvertExtra", 0, 600, "Waits a bit more after converting.", 90)
    Group(2, "Honey balloon")
    RowToggle(2, 1, "Convert the balloon", "Balloon", "Also waits for the hive balloon to be converted.`nOff = goes back to gathering as soon as the bag is empty.")
    RowSpin(2, 2, "Balloon every (min)", "BalloonMins", 0, 600, "0 = every conversion.`nOtherwise, the balloon is only converted once per period.", 90)

    ; ---------- Farm IA ----------
    Page("Gather", "AI Gather", "Settings")
    Group(1, "Hive color")
    cl := Cell(1, 1), t := Tile(cl.x, cl.y, W, "Hive", "Sorts tokens in the recommended order for your hive.`nTokens of another color are removed from the list.`nYou can then change each priority (Tokens page).")
    for j, hv in HIVE_LIST {
        bx := t.r - (HIVE_LIST.Length - j + 1) * 92
        b := AddC("Picture", Format("x{} y{} w86 h24", bx, t.y + 3), "HBITMAP:*" RoundHBM(86, 24, 7, S["AI_Hive"] = hv ? CLR["acc"] : CLR["pill"], CLR["tile"]))
        Font("s9 bold c" (S["AI_Hive"] = hv ? CLR["accTxt"] : CLR["txt"]))
        tx := AddC("Text", Format("x{} y{} w86 h24 Center 0x200 BackgroundTrans", bx, t.y + 3), hv)
        HiveBtn[hv] := {b: b, t: tx}
        b.OnEvent("Click", SetHive.Bind(hv)), tx.OnEvent("Click", SetHive.Bind(hv))
    }
    global RowBase := ROW0 + 24 + ROWH
    RowSpin(1, 1, "Frames per second (FPS)", "AI_FPS", 2, 60, "How many times per second the AI looks at the screen.", 90)
    RowToggle(1, 2, "Show overlay", "AI_Overlay", "Draws a box around recognized tokens`n(green = the one being targeted).")
    RowToggle(1, 3, "Loot mode", "AI_Loot", "Ignores priorities: picks up the closest token.")
    RowToggle(2, 1, "Eco mode", "AI_Eco", "Looks less often when nothing happens`n(uses less CPU).")
    RowToggle(2, 2, "Stay on the sprinkler", "AI_Stay", "With the field's drift compensation: the character stays`nstill on the saturator, goes for each token`nthen comes right back.")
    RowToggle(2, 3, "Turn the camera", "AI_Cam", "When no token is seen, the camera turns around`nto look at the other side of the field.`nIt is reset before going back to the hive.")
    RowSpin(1, 4, "Turn around after (s)", "AI_CamEvery", 2, 30, "Time without seeing a token before turning the camera.", 90)

    ; tokens : un seul onglet, 3 groupes (ruche / autres / loot) avec un selecteur et une couleur chacun
    Page("Gather", "AI Gather", "Tokens")
    for j, sec in ["Hive", "Others", "Loot"] {
        bx := COL1 + (j - 1) * 152
        b := AddC("Picture", Format("x{} y{} w146 h28", bx, ROW0 - 6), "HBITMAP:*" RoundHBM(146, 28, 8, CLR["tile"], CLR["body"]))
        dot := AddC("Picture", Format("x{} y{} w10 h10", bx + 12, ROW0 + 3), "HBITMAP:*" CircleHBM(10, SecColor(sec), CLR["tile"]))
        Font("s9 bold c" CLR["txt"])
        t := AddC("Text", Format("x{} y{} w110 h28 0x200 BackgroundTrans", bx + 30, ROW0 - 6), sec)
        TokBtn[sec] := {b: b, dot: dot, t: t}
        for c in [b, dot, t]
            c.OnEvent("Click", ShowTokSec.Bind(sec))
    }
    Font("s8 c" CLR["faint"])
    UI["prio_title"] := AddC("Text", Format("x{} y{} w{} BackgroundTrans", COL1 + 4, ROW0 + 28, W), "")
    for tk in TOKEN_LIST {
        global CaptureList := []
        AddC("Picture", Format("x{} y{} w{} h26", COL1, ROW0, PRIO_W - 5), "HBITMAP:*" RoundHBM(PRIO_W - 5, 26, 7, CLR["tile"], CLR["body"]))
        AddC("Picture", Format("x{} y{} w3 h16", COL1 + 6, ROW0 + 5), "HBITMAP:*" RoundHBM(3, 16, 1, TokColor(tk[1]), CLR["tile"]))
        Font("s8 c" CLR["txt"])
        AddC("Text", Format("x{} y{} w{} h26 0x200 BackgroundTrans", COL1 + 14, ROW0, PRIO_W - 76), tk[2])
        SpinAt(COL1 + PRIO_W - 62, ROW0 + 1, 34, "AI_P_" tk[1], 0, 10)
        cells := []
        for ctl in CaptureList {
            ctl.GetPos(&cx, &cy)
            cells.Push({c: ctl, dx: cx - COL1, dy: cy - ROW0})
        }
        PrioCells[tk[1]] := cells
        CaptureList := ""
    }
    PrioLayout()

    Page("Gather", "AI Gather", "Detection")
    Group(1, "Screen capture")
    RowDDL(1, 1, "Capture method", "AI_Capture", ["Screen", "Window"], 110, "Screen = screen capture (fastest).`nWindow = Roblox window capture (works even`nif another window is in front).")
    RowDDL(1, 2, "Search resolution", "AI_Res", ["50%", "100%"], 90, "50% = fast (recommended).`n100% = more precise for small or far tokens.")
    RowSpin(1, 3, "Token size (px)", "AI_TokSize", 15, 120, "Token size on screen at 1080p (gathering camera).`nSmaller if your camera is far.", 90)
    RowSpin(1, 4, "Search area (%)", "AI_Zone", 30, 100, "Size of the area watched around the character.", 90)
    Group(2, "Reconnaissance")
    RowSpin(2, 1, "Color tolerance", "AI_Var", 0, 120, "Higher = finds tokens better (light, night),`nbut more false leads to check.", 90)
    RowSpin(2, 2, "Min match (%)", "AI_Match", 30, 100, "How similar an object must be to count`nas a token. Higher = safer.", 90)
    RowSpin(2, 3, "Character height (%)", "AI_PlayerY", 30, 80, "Where your character is on screen (top to bottom).", 90)

    Page("Gather", "AI Gather", "Movement")
    Group(1, "Deplacements")
    RowSpin(1, 1, "Max distance from sprinkler", "AI_Leash", 3, 25, "In tiles. The AI never goes further:`nit stays in the field.", 90)
    RowSpin(1, 2, "Pickup radius (px)", "AI_Reach", 10, 80, "On-screen distance at which a token counts as picked up.", 90)
    RowSpin(1, 3, "Max chase per token (s)", "AI_Chase", 1, 10, "Maximum time to go for a token.", 90)
    Group(2, "Sprinkler")
    RowSpin(2, 1, "Re-center every (s)", "AI_Home", 5, 120, "The AI regularly goes back to re-center on the sprinkler.", 90)
    RowToggle(2, 2, "Wander if nothing", "AI_Wander", "Without drift compensation: when no token is visible,`nthe AI walks small loops around the sprinkler.")
    RowSpin(2, 3, "Loop size (tiles)", "AI_WanderTiles", 1, 6, "Length of each side of the small loop.", 90)

    ; ================= COLLECT =================
    for cat in ["Dispensers", "Passes"] {
        Page("Collect", "Items", cat), n := 0
        for c in COLLECT_LIST
            if (c[4] = cat) || (cat = "Passes" && c[4] = "Items") {
                n++, col := (n <= 6) ? 1 : 2, row := (n <= 6) ? n : n - 6
                IconRow(col, row, A_ScriptDir "\assets\icons\collect\" c[1] ".png", c[2], "C_" c[1], "Every " FmtSecs(c[3]) ".", "next_" c[1])
            }
    }

    Page("Collect", "Bug run", "Mobs")
    for i, m in MOB_LIST
        IconRow(i <= 3 ? 1 : 2, i <= 3 ? i : i - 3, A_ScriptDir "\assets\icons\mobs\" m[1] ".png", m[2], "K_" m[1], "Fields: " JoinList(m[3]) "`nRespawn: " FmtSecs(m[4]))
    Font("s8 c" CLR["faint"])
    AddC("Text", Format("x{} y{} w700 BackgroundTrans", COL1, ROW0 + 3 * ROWH + 8), "Walks around the field while your bees kill the mobs.")

    Page("Collect", "Boss", "Boss")
    for i, b in BOSS_LIST
        IconRow(i <= 3 ? 1 : 2, i <= 3 ? i : i - 3, A_ScriptDir "\assets\icons\mobs\" b[1] ".png", b[2], "B_" b[1], "Respawn: " FmtSecs(b[3]) "`nNot there = retry in 2 h.")
    RowDDL(2, 3, "Amulet", "Amulet", ["Keep", "Replace"], 130, "What to do when the game offers a new amulet.")
    RowSpin(1, 4, "Snail max (min)", "SnailMins", 0, 10000, "0 = until the Stump Snail dies.", 90)
    RowSpin(2, 4, "Commando max (min)", "ChickMins", 0, 600, "0 = no limit.", 90)

    Page("Collect", "Boss", "Vicious Bee")
    RowToggle(1, 1, "Hunt the Vicious Bee", "VB_Enable", "Night is detected automatically,`nthen the macro searches the selected fields.")
    RowToggle(2, 1, "Daily bonus only", "VB_Daily", "Only one Vicious Bee every 22 h.")
    for i, f in VB_FIELDS
        RowToggle(i <= 3 ? 1 : 2, (i <= 3 ? i : i - 3) + 1, f, "VB_" StrReplace(f, " "))

    Page("Collect", "Quests", "Givers")
    for i, q in QUEST_LIST
        IconRow(i <= 3 ? 1 : 2, i <= 3 ? i : i - 3, A_ScriptDir "\assets\icons\mobs\" q[1] ".png", q[2], "Q_" q[1], (q[1] = "Black" || q[1] = "Brown") ? "One quest per hour at most." : "")
    Font("s8 c" CLR["faint"])
    AddC("Text", Format("x{} y{} w700 BackgroundTrans", COL1, ROW0 + 3 * ROWH + 8), "The macro reads your quest log, does the objectives, then turns the quest in.")

    Page("Collect", "Quests", "Progress")
    Loop 6 {
        q := QUEST_LIST[A_Index], col := Mod(A_Index - 1, 3), row := (A_Index - 1) // 3
        qw := (W - 16) // 3, x := COL1 + col * (qw + 8), y := ROW0 + row * 136
        AddC("Picture", Format("x{} y{} w{} h128", x, y, qw), "HBITMAP:*" RoundHBM(qw, 128, 8, CLR["tile"], CLR["body"]))
        Font("s10 c" CLR["acc"], "Segoe UI Semibold")
        AddC("Text", Format("x{} y{} w210 BackgroundTrans", x + 12, y + 9), q[2])
        Font("s8 c" CLR["dim"])
        UI["quest_" q[1]] := AddC("Text", Format("x{} y{} w{} h90 BackgroundTrans", x + 12, y + 32, qw - 22), "")
    }

    Page("Collect", "Buffs", "Boosters")
    Group(1, "Field boosters")
    IconRow(1, 1, "", "Blue Field Booster", "BO_blue", "Every 45 min.")
    IconRow(1, 2, "", "Red Field Booster", "BO_red", "Every 45 min.")
    IconRow(1, 3, "", "Mountain Top Booster", "BO_mountain", "Every 45 min.")
    Group(2, "Info")
    Font("s9 c" CLR["dim"])
    AddC("Text", Format("x{} y{} w{} BackgroundTrans", COL2 + 4, RowBase + 4, COLW - 8)
        , "Boosters requested by a quest (Bucko,`nRiley) are used automatically.`n`nItems to use while gathering (extracts,`nglitter, dice...) are set in Gather > Boost.")

    Page("Collect", "Memory Match", "Games")
    for i, g in MM_LIST
        IconRow(i <= 3 ? 1 : 2, i <= 3 ? i : i - 3, A_ScriptDir "\assets\icons\collect\" g[4] ".png", g[2], "MM_" g[1], "Every " FmtSecs(g[3]) ". The grid is solved automatically." (g[1] = "Night" ? "`nNight only." : ""))
    Font("s8 c" CLR["faint"])
    AddC("Text", Format("x{} y{} w700 BackgroundTrans", COL1, ROW0 + 3 * ROWH + 8), "The macro goes to the Memory Match, starts it and flips the cards in pairs.")

    ; ================= PLANTERS =================
    Page("Planters", "Planters", "Planters")
    Font("s20 c" CLR["acc"], "Segoe MDL2 Assets")
    AddC("Text", Format("x{} y{} w{} Center BackgroundTrans", COL1, ROW0 + 70, W), Chr(0xE8F1))
    Font("s14 c" CLR["txt"], "Segoe UI Semibold")
    AddC("Text", Format("x{} y{} w{} Center BackgroundTrans", COL1, ROW0 + 120, W), "Work in progress")
    Font("s9 c" CLR["dim"])
    AddC("Text", Format("x{} y{} w{} Center BackgroundTrans", COL1, ROW0 + 152, W), "Planters are coming in a future update.")

    ; ================= STATUS =================
    Page("Status", "Session", "Stats")
    statRows := [["run", "Total time"], ["gather", "Gathering"], ["convert", "Conversion"], ["cycles", "Gathering cycles"]
        , ["bugs", "Bug runs"], ["bosses", "Bosses killed"], ["vb", "Vicious Bees"], ["collects", "Collects"]
        , ["quests", "Quests turned in"], ["disconnects", "Disconnects"], ["deaths", "Deaths"], ["roblox", "Roblox"]]
    for i, st in statRows
        RowText(i <= 7 ? 1 : 2, i <= 7 ? i : i - 7, st[2], "st_" st[1])

    Page("Status", "Session", "Log")
    Font("s9 c" CLR["txt"], "Consolas")
    UI["log"] := AddC("Edit", Format("x{} y{} w{} h{} ReadOnly -Wrap +VScroll -E0x200 Background{} c{}", COL1, ROW0, W, BODY_H - 60, CLR["input"], CLR["txt"]))
    DllCall("uxtheme\SetWindowTheme", "Ptr", UI["log"].Hwnd, "Str", "DarkMode_Explorer", "Ptr", 0)

    ; ================= TOOLS =================
    ; ---------- Hive Check ----------
    Page("Tools", "Hive Check", "Setup")
    Group(1, "Your hive")
    cl := Cell(1, 1), t := Tile(cl.x, cl.y, W, "Hive color", "The color most of your bees are.")
    for j, hv in HIVE_LIST {
        bx := t.r - (HIVE_LIST.Length - j + 1) * 92
        b := AddC("Picture", Format("x{} y{} w86 h24", bx, t.y + 3), "HBITMAP:*" RoundHBM(86, 24, 7, S["HC_Hive"] = hv ? CLR["acc"] : CLR["pill"], CLR["tile"]))
        Font("s9 bold c" (S["HC_Hive"] = hv ? CLR["accTxt"] : CLR["txt"]))
        tx := AddC("Text", Format("x{} y{} w86 h24 Center 0x200 BackgroundTrans", bx, t.y + 3), hv)
        HCBtn[hv] := {b: b, t: tx}
        b.OnEvent("Click", SetHCHive.Bind(hv)), tx.OnEvent("Click", SetHCHive.Bind(hv))
    }
    global RowBase := ROW0 + 24 + ROWH
    RowSpin(1, 1, "Number of bees", "HC_Bees", 1, 50, "How many bees are in your hive.", 90)
    RowDDL(2, 1, "Field you want to farm", "HC_Field", FIELD_LIST, 130, "The field you farm the most (or want to).")
    Font("s8 bold c" CLR["faint"])
    AddC("Text", Format("x{} y{} w{} BackgroundTrans", COL1 + 4, ROW0 + 24 + 2 * ROWH + 8, W), "HOW IT WORKS")
    Font("s9 c" CLR["dim"])
    AddC("Text", Format("x{} y{} w{} BackgroundTrans", COL1 + 4, ROW0 + 24 + 2 * ROWH + 28, W - 8)
        , "1. Pick your hive color and the field you want to farm.`n"
        . "2. Scan my bees: Nova opens the Bees menu in Roblox and reads every bee you have`n    (or mark them yourself in the 2 'bees' pages).`n"
        . "3. Analyze: a report opens in Notepad with what to get, what to gift first,`n    what to replace and why.")
    Btn(COL1, ROW0 + 226, W // 2 - 4, 36, "Scan my bees (in game)", CLR["tile"], CLR["txt"], CLR["body"], HiveScan, "s10 bold")
    Btn(COL1 + W // 2 + 4, ROW0 + 226, W // 2 - 4, 36, "Analyze my hive", CLR["acc"], CLR["accTxt"], CLR["body"], HiveCheck, "s10 bold")
    for pg in ["Common-Epic", "Legendary-Event"] {
        Page("Tools", "Hive Check", pg)
        list := []
        for b in BEE_LIST
            if (pg = "Common-Epic") = (b[4] = "Common" || b[4] = "Rare" || b[4] = "Epic")
                list.Push(b)
        cw := W // 3
        for i, b in list {
            x := COL1 + Mod(i - 1, 3) * cw, y := ROW0 - 4 + ((i - 1) // 3) * 30
            AddC("Picture", Format("x{} y{} w{} h26", x, y, cw - 6), "HBITMAP:*" RoundHBM(cw - 6, 26, 7, CLR["tile"], CLR["body"]))
            AddC("Picture", Format("x{} y{} w3 h16", x + 6, y + 5), "HBITMAP:*" RoundHBM(3, 16, 1, b[3] = "Blue" ? "3B82F6" : b[3] = "Red" ? "E04848" : "E5E5E5", CLR["tile"]))
            Font("s8 c" CLR["txt"])
            AddC("Text", Format("x{} y{} w76 h26 0x200 BackgroundTrans", x + 14, y), b[2])
            Font("s7 c" CLR["faint"])
            AddC("Text", Format("x{} y{} w52 h26 0x200 BackgroundTrans", x + 90, y), b[4])
            DDLAt(x + cw - 78, y + 2, 70, "HC_B_" b[1], ["-", "Have", "Gifted"])
        }
    }

    ; ================= SETTINGS =================
    Page("Settings", "Macro", "Reconnect")
    Group(1, "Reconnect")
    RowToggle(1, 1, "Enable reconnect", "R_Enable", "If Roblox crashes or disconnects you, the macro restarts`nthe game and claims a hive.")
    RowSpin(1, 2, "Reconnect every (h)", "R_Hours", 0, 48, "0 = never. Useful to keep a fresh server.", 90)
    Group(2, "Server")
    RowToggle(2, 1, "Public if private fails", "R_Public")
    t := Tile(COL1, RowBase + 2 * ROWH, W, "Private server link", "Paste your private server link`n(privateServerLinkCode=... or share?code=...).")
    EditAt(t.r - 440, t.m, 440, "R_Link")

    Page("Settings", "Macro", "Discord")
    Group(1, "Webhook")
    RowToggle(1, 1, "Enable notifications", "D_Enable", "Detailed messages: start, gathering, conversion, collects,`nbosses, quests, disconnects, errors, hourly report.")
    RowDDL(1, 2, "Message detail", "D_Level", ["All", "Important", "Essential"], 120, "All = every action.`nImportant = results.`nEssential = start/stop, bosses, disconnects, report.")
    t := Tile(COL1, RowBase + 2 * ROWH, W, "Webhook URL", "Channel settings > Integrations > Webhooks > Copy URL.")
    EditAt(t.r - 440, t.m, 440, "D_Webhook")
    RowBtn(1, 4, "Send a test message", (*) => Hook("Notification test", "If you see this message, the webhook works.", "good", SettingsFields(), true, 1), true)
    RowDDL(1, 5, "Live gather: refresh", "D_LiveEvery", ["1.5 s", "3 s", "5 s", "10 s", "30 s"], 100, "Time between two updates of the live message.")
    Group(2, "Options")
    RowToggle(2, 1, "Hourly report", "D_Hourly")
    RowToggle(2, 2, "Live gather", "D_Live", "While gathering: ONE message updated with a`nnew screenshot, the bag and the time (no spam).")
    t := Tile(COL2, RowBase + 3 * ROWH, COLW, "Your Discord ID", "To be pinged when something goes wrong`n(developer mode > Copy ID).")
    EditAt(t.r - 160, t.m, 160, "D_UserID", "Number")
    RowToggle(2, 5, "Ping me on problems", "D_Ping")

    Page("Settings", "Hotkeys", "Hotkeys")
    keys := ["None"]
    Loop 12
        keys.Push("F" A_Index)
    Group(1, "Hotkeys")
    for i, hk in [["HK_Start", "Start"], ["HK_Pause", "Pause"], ["HK_Stop", "Stop"]]
        RowDDL(1, i, hk[2], hk[1], keys, 90).OnEvent("Change", (*) => ApplyHotkeys())
    Group(2, "Info")
    Font("s9 c" CLR["dim"])
    AddC("Text", Format("x{} y{} w{} BackgroundTrans", COL2 + 4, RowBase + 4, COLW - 8), "Hotkeys work even when Roblox`nis in front.`nThey apply right away, no restart needed.")

    Page("Settings", "Macro", "Captures")
    Group(1, "Screenshots")
    RowToggle(1, 1, "Screenshots in Discord", "D_Shots", "Adds a screenshot to Discord messages`n(gathering, collects, deaths...).")
    RowDDL(1, 2, "Method (AI Gather)", "AI_Capture", ["Screen", "Window"], 110, "Screen = fastest.`nWindow = works even if Roblox is covered.")
    Group(2, "Screen")
    RowDDL(2, 1, "Watched screen", "AI_Screen", ["Roblox window"], 150, "The AI follows the Roblox window automatically,`non any screen.")

    Page("Settings", "Misc", "Misc")
    Group(1, "Window")
    RowToggle(1, 1, "Always on top", "UI_OnTop")
    RowBtn(1, 2, "Open the macro folder", (*) => Run(A_ScriptDir))
    RowToggle(1, 3, "Check updates at start", "U_Check", "At start, the macro checks for a new version.`nIf there is one, it offers to install it (your settings are kept).")
    RowBtn(1, 4, "Check for updates", (*) => CheckUpdate(true))
    Group(2, "Help")
    RowBtn(2, 1, "Create a diagnostic report", DiagnosticReport, true)
    Font("s8 c" CLR["faint"])
    AddC("Text", Format("x{} y{} w{} BackgroundTrans", COL2 + 4, RowBase + ROWH + 6, COLW - 8), "A file to send if something does not work:`nscreen, Roblox, settings and end of the log.`nNo webhook or server link inside.")

    Page("Settings", "Misc", "Credits")
    AddC("Picture", Format("x{} y{} w170 h170", COL1, ROW0 - 4), "HBITMAP:*" ImageHBM(A_ScriptDir "\assets\logo\nova_card.png", 170, 170, CLR["body"]))
    Font("s16 c" CLR["txt"], "Segoe UI Semibold")
    AddC("Text", Format("x{} y{} BackgroundTrans", COL1 + 190, ROW0), "Nova Macro")
    Font("s9 c" CLR["acc"], "Segoe UI Semibold")
    AddC("Text", Format("x{} y{} BackgroundTrans", COL1 + 330, ROW0 + 9), "version " NovaVersion())
    Font("s11 c" CLR["txt"], "Segoe UI Semibold")
    AddC("Text", Format("x{} y{} BackgroundTrans", COL1 + 190, ROW0 + 40), "Created by 5lmj")
    Font("s9 c" CLR["dim"])
    AddC("Text", Format("x{} y{} w{} BackgroundTrans", COL1 + 190, ROW0 + 70, W - 200)
        , "Bee Swarm Simulator macro made with AutoHotkey v2.`n`n"
        . "Add a pattern: drop a .ahk file in the patterns\ folder.`nPaths: one file per trip in the paths\ folder.")
    Font("s8 c" CLR["faint"])
    AddC("Text", Format("x{} y{} w{} BackgroundTrans", COL1 + 190, ROW0 + 168, W - 200)
        , "Includes code under the GNU GPL-3.0 (see LICENCE.txt).")

    Page("Settings", "Appearance", "Theme")
    Group(1, "Colors")
    RowDDL(1, 1, "Theme", "UI_Theme", ["Dark", "Black", "Slate", "Midnight", "Forest"], 130, "Window background colors.")
    RowDDL(1, 2, "Accent color", "UI_Accent", ["Nova", "Blue", "Honey", "Purple", "Green", "Pink"], 130, "Color of buttons and toggles.")
    RowBtn(1, 3, "Appliquer", (*) => Reload(), true)
    Group(2, "Preview")
    for i, th in ["Dark", "Black", "Slate", "Midnight", "Forest"] {
        x := COL2 + (i - 1) * 66, c := THEMES[th]
        AddC("Picture", Format("x{} y{} w58 h40", x, RowBase), "HBITMAP:*" RoundHBM(58, 40, 8, c[3], CLR["body"], c[5]))
        Font("s7 c" CLR["dim"])
        AddC("Text", Format("x{} y{} w58 Center BackgroundTrans", x, RowBase + 44), th)
    }

    Page("Settings", "Game", "Speed")
    Group(1, "Speed")
    RowSpin(1, 1, "Speed (no haste)", "MoveSpeed", 10, 100, "Your in-game speed WITHOUT buffs.`nThe macro keeps reading haste and other buffs`nand adapts ALL movement.", 90)
    RowSpin(1, 2, "Speed correction %", "SpeedCorr", -50, 50, "+ if you stop too early, - if you go too far.", 90)
    RowDDL(1, 3, "Movement", "MoveMethod", ["Cannon", "Walk"], 110, "Cannon = faster for far fields.")
    RowSpin(1, 4, "Key delay (ms)", "KeyDelay", 0, 200, "Raise it if the game misses keys.", 90)
    Group(2, "Permanent bonuses")
    RowToggle(2, 1, "Hasty Guard", "HastyGuard", "Turn on if you wear the Hasty Guard (+10%).")
    RowToggle(2, 2, "Gifted Hasty Bee", "GiftedHasty", "Turn on if you have a gifted Hasty Bee (+15%).")

    Page("Settings", "Game", "Hive & sprinkler")
    Group(1, "Hive")
    RowToggle(1, 1, "Detect my hive", "HiveAuto", "At start, the macro finds your hive and its slot`nby itself (and claims one if you have none).")
    RowSpin(1, 2, "Hive slot (if manual)", "HiveSlot", 1, 6, "1 = the hive closest to the ramp.", 90)
    RowSpin(1, 3, "Number of bees", "HiveBees", 1, 50, "Used to pick reachable fields and paths.", 90)
    RowSpin(1, 4, "Wait after reset (s)", "ResetWait", 0, 30, "Extra wait after a reset.", 90)
    Group(2, "Sprinkler")
    RowDDL(2, 1, "Sprinkler type", "SprinklerType", SPRINKLER_TYPES, 120, "Drift compensation needs the Supreme.")
    RowSpin(2, 2, "Sprinkler key", "SprinklerSlot", 1, 7, "Hotbar slot of your sprinkler.", 90)

    Page("Settings", "Profiles", "Account")
    Group(1, "Active account")
    t := Tile(COL1, RowBase, COLW, "Account", "Each account keeps its own settings:`nspeed, hive, sprinkler, private server...`nSwitch account with the arrows at the bottom.")
    Font("s10 c" CLR["acc"], "Segoe UI Semibold")
    AddC("Text", Format("x{} y{} w180 h{} Right 0x200 BackgroundTrans", t.r - 180, t.y, TILE_H), CurrentAccount())
    RowBtn(1, 2, "New account", NewAccount, true)
    RowBtn(1, 3, "Rename this account", RenameAccount)
    RowBtn(1, 4, "Delete this account", DeleteAccount)
    Group(2, "Saved in the account")
    Font("s9 c" CLR["dim"])
    AddC("Text", Format("x{} y{} w{} BackgroundTrans", COL2 + 4, RowBase + 4, COLW - 8)
        , "- speed, correction, Hasty Guard, Gifted Hasty`n- movement, key delay`n- hive (auto or slot), number of bees`n"
        . "- sprinkler type and key`n- reconnect and private server`n- your Discord ID`n`nEverything is saved as soon as you change a setting.")

    Page("Settings", "Profiles", "Preset")
    Group(1, "Active preset")
    t := Tile(COL1, RowBase, COLW, "Preset", "A preset = a full gathering setup:`nfields, patterns, collects, bosses, quests...`nIt does not touch account settings.")
    Font("s10 c" CLR["acc"], "Segoe UI Semibold")
    AddC("Text", Format("x{} y{} w180 h{} Right 0x200 BackgroundTrans", t.r - 180, t.y, TILE_H), CurrentPreset())
    RowBtn(1, 2, "New preset", NewPreset, true)
    RowBtn(1, 3, "Delete this preset", DeletePreset)
    Group(2, "How it works")
    Font("s9 c" CLR["dim"])
    AddC("Text", Format("x{} y{} w{} BackgroundTrans", COL2 + 4, RowBase + 4, COLW - 8)
        , "Create a preset for each way of playing (e.g. 'Pine Farm',`n'Quests', 'Bosses').`n`nSwitch preset with the arrows of the`n'Preset' box at the bottom of the window.")
}

; ---------- liste des champs (Gather) ----------
global FieldCards := [], FieldEmpty := [], FieldPickerGui := 0

; met a jour les cartes : un champ par carte, dans l'ordre, rien si l'emplacement est vide
FieldShown() => (CurTab = "Gather") && CurSec.Has("Gather") && (CurSec["Gather"] = "Fields") && CurPg.Has("Gather|Fields") && (CurPg["Gather|Fields"] = "Fields")

RefreshFieldList() {
    global FieldOpen
    shown := FieldShown(), n := 0
    for i, c in FieldCards {
        f := S["F" i "_Field"], on := (f != "None")
        if !on && (FieldOpen = i)
            FieldOpen := 0
        if on {
            n++
            c.name.Value := f
            c.icon.Value := "HBITMAP:*" FieldIcon(f, CLR["tile"], 32)
            FieldSub(i)
        }
        for ctl in [c.bg, c.bar, c.icon, c.name, c.sub, c.edit, c.del] {
            if on {
                if Hidden.Has(ctl.Hwnd)
                    Hidden.Delete(ctl.Hwnd)
            } else
                Hidden[ctl.Hwnd] := 1
            if shown
                ctl.Visible := on
        }
    }
    for ctl in FieldEmpty {
        if n
            Hidden[ctl.Hwnd] := 1
        else if Hidden.Has(ctl.Hwnd)
            Hidden.Delete(ctl.Hwnd)
        if shown
            ctl.Visible := !n
    }
    try UI["field"].Value := FieldNames()
    FieldLayout()
}

; champs choisis, pour la barre du bas
FieldNames() {
    out := ""
    Loop 3
        if (S["F" A_Index "_Field"] != "None")
            out .= (out ? ", " : "") S["F" A_Index "_Field"]
    return out ? out : "none"
}

; resume d'une ligne sous le nom du champ
FieldSub(i) {
    c := FieldCards[i], p := "F" i "_"
    c.sub.Value := Num(S[p "Mins"], 15) " min  " Chr(0x00B7) "  " (Num(S[p "AI"]) ? "AI Gather" : S[p "Pattern"] " " S[p "Size"] " x" S[p "Width"])
        . "  " Chr(0x00B7) "  bag " S[p "Pack"] "%  " Chr(0x00B7) "  return " StrLower(S[p "Return"])
}

; Farm IA active : les reglages du pattern sont grises
CardAIState(i) {
    on := Num(S["F" i "_AI"])
    for ctl in FieldCards[i].pat
        if (ctl.Type != "Text")   ; un texte grise est mal dessine : on ne grise que les controles
            try ctl.Enabled := !on
}

; place les cartes les unes sous les autres ; openH = hauteur de la carte qui s'ouvre / se ferme
; pendant l'animation seuls le fond et les cartes du dessous bougent, les reglages apparaissent a la fin
global FieldOpen := 0, FIELD_OPEN_H := 52 + 4 * 36 + 6
FieldLayout(openH := 0) {
    shown := FieldShown(), y := ROW0, W := COL2 + COLW - COL1
    Freeze(true)
    for i, c in FieldCards {
        used := (S["F" i "_Field"] != "None"), isOpen := used && (i = FieldOpen)
        h := isOpen ? (openH ? openH : FIELD_OPEN_H) : 48
        if used {
            c.bg.Move(, y, , h)
            c.bg.Value := "HBITMAP:*" RoundHBM(W, h, 8, CLR["tile"], CLR["body"])
            c.bar.Move(, y + 8), c.icon.Move(, y + 8), c.name.Move(, y + 6), c.sub.Move(, y + 26), c.edit.Move(, y), c.del.Move(, y)
            c.edit.Value := isOpen ? Chr(0xE70E) : Chr(0xE70F)
        }
        vis := isOpen && !openH
        for it in c.inner {
            if vis {
                it.c.Move(, y + it.dy)
                if Hidden.Has(it.c.Hwnd)
                    Hidden.Delete(it.c.Hwnd)
            } else
                Hidden[it.c.Hwnd] := 1
            if shown
                it.c.Visible := vis
        }
        if used
            y += h + 6
    }
    Freeze(false)
}

; crayon : la carte se deroule (ou se replie) en douceur
ToggleFieldCard(i, *) {
    global FieldOpen
    FieldPickerClose()
    if (prev := FieldOpen) {
        AnimateCard(FIELD_OPEN_H, 48)
        FieldOpen := 0
        FieldLayout()
        if (prev = i)
            return
    }
    FieldOpen := i
    AnimateCard(48, FIELD_OPEN_H)
    FieldLayout()
}

; deroulement sur ~160 ms, ralenti a la fin
AnimateCard(from, to) {
    static dur := 160
    t0 := A_TickCount
    Loop {
        k := Min(1, (A_TickCount - t0) / dur)
        FieldLayout(from + (to - from) * (1 - (1 - k) ** 3))
        if (k >= 1)
            break
        Sleep 10
    }
}

; une case de reglage dans une carte ouverte : fond, nom a gauche, controle a droite
CardCell(x, y, w, label, help := "") {
    AddC("Picture", Format("x{} y{} w{} h30", x, y, w), "HBITMAP:*" RoundHBM(w, 30, 7, CLR["pill"], CLR["tile"]))
    Font("s8 c" CLR["dim"])
    t := AddC("Text", Format("x{} y{} h30 0x200 BackgroundTrans", x + 8, y), label)
    if (help != "")
        Tip(t, help)
    return {r: x + w - 6, m: y + 3}
}

AddField(*) {
    Loop 3
        if (S["F" A_Index "_Field"] = "None")
            return FieldPicker(PickField.Bind(A_Index))
    ToolTip "3 fields max: delete a field (trash) to add another one."
    SetTimer () => ToolTip(), -2500
}

PickField(i, field) {
    SaveSetting("F" i "_Field", field)
    RefreshFieldList()
    Log("Field " i ": " field)
}

RemoveField(i, *) {
    global FieldOpen
    if (FieldOpen = i)
        FieldOpen := 0
    SaveSetting("F" i "_Field", "None")
    RefreshFieldList()
}

; panneau de choix du champ, affiche DANS la fenetre de la macro, range par zone
FieldPicker(cb, *) {
    global FieldPickerGui
    FieldPickerClose()
    static zones := [["Starter", ["Sunflower", "Mushroom", "Dandelion", "Blue Flower", "Clover"]]
        , ["5 bees", ["Strawberry", "Spider", "Bamboo"]], ["10 bees", ["Pineapple", "Stump"]]
        , ["15 bees", ["Pine Tree", "Pumpkin", "Cactus", "Rose", "Mountain Top"]], ["35 bees", ["Coconut", "Pepper"]]]
    w := 92 + 5 * 64 + 8, h := 40 + zones.Length * 54 + 6
    ; petite fenetre attachee a la macro (une fenetre "enfant" se faisait recouvrir par la page)
    g := Gui("+Owner" MainGui.Hwnd " -Caption +ToolWindow -DPIScale")
    g.BackColor := CLR["pill"], g.MarginX := g.MarginY := 0
    g.SetFont("s10 c" CLR["txt"], "Segoe UI Semibold")
    g.Add("Text", "x14 y0 w300 h36 0x200 BackgroundTrans", "Pick a field")
    g.SetFont("s10 c" CLR["dim"], "Segoe MDL2 Assets")
    x := g.Add("Text", Format("x{} y0 w36 h36 Center 0x200 BackgroundTrans", w - 40), Chr(0xE711))
    x.OnEvent("Click", (*) => FieldPickerClose())
    y := 40
    for z in zones {
        g.SetFont("s8 bold c" CLR["faint"], "Segoe UI")
        g.Add("Text", Format("x14 y{} w76 h36 0x200 BackgroundTrans", y), StrUpper(z[1]))
        for j, f in z[2] {
            fx := 92 + (j - 1) * 64
            pic := g.Add("Picture", Format("x{} y{} w32 h32", fx + 16, y), "HBITMAP:*" FieldIcon(f, CLR["pill"], 32))
            g.SetFont("s7 c" CLR["dim"], "Segoe UI")
            lb := g.Add("Text", Format("x{} y{} w64 h14 Center BackgroundTrans", fx, y + 34), f)
            for ctl in [pic, lb]
                ctl.OnEvent("Click", ((fld, *) => (FieldPickerClose(), cb(fld))).Bind(f))
        }
        y += 54
    }
    g.OnEvent("Escape", (*) => FieldPickerClose())
    ; au centre de la zone de contenu de la macro : il ne depasse jamais de la fenetre
    WinGetClientPos &gx, &gy, , , MainGui
    g.Show(Format("x{} y{} w{} h{}{}", gx + COL1 + (COL2 + COLW - COL1 - w) // 2, gy + BODY_Y + (BODY_H - h) // 2, w, h, TestMode() ? " NA" : ""))
    WinSetRegion(Format("0-0 w{} h{} R16-16", w, h), g)
    FieldPickerGui := g
    if !TestMode()
        SetTimer FieldPickerWatch, 150
}

; se ferme des qu'on clique ailleurs (dans la macro ou une autre fenetre)
FieldPickerWatch() {
    if !FieldPickerGui
        return SetTimer(FieldPickerWatch, 0)
    if !WinActive("ahk_id " FieldPickerGui.Hwnd)
        FieldPickerClose()
}

FieldPickerClose() {
    global FieldPickerGui
    if FieldPickerGui
        try FieldPickerGui.Destroy()
    FieldPickerGui := 0
    SetTimer FieldPickerWatch, 0
}

; lance sans prendre le focus (tests automatiques : NOVA_TEST=1)
TestMode() => EnvGet("NOVA_TEST") = "1"

; petit anneau gris (comme le compteur de Revolution)
RingHBM(d, bg) {
    return HBM("ring|" d "|" bg, d, d, Draw)
    Draw(G, w, h) {
        Gdip_GraphicsClear(G, ARGB(bg))
        pen := Gdip_CreatePen(0xFF4A4A4A, 4)
        Gdip_DrawEllipse(G, pen, 3, 3, d - 7, d - 7)
        Gdip_DeletePen(pen)
    }
}

; ligne avec nom, temps restant (optionnel) et interrupteur
IconRow(col, row, icon, label, key, help := "", nextKey := "") {
    p := Cell(col, row), t := Tile(p.x, p.y, COLW, label, help)   ; pas d'icone : seuls les champs et les planters en ont
    if (nextKey != "") {
        Font("s9 c" CLR["dim"])
        UI[nextKey] := AddC("Text", Format("x{} y{} w80 h{} Right 0x200 BackgroundTrans", t.r - 140, p.y, TILE_H), "")
    }
    return ToggleAt(t.r - 46, t.m, key)
}

; Hive Check : couleur de la ruche
global HCBtn := Map()
SetHCHive(hv, *) {
    SaveSetting("HC_Hive", hv)
    for name, b in HCBtn {
        on := (name = hv)
        b.b.Value := "HBITMAP:*" RoundHBM(86, 24, 7, on ? CLR["acc"] : CLR["pill"], CLR["tile"])
        b.t.SetFont("c" (on ? CLR["accTxt"] : CLR["txt"]))
    }
}

; boutons Bleue / Rouge / Mixte : range les priorites des tokens
global HiveBtn := Map()
SetHive(hv, *) {
    ApplyHivePreset(hv)
    for name, b in HiveBtn {
        on := (name = hv)
        b.b.Value := "HBITMAP:*" RoundHBM(86, 24, 7, on ? CLR["acc"] : CLR["pill"], CLR["tile"])
        b.t.SetFont("c" (on ? CLR["accTxt"] : CLR["txt"]))
    }
    for tk in TOKEN_LIST
        RefreshControl("AI_P_" tk[1])
    try TokBtn["Hive"].dot.Value := "HBITMAP:*" CircleHBM(10, SecColor("Hive"), CLR["tile"])
    PrioLayout()
    Log("Token priorities: hive " hv)
}

; page des priorites d'un token
PrioPage(key) => (c := TokenCat(key)) = "L" ? "Loot" : (c = "O") ? "Others" : "Hive"

; couleur de chaque groupe et de chaque token (petite barre a gauche de la case)
SecColor(sec) {
    static hive := Map("Blue", "3B82F6", "Red", "E04848", "White", "E5E5E5", "Mixed", "F472B6")
    return (sec = "Loot") ? "F2B01E" : (sec = "Others") ? "A78BFA" : hive.Has(S["AI_Hive"]) ? hive[S["AI_Hive"]] : "F472B6"
}
TokColor(key) {
    static cat := Map("R", "E04848", "B", "3B82F6", "W", "E5E5E5", "O", "A78BFA", "L", "F2B01E")
    return cat[TokenCat(key)]
}

; groupe de tokens affiche (Hive / Others / Loot)
global TokSec := "Hive", TokBtn := Map()
ShowTokSec(sec, *) {
    global TokSec := sec
    PrioLayout()
}

; grille des priorites : seulement le groupe choisi et les tokens de la ruche, ranges sans trou
global PrioCells := Map(), PRIO_W := (COL2 + COLW - COL1) // 4
PrioLayout() {
    hive := S["AI_Hive"], n := Map("Hive", 0, "Others", 0, "Loot", 0), k := 0
    shown := (CurTab = "Gather") && CurSec.Has("Gather") && (CurSec["Gather"] = "AI Gather") && CurPg.Has("Gather|AI Gather") && (CurPg["Gather|AI Gather"] = "Tokens")
    Freeze(true)
    for tk in TOKEN_LIST {
        sec := PrioPage(tk[1]), ok := HiveHas(hive, tk[1])
        if ok
            n[sec]++
        on := ok && (sec = TokSec)
        if on
            x := COL1 + Mod(k, 4) * PRIO_W, y := ROW0 + 46 + (k // 4) * 28, k++
        for it in PrioCells[tk[1]] {
            if on {
                it.c.Move(x + it.dx, y + it.dy)
                if Hidden.Has(it.c.Hwnd)
                    Hidden.Delete(it.c.Hwnd)
            } else
                Hidden[it.c.Hwnd] := 1
            if shown
                it.c.Visible := on
        }
    }
    for sec, b in TokBtn {
        active := (sec = TokSec)
        b.b.Value := "HBITMAP:*" RoundHBM(146, 28, 8, active ? Mix(SecColor(sec), CLR["tile"], 0.28) : CLR["tile"], CLR["body"])
        b.dot.Value := "HBITMAP:*" CircleHBM(10, SecColor(sec), active ? Mix(SecColor(sec), CLR["tile"], 0.28) : CLR["tile"])
        b.t.Value := sec " (" n[sec] ")"
        b.t.SetFont("c" (active ? CLR["txt"] : CLR["dim"]))
    }
    UI["prio_title"].Value := (TokSec = "Hive") ? StrUpper(hive) " HIVE TOKENS  -  change hive in Settings  -  0 = ignored, 10 = first"
        : (TokSec = "Others") ? "OTHER TOKENS: useful for every hive  -  0 = ignored, 10 = first"
        : "LOOT: items dropped in fields  -  0 = ignored, 10 = first"
    Freeze(false)
}

FieldIcon(field, bg, sz := 26) => ImageHBM(A_ScriptDir "\assets\icons\fields\" FieldKey(field) ".png", sz, sz, bg)

; rapport de diagnostic (sans webhook ni lien de serveur)
DiagnosticReport(*) {
    file := A_ScriptDir "\diagnostic.txt"
    UpdateWindow()
    out := "Nova Macro - report of " FormatTime(, "dd/MM/yyyy HH:mm") "`n"
        . "AutoHotkey " A_AhkVersion " (" (A_PtrSize = 8 ? "64" : "32") " bits) - Windows " A_OSVersion "`n"
        . "Screen " A_ScreenWidth "x" A_ScreenHeight " - DPI " A_ScreenDPI " (" Round(A_ScreenDPI / 96 * 100) " %)`n"
        . "Roblox: " (GetRobloxHWND() ? "open, " windowWidth "x" windowHeight " a " windowX "," windowY : "not found") "`n"
        . "Paths: " PATH_FILES.Count " - patterns: " PATTERN_FILES.Count " - token images: " TokenFileCount() "`n"
        . "Account: " CurrentAccount() " - preset: " CurrentPreset() "`n`n[settings]`n"
    for k, v in S
        if !(k ~= "i)webhook|link|userid")
            out .= k " = " v "`n"
    out .= "`n[log]`n"
    for l in LogLines
        out .= l "`n"
    try FileDelete file
    FileAppend out, file, "UTF-8"
    Run file
}

TokenFileCount() {
    n := 0
    Loop Files TokenDir() "\*.png"
        n++
    return n
}

JoinList(arr) {
    out := ""
    for v in arr
        out .= (out ? ", " : "") v
    return out
}

; charge une image (png avec transparence) et la pose sur une couleur de fond
ImageHBM(file, w, h, bg) {
    return HBM("img|" file "|" w "|" h "|" bg, w, h, Draw)
    Draw(G, w, h) {
        Gdip_GraphicsClear(G, ARGB(bg))
        Gdip_SetInterpolationMode(G, 7)
        if !FileExist(file)
            return
        pImg := Gdip_CreateBitmapFromFile(file)
        Gdip_DrawImage(G, pImg, 0, 0, w, h)
        Gdip_DisposeImage(pImg)
    }
}
