if (MoveMethod = "cannon")
{
	bm_gotoramp()
	bm_gotocannon()
	send "{e down}"
	HyperSleep(100)
	send "{e up}{" RightKey " down}"
	HyperSleep(1200)
	send "{space 2}"
	send "{" RightKey " up}"
	HyperSleep(6000)
	bm_Walk(22, RightKey)
	bm_Walk(7, LeftKey)
	bm_Walk(11, BackKey)
	send "{space down}"
	bm_Walk(1.5, BackKey)
	send "{space up}"
	bm_Walk(1.5, BackKey)
	send "{space down}"
	bm_Walk(1.5, BackKey)
	send "{space up}"
	bm_Walk(9, BackKey)
	bm_Walk(9, LeftKey)
	HyperSleep(2000)
}
else
{
	bm_gotoramp()
	bm_Walk(67.5, BackKey, LeftKey)
	send "{" RotRight " 4}"
	bm_Walk(31.5, FwdKey)
	bm_Walk(9, LeftKey)
	bm_Walk(9, BackKey)
	bm_Walk(58.5, LeftKey)
	bm_Walk(49.5, FwdKey)
	bm_Walk(2.25, BackKey, LeftKey)
	bm_Walk(36, LeftKey)
	send "{" RotLeft " 2}"
	send "{" FwdKey " down}"
	send "{space down}"
	HyperSleep(300)
	send "{space up}"
	HyperSleep(500)
	send "{" RotRight " 2}"
	HyperSleep(1000)
	send "{space down}"
	HyperSleep(300)
	send "{space up}"
	Walk(6)
	send "{" FwdKey " up}"
	bm_Walk(6, RightKey)
	bm_Walk(7, FwdKey)
	bm_Walk(6, LeftKey)
	bm_Walk(3, RightKey)
	bm_Walk(32, FwdKey)
	bm_Walk(4, BackKey)
    bm_Walk(8, LeftKey)
	send "{space down}"
	HyperSleep(100)
	send "{space up}"
	bm_Walk(4, LeftKey)
    Sleep 500
    send "{space down}"
	HyperSleep(100)
	send "{space up}"
    bm_Walk(6, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(12, FwdKey)
    send "{space down}"
	HyperSleep(100)
	send "{space up}"
    bm_Walk(14, FwdKey, LeftKey)
    bm_Walk(3, FwdKey)
}

; edited by Lorddrak