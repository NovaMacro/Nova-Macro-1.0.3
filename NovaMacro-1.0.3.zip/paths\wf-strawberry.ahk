﻿Send "{" RotLeft " 2}"
bm_Walk(12, BackKey)            ;walk back against wall
bm_Walk(15, BackKey, LeftKey)   ;move to corner (betwen strawberry & vicious bee)
bm_Walk(18, LeftKey)            ;ensure against vicious bee platform
bm_Walk(15, FwdKey)             ;move forward past vicious bee platform
bm_Walk(6, LeftKey)             ;align with SpawnLocation
bm_Walk(95, FwdKey)             ;walk towards hives

switch HiveSlot
    {
    case 3:
    bm_Walk(2.7, BackKey) ;center on hive pad 3

    default:
    bm_Walk(1.5, BackKey) ;walk backwards to avoid thicker hives
    bm_Walk(35, RightKey) ;walk to ramp
    bm_Walk(2.7, BackKey) ;center with hive pads
    }

;zaappiix 230203
; [2024-01-15/rpertusio] Avoid using corner (Hive 1 and ramp) where character gets stuck after 2024-01-12 BSS update
; [2024-01-15/rpertusio] No longer uses the Instant Converter corner to align
; [2024-01-15/rpertusio] Aligns with default SpawnLocation, saves walking if player chose Hive 3
