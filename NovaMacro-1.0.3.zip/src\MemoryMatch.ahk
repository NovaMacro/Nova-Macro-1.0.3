﻿; =====================================================================
;  Memory Match : va au jeu, appuie sur E puis resout la grille
;  (resolution reprise de Natro Macro, GPL-3.0)
; =====================================================================

DoMemoryMatch() {
    for g in MM_LIST {
        CheckStop()
        if !S["MM_" g[1]] || (Now() - GetTime("mm_" g[1]) < g[3])
            continue
        if (g[1] = "Night" && !NightDetected)
            continue
        PlayMemoryMatch(g)
    }
}

PlayMemoryMatch(g) {
    Loop 2 {
        ResetChar()
        SetStatus("Memory Match", g[2] (A_Index > 1 ? " (2nd try)" : ""))
        CallPath("gtc-" g[4])
        Sleep 500
        if PressE() {
            Sleep 1500
            SetTime("mm_" g[1])
            bm_SolveMemoryMatch(g[1])
            Stats["collects"]++
            Hook(g[2] " played", "", "collect", [["Next game", "in " FmtSecs(g[3])]], true, 2)
            return true
        }
    }
    SetTime("mm_" g[1], Now() - g[3] + 1800)   ; nouvel essai dans 30 min
    Log(g[2] ": E prompt not found")
    return false
}

bm_SolveMemoryMatch(MemoryMatchGame:="") {

	; initialize variables
	UpdateWindow()
	middleX := windowX+(windowWidth//2)
	middleY := windowY+(windowHeight//2)

	switch MemoryMatchGame {
		case "Extreme","Winter":
		Xoffset := 40, Tiles := 20

		case "Normal","Mega","Night":
		Xoffset := 0, Tiles := 16

		default:
		pBMScreen := Gdip_BitmapFromScreen(middleX-250 "|" middleY-210 "|500|50")
		if (Gdip_ImageSearch(pBMScreen, bitmaps["MMTitleWide"], , , , , , 8) = 1)
			Xoffset := 40, Tiles := 20
		else if (Gdip_ImageSearch(pBMScreen, bitmaps["MMTitle"], , , , , , 8) = 1)
			Xoffset := 0, Tiles := 16
		else {
			Gdip_DisposeImage(pBMScreen)
			return
		}
		Gdip_DisposeImage(pBMScreen)
	}

	StoreItemOAC := [], StoreItemOAC.Default := "", StoreItemOAC.Length := 20
	IgnoreItemOAC := [], IgnoreItemOAC.Default := 0, IgnoreItemOAC.Length := 20

	GridOAC:= [] ;Define MM Tile Coordinates
	Loop 5 {
		Xcord:=middleX-200+80*A_Index
		x:=A_index
		Loop 4 {
			row := []
			Ycord:=middleY-200+80*A_Index
			R:=A_index+(x-1)*4
			Row.push(Xcord)
			Row.push(Ycord)
			GridOAC.push(row)
		}
	}
	Tile:=0
	PriorityClaimedOAC:=0
	MMTempTile1OAC:=0
	MMTempTile2OAC:=0
	PairFoundOAC:=0
	MatchFoundOAC:=0
	ClickNum:=0
	Chances:=8
	LastChance:=0

	Loop 10 { ; Numer of available Chances.
		if(Chances=2) {
			Loop 1000 {
				pBMScreen := Gdip_BitmapFromScreen(middleX-275-Xoffset "|" middleY-146 "|100|100") ; Detect Number of Chances
				if(Gdip_ImageSearch(pBMScreen, bitmaps["Chances1"], , , , , , 10, , 2) = 1)  {
					LastChance := 1
					Gdip_DisposeImage(pBMScreen)
					break
				}
				Gdip_DisposeImage(pBMScreen)
				sleep 10
			}
		}
		loop 2 { ;Click tile, store item and compare
			if(A_Index=1) {
				; Compare Tiles before Click 1
				loop Tiles {
					i:=A_index
					loop Tiles {
						j := A_index

						if (i = j)
							continue ; Skip self-comparison

						; Check if either variable is Null or Ignored
						if(StoreitemOAC[i] = 0 || StoreitemOAC[j] = 0 || IgnoreitemOAC[i] = 1 || IgnoreitemOAC[j] = 1 || StoreitemOAC[i] = "" || StoreitemOAC[j] = "")
							continue ; Skip the comparison if either Item is Null or Not Priority

						; Check if variables have the same value
						if (Gdip_ImageSearch(StoreitemOAC[i], StoreitemOAC[j], , , , , , 10, , 2)=1) {
							MMTempTile1OAC:=i
							MMTempTile2OAC:=j
							Gdip_DisposeImage(StoreitemOAC[i]), StoreitemOAC[i]:=0	;claimed
							Gdip_DisposeImage(StoreitemOAC[j]), StoreitemOAC[j]:=0	;claimed
							PairFoundOAC:=1
							Break 2
						} else {
							PairFoundOAC:=0
						}
					}
				}
				;end compare1
				if(PairFoundOAC) {
					LastTile:=Tile
					Tile:=MMTempTile1OAC ;-1
				}
			} else {
				if(PairFoundOAC=0 || LastChance=1) {
					; Compare all other tiles to click 1
					j:=Tile

					loop Tiles {
						i:=A_index

						if (i = Tile)
							continue ; Skip self-comparison

						; Check if either variable is Null or Ignored
						if(StoreitemOAC[i] = 0 || StoreitemOAC[j] = 0 || (IgnoreitemOAC[i] = 1 && LastChance!=1) || StoreitemOAC[i] = "" || StoreitemOAC[j] = "")
							continue ; Skip the comparison if either Item is Null or Not Priority

						; Check if Items are the same.
						if (Gdip_ImageSearch(StoreitemOAC[j], StoreitemOAC[i], , , , , , 10, , 2)=1) {
							MMTempTile2OAC:=i
							Gdip_DisposeImage(StoreitemOAC[i]), StoreitemOAC[i]:=0	;claimed
							Gdip_DisposeImage(StoreitemOAC[j]), StoreitemOAC[j]:=0	;claimed
							MatchFoundOAC:=1
							Break
						} else {
							MatchFoundOAC:=0
						}
					}
					;end compare2
					if(MatchFoundOAC) {
						LastTile:=Tile
						Tile:=MMTempTile2OAC
					}
				}
				if(PairFoundOAC)
					Tile:=MMTempTile2OAC
			}

			if(!MatchFoundOAC && !PairFoundOAC) {
				Loop 20 {
					Tile := Random(1, Tiles)
					If(StoreItemOAC[Tile]="")
						break
				}
			}
			;tile:=1
			TileXCordOAC:=GridOAC[Tile][1]-Xoffset ; Determine click coordinates
			TileYCordOAC:=GridOAC[Tile][2]
			ClickNum++
			MMItemOAC:=0

			MouseMove TileXCordOAC, TileYCordOAC
			sleep 400 ; I know this looks excessive, but it is to compensate for lag.
			sendinput "{click down}"
			sleep 100
			sendinput "{click up}"
			DllCall("GetSystemTimeAsFileTime", "int64p", &s:=0)
			sleep 100
			MouseMove middleX, middleY-190
			DllCall("GetSystemTimeAsFileTime", "int64p", &f:=s)
			Sleep Max(500 - (f - s)//10000, -1) ; match previous version's total sleep 500

			Loop 300 {
				pBMScreen := Gdip_BitmapFromScreen(TileXCordOAC-35 "|" TileYCordOAC-20 "|45|30") ; Detect Clicked Item
				;Gdip_SaveBitmapToFile(pBMScreen, "empty" A_index ".png")
				if (Gdip_ImageSearch(pBMScreen, bitmaps["MMBorder"], , , , 8, 20, 1, , 2) = 1) {
					if (Gdip_ImageSearch(pBMScreen, bitmaps["MMEmptyTile"], , 25, 10, , , 1, , 2) != 1) {
						MMItemOAC := 1
						Gdip_DisposeImage(pBMScreen)
						break
					}
				}
				Gdip_DisposeImage(pBMScreen)
				sleep 10
			}
			Sleep 300

			if(MMItemOAC=1 && PairFoundOAC!=1 && (A_Index=1 || (A_Index=2 && MatchFoundOAC!=1))) {
				StoreItemOAC[Tile] := Gdip_BitmapFromScreen(TileXCordOAC-25 "|" TileYCordOAC-25 "|50|50") ; Detect Clicked Item
			}

			if(A_index=1) {
				pBMScreen := Gdip_BitmapFromScreen(middleX-275-Xoffset "|" middleY-146 "|100|100") ; Detect Number of Chances
				if (Gdip_ImageSearch(pBMScreen, bitmaps["Chances2"], , , , , , 10, , 2) = 1)
				Chances:=2
				Gdip_DisposeImage(pBMScreen)
			}

			if(A_Index=1) {
				Click1Tile:=Tile
				if(PairFoundOAC) {
					Tile:=MMTempTile2OAC
				}
			} else {
				if((Gdip_ImageSearch(StoreitemOAC[Click1Tile], StoreitemOAC[Tile], , , , , , 10, , 2) = 1) && PairFoundOAC!=1 && MatchFoundOAC!=1) {
					Gdip_DisposeImage(StoreitemOAC[Click1Tile]), StoreitemOAC[Click1Tile]:=0 ;"claimed"
					Gdip_DisposeImage(StoreitemOAC[Tile]), StoreitemOAC[Tile]:=0 ;"claimed"
					Continue
				}
				if(PairFoundOAC || MatchFoundOAC) {
					Tile:=LastTile
					if(PairFoundOAC)
						PairFoundOAC:=0
					if(MatchFoundOAC)
						MatchFoundOAC:=0
				}
			}

			if(A_Index=2 && LastChance=1)
				break 2
		} ;Close loop 2 Click tile, store item, and compare
	} ;close Chances Loop

	; dispose remnant bitmaps
	for pBM in StoreitemOAC
		IsSet(pBM) && IsInteger(pBM) && (pBM > 0) && Gdip_DisposeImage(pBM)

	MouseMove windowX+350, windowY+offsetY+100
	Sleep 1200
	SetStatus("Memory Match", (MemoryMatchGame ? (MemoryMatchGame " ") : "") "Memory Match")

	; wait for window to close
	Loop 50 {
		pBMScreen := Gdip_BitmapFromScreen(middleX-250 "|" middleY-210 "|500|50")
		if (Gdip_ImageSearch(pBMScreen, bitmaps["MMTitle"], , , , , , 8) = 0) {
			Gdip_DisposeImage(pBMScreen)
			break
		}
		Gdip_DisposeImage(pBMScreen)
		Sleep 250
	}
}

