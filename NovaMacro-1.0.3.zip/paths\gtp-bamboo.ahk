﻿if (MoveMethod = "walk") 
{
    bm_gotoramp()
    bm_Walk(67.5, BackKey, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(23.5, FwdKey)
    bm_Walk(31.5, FwdKey, RightKey)
    bm_Walk(10, RightKey)
    send "{" RotRight " 2}"
    bm_Walk(30, FwdKey)
    bm_Walk(15, LeftKey)
    bm_Walk(3, FwdKey)
    bm_Walk(1, RightKey)
    bm_Walk(3, BackKey)
}
else {
    bm_gotoramp()
    bm_gotocannon()
    send "{" RotLeft " 2}{e down}"
    HyperSleep(100)
    send "{e up}{" FwdKey " down}"
    HyperSleep(800)
    send "{" SC_space " 2}"
    HyperSleep(3000)
    send "{" FwdKey " up}{" LeftKey " down}"
    HyperSleep(1000)
    send "{" SC_space "}"
    send "{" LeftKey " up}"
    HyperSleep(1000)
    bm_Walk(25, LeftKey)
    bm_Walk(30, FwdKey)
    bm_Walk(1, RightKey)
    bm_Walk(3, BackKey)
}
;path 230729 noobyguy
; edit by Lorddrak
