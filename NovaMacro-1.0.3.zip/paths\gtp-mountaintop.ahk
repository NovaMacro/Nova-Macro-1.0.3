﻿if (MoveMethod = "walk")
{
    bm_gotoramp()
    bm_Walk(67.5, BackKey, LeftKey)
    send "{" RotRight " 4}"
    bm_Walk(31, FwdKey)
    bm_Walk(7.8, LeftKey)
    bm_Walk(10, BackKey)
    bm_Walk(5, RightKey)
    bm_Walk(1.5, FwdKey)
    bm_Walk(60, LeftKey)
    bm_Walk(3.75, RightKey)
    bm_Walk(85, FwdKey)
    bm_Walk(45, RightKey)
    bm_Walk(50, BackKey)
    bm_Walk(60, RightKey)
    bm_Walk(5, LeftKey)
    bm_Walk(7, FwdKey)
    bm_Walk(9, FwdKey, LeftKey)
    bm_Walk(16.5, FwdKey)
    send "{" RotRight " 4}"
}
else {
    bm_gotoramp()
    bm_gotocannon()
    send "{e down}"
    HyperSleep(100)
    send "{e up}"
    Sleep 2750
}
;path 230729 noobyguy
